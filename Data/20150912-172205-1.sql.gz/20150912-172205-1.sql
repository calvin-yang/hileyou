-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 183.57.42.33
-- Port     : 3306
-- Database : hileyou
-- 
-- Part : #1
-- Date : 2015-09-12 17:22:05
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `tv_action`
-- -----------------------------
DROP TABLE IF EXISTS `tv_action`;
CREATE TABLE `tv_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `tv_action`
-- -----------------------------
INSERT INTO `tv_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '2', '2', '1383295068');
INSERT INTO `tv_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '2', '2', '1440410668');
INSERT INTO `tv_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '2', '2', '1383285646');
INSERT INTO `tv_action` VALUES ('4', 'add_document_blog', '发表博客', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '2', '2', '1440410860');
INSERT INTO `tv_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '2', '2', '1383285551');
INSERT INTO `tv_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '1', '1', '1383294988');
INSERT INTO `tv_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '1', '1', '1383295057');
INSERT INTO `tv_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '1', '1', '1383295963');
INSERT INTO `tv_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '1', '1', '1383296301');
INSERT INTO `tv_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '1', '1', '1383296392');
INSERT INTO `tv_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '1', '1', '1383296765');

-- -----------------------------
-- Table structure for `tv_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `tv_action_log`;
CREATE TABLE `tv_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`),
  KEY `action_ip_ix` (`action_ip`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `tv_action_log`
-- -----------------------------
INSERT INTO `tv_action_log` VALUES ('2', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1438751967');
INSERT INTO `tv_action_log` VALUES ('3', '10', '1', '2130706433', 'Menu', '17', '操作url：/tourism/index.php?s=/admin/menu/edit/id/17.html', '1', '1438753752');
INSERT INTO `tv_action_log` VALUES ('4', '10', '1', '2130706433', 'Menu', '118', '操作url：/tourism/index.php?s=/admin/menu/add/pid/0.html', '1', '1438754463');
INSERT INTO `tv_action_log` VALUES ('5', '10', '1', '2130706433', 'Menu', '0', '操作url：/tourism/index.php?s=/admin/menu/del/id/118.html', '1', '1438754498');
INSERT INTO `tv_action_log` VALUES ('6', '10', '1', '2130706433', 'Menu', '119', '操作url：/tourism/index.php?s=/admin/menu/add/pid/0.html', '1', '1438756058');
INSERT INTO `tv_action_log` VALUES ('7', '10', '1', '2130706433', 'Menu', '0', '操作url：/tourism/index.php?s=/admin/menu/del/id/119.html', '1', '1438756097');
INSERT INTO `tv_action_log` VALUES ('8', '10', '1', '2130706433', 'Menu', '120', '操作url：/tourism/index.php?s=/admin/menu/add/pid/0.html', '1', '1438756238');
INSERT INTO `tv_action_log` VALUES ('9', '10', '1', '2130706433', 'Menu', '0', '操作url：/tourism/index.php?s=/admin/menu/del/id/120.html', '1', '1438756262');
INSERT INTO `tv_action_log` VALUES ('10', '10', '1', '2130706433', 'Menu', '121', '操作url：/tourism/index.php?s=/admin/menu/add/pid/0.html', '1', '1438756804');
INSERT INTO `tv_action_log` VALUES ('11', '10', '1', '2130706433', 'Menu', '121', '操作url：/tourism/index.php?s=/admin/menu/edit/id/121.html', '1', '1438756825');
INSERT INTO `tv_action_log` VALUES ('12', '10', '1', '2130706433', 'Menu', '121', '操作url：/tourism/index.php?s=/admin/menu/edit/id/121.html', '1', '1438756853');
INSERT INTO `tv_action_log` VALUES ('13', '10', '1', '2130706433', 'Menu', '2', '操作url：/tourism/index.php?s=/admin/menu/edit/id/2.html', '1', '1438756862');
INSERT INTO `tv_action_log` VALUES ('14', '10', '1', '2130706433', 'Menu', '16', '操作url：/tourism/index.php?s=/admin/menu/edit/id/16.html', '1', '1438756883');
INSERT INTO `tv_action_log` VALUES ('15', '10', '1', '2130706433', 'Menu', '2', '操作url：/tourism/index.php?s=/admin/menu/edit/id/2.html', '1', '1438756896');
INSERT INTO `tv_action_log` VALUES ('16', '10', '1', '2130706433', 'Menu', '2', '操作url：/tourism/index.php?s=/admin/menu/edit/id/2.html', '1', '1438756908');
INSERT INTO `tv_action_log` VALUES ('17', '10', '1', '2130706433', 'Menu', '68', '操作url：/tourism/index.php?s=/admin/menu/edit/id/68.html', '1', '1438756933');
INSERT INTO `tv_action_log` VALUES ('18', '10', '1', '2130706433', 'Menu', '93', '操作url：/tourism/index.php?s=/admin/menu/edit/id/93.html', '1', '1438756946');
INSERT INTO `tv_action_log` VALUES ('19', '10', '1', '2130706433', 'Menu', '102', '操作url：/tourism/index.php?s=/admin/menu/edit/id/102.html', '1', '1438756963');
INSERT INTO `tv_action_log` VALUES ('20', '10', '1', '2130706433', 'Menu', '121', '操作url：/tourism/index.php?s=/admin/menu/edit/id/121.html', '1', '1438756977');
INSERT INTO `tv_action_log` VALUES ('21', '10', '1', '2130706433', 'Menu', '16', '操作url：/tourism/index.php?s=/admin/menu/edit/id/16.html', '1', '1438756989');
INSERT INTO `tv_action_log` VALUES ('22', '10', '1', '2130706433', 'Menu', '68', '操作url：/tourism/index.php?s=/admin/menu/edit/id/68.html', '1', '1438757008');
INSERT INTO `tv_action_log` VALUES ('23', '10', '1', '2130706433', 'Menu', '16', '操作url：/tourism/index.php?s=/admin/menu/edit/id/16.html', '1', '1438757026');
INSERT INTO `tv_action_log` VALUES ('24', '10', '1', '2130706433', 'Menu', '121', '操作url：/tourism/index.php?s=/admin/menu/edit/id/121.html', '1', '1438757033');
INSERT INTO `tv_action_log` VALUES ('25', '10', '1', '2130706433', 'Menu', '2', '操作url：/tourism/index.php?s=/admin/menu/edit/id/2.html', '1', '1438757066');
INSERT INTO `tv_action_log` VALUES ('26', '10', '1', '2130706433', 'Menu', '68', '操作url：/tourism/index.php?s=/admin/menu/edit/id/68.html', '1', '1438757073');
INSERT INTO `tv_action_log` VALUES ('27', '10', '1', '2130706433', 'Menu', '122', '操作url：/tourism/index.php?s=/admin/menu/add/pid/0.html', '1', '1438757202');
INSERT INTO `tv_action_log` VALUES ('28', '1', '26', '2130706433', 'member', '26', '操作url：/tourism/index.php?s=/home/user/login.html', '1', '1438765681');
INSERT INTO `tv_action_log` VALUES ('29', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1438821099');
INSERT INTO `tv_action_log` VALUES ('30', '10', '1', '2130706433', 'Menu', '2', '操作url：/tourism/index.php?s=/admin/menu/edit/id/2.html', '1', '1438821121');
INSERT INTO `tv_action_log` VALUES ('31', '10', '1', '2130706433', 'Menu', '123', '操作url：/tourism/index.php?s=/admin/menu/add/pid/2.html', '1', '1438821302');
INSERT INTO `tv_action_log` VALUES ('32', '10', '1', '2130706433', 'Menu', '124', '操作url：/tourism/index.php?s=/admin/menu/add/pid/2.html', '1', '1438821400');
INSERT INTO `tv_action_log` VALUES ('33', '10', '1', '2130706433', 'Menu', '0', '操作url：/tourism/index.php?s=/admin/menu/del/id/124.html', '1', '1438821767');
INSERT INTO `tv_action_log` VALUES ('34', '10', '1', '2130706433', 'Menu', '0', '操作url：/tourism/index.php?s=/admin/menu/del/id/123.html', '1', '1438822740');
INSERT INTO `tv_action_log` VALUES ('35', '11', '1', '2130706433', 'category', '39', '操作url：/tourism/index.php?s=/admin/category/add.html', '1', '1438822826');
INSERT INTO `tv_action_log` VALUES ('36', '11', '1', '2130706433', 'category', '39', '操作url：/tourism/index.php?s=/admin/category/edit/id/39/pid/0.html', '1', '1438822885');
INSERT INTO `tv_action_log` VALUES ('37', '11', '1', '2130706433', 'category', '40', '操作url：/tourism/index.php?s=/admin/category/add/pid/39.html', '1', '1438822998');
INSERT INTO `tv_action_log` VALUES ('38', '10', '1', '2130706433', 'Menu', '125', '操作url：/tourism/index.php?s=/admin/menu/add/pid/2.html', '1', '1438823375');
INSERT INTO `tv_action_log` VALUES ('39', '10', '1', '2130706433', 'Menu', '125', '操作url：/tourism/index.php?s=/admin/menu/edit/id/125.html', '1', '1438824280');
INSERT INTO `tv_action_log` VALUES ('40', '11', '1', '2130706433', 'category', '40', '操作url：/tourism/index.php?s=/admin/category/edit/id/40/pid/39.html', '1', '1438824887');
INSERT INTO `tv_action_log` VALUES ('41', '11', '1', '2130706433', 'category', '41', '操作url：/tourism/index.php?s=/admin/category/add/pid/40.html', '1', '1438824967');
INSERT INTO `tv_action_log` VALUES ('42', '11', '1', '2130706433', 'category', '40', '操作url：/tourism/index.php?s=/admin/category/edit/id/40/pid/39.html', '1', '1438825032');
INSERT INTO `tv_action_log` VALUES ('43', '11', '1', '2130706433', 'category', '40', '操作url：/tourism/index.php?s=/admin/category/remove/id/40.html', '1', '1438825079');
INSERT INTO `tv_action_log` VALUES ('44', '11', '1', '2130706433', 'category', '41', '操作url：/tourism/index.php?s=/admin/category/edit/id/41/pid/39.html', '1', '1438825091');
INSERT INTO `tv_action_log` VALUES ('45', '11', '1', '2130706433', 'category', '42', '操作url：/tourism/index.php?s=/admin/category/add/pid/39.html', '1', '1438825142');
INSERT INTO `tv_action_log` VALUES ('46', '10', '1', '2130706433', 'Menu', '0', '操作url：/tourism/index.php?s=/admin/menu/del/id/125.html', '1', '1438828568');
INSERT INTO `tv_action_log` VALUES ('47', '10', '1', '2130706433', 'Menu', '17', '操作url：/tourism/index.php?s=/admin/menu/edit/id/17.html', '1', '1438829340');
INSERT INTO `tv_action_log` VALUES ('48', '10', '1', '2130706433', 'Menu', '19', '操作url：/tourism/index.php?s=/admin/menu/edit/id/19.html', '1', '1438829357');
INSERT INTO `tv_action_log` VALUES ('49', '1', '27', '2130706433', 'member', '27', '操作url：/tourism/index.php?s=/home/user/login.html', '1', '1438839332');
INSERT INTO `tv_action_log` VALUES ('50', '10', '1', '2130706433', 'Menu', '126', '操作url：/tourism/index.php?s=/admin/menu/add/pid/16.html', '1', '1438839554');
INSERT INTO `tv_action_log` VALUES ('51', '10', '1', '2130706433', 'Menu', '127', '操作url：/tourism/index.php?s=/admin/menu/add/pid/16.html', '1', '1438841149');
INSERT INTO `tv_action_log` VALUES ('52', '10', '1', '2130706433', 'Menu', '128', '操作url：/tourism/index.php?s=/admin/menu/add/pid/16.html', '1', '1438841509');
INSERT INTO `tv_action_log` VALUES ('53', '10', '1', '2130706433', 'Menu', '0', '操作url：/tourism/index.php?s=/admin/menu/del/id/122.html', '1', '1438841875');
INSERT INTO `tv_action_log` VALUES ('54', '1', '35', '2130706433', 'member', '35', '操作url：/tourism/index.php?s=/home/user/firstpwd.html', '1', '1438854358');
INSERT INTO `tv_action_log` VALUES ('55', '1', '35', '2130706433', 'member', '35', '操作url：/tourism/index.php?s=/home/user/login.html', '1', '1438854861');
INSERT INTO `tv_action_log` VALUES ('56', '1', '36', '2130706433', 'member', '36', '操作url：/tourism/index.php?s=/home/user/firstpwd.html', '1', '1438922075');
INSERT INTO `tv_action_log` VALUES ('57', '1', '36', '2130706433', 'member', '36', '操作url：/tourism/index.php?s=/home/user/login.html', '1', '1438922213');
INSERT INTO `tv_action_log` VALUES ('58', '10', '1', '2130706433', 'Menu', '129', '操作url：/tourism/index.php?s=/admin/menu/add/pid/127.html', '1', '1438932413');
INSERT INTO `tv_action_log` VALUES ('59', '10', '1', '2130706433', 'Menu', '126', '操作url：/tourism/index.php?s=/admin/menu/edit/id/126.html', '1', '1438933953');
INSERT INTO `tv_action_log` VALUES ('60', '10', '1', '2130706433', 'Menu', '130', '操作url：/tourism/index.php?s=/admin/menu/add/pid/126.html', '1', '1438937829');
INSERT INTO `tv_action_log` VALUES ('61', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439168439');
INSERT INTO `tv_action_log` VALUES ('62', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439174755');
INSERT INTO `tv_action_log` VALUES ('63', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439174975');
INSERT INTO `tv_action_log` VALUES ('64', '10', '1', '2130706433', 'Menu', '131', '操作url：/tourism/index.php?s=/admin/menu/add/pid/127.html', '1', '1439198385');
INSERT INTO `tv_action_log` VALUES ('65', '10', '1', '2130706433', 'Menu', '132', '操作url：/tourism/index.php?s=/admin/menu/add/pid/126.html', '1', '1439198450');
INSERT INTO `tv_action_log` VALUES ('66', '10', '1', '2130706433', 'Menu', '130', '操作url：/tourism/index.php?s=/admin/menu/edit/id/130.html', '1', '1439198460');
INSERT INTO `tv_action_log` VALUES ('67', '10', '1', '2130706433', 'Menu', '130', '操作url：/tourism/index.php?s=/admin/menu/edit/id/130.html', '1', '1439199060');
INSERT INTO `tv_action_log` VALUES ('68', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439200584');
INSERT INTO `tv_action_log` VALUES ('69', '1', '41', '2130706433', 'member', '41', '操作url：/tourism/index.php?s=/home/user/login.html', '1', '1439201402');
INSERT INTO `tv_action_log` VALUES ('70', '1', '42', '2130706433', 'member', '42', '操作url：/tourism/index.php?s=/home/user/firstpwd.html', '1', '1439202215');
INSERT INTO `tv_action_log` VALUES ('71', '1', '43', '2130706433', 'member', '43', '操作url：/tourism/index.php?s=/home/user/login.html', '1', '1439202396');
INSERT INTO `tv_action_log` VALUES ('72', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439254711');
INSERT INTO `tv_action_log` VALUES ('73', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/home/user/firstpwd.html', '1', '1439255086');
INSERT INTO `tv_action_log` VALUES ('74', '10', '1', '2130706433', 'Menu', '133', '操作url：/tourism/index.php?s=/admin/menu/add/pid/128.html', '1', '1439256428');
INSERT INTO `tv_action_log` VALUES ('75', '8', '1', '2130706433', 'attribute', '187', '操作url：/tourism/index.php?s=/admin/attribute/update.html', '1', '1439272529');
INSERT INTO `tv_action_log` VALUES ('76', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439281537');
INSERT INTO `tv_action_log` VALUES ('77', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439339861');
INSERT INTO `tv_action_log` VALUES ('78', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439344486');
INSERT INTO `tv_action_log` VALUES ('79', '6', '1', '2130706433', 'config', '20', '操作url：/tourism/index.php?s=/admin/config/edit/id/20.html', '1', '1439346778');
INSERT INTO `tv_action_log` VALUES ('80', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/home/user/login.html', '1', '1439347420');
INSERT INTO `tv_action_log` VALUES ('81', '10', '1', '2130706433', 'Menu', '134', '操作url：/tourism/index.php?s=/admin/menu/add/pid/128.html', '1', '1439351688');
INSERT INTO `tv_action_log` VALUES ('82', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439362188');
INSERT INTO `tv_action_log` VALUES ('83', '6', '1', '2130706433', 'config', '33', '操作url：/tourism/index.php?s=/admin/config/edit/id/33.html', '1', '1439364296');
INSERT INTO `tv_action_log` VALUES ('84', '6', '1', '2130706433', 'config', '35', '操作url：/tourism/index.php?s=/admin/config/edit/id/35.html', '1', '1439364350');
INSERT INTO `tv_action_log` VALUES ('85', '10', '1', '2130706433', 'Menu', '135', '操作url：/tourism/index.php?s=/admin/menu/add/pid/16.html', '1', '1439365716');
INSERT INTO `tv_action_log` VALUES ('86', '10', '1', '2130706433', 'Menu', '135', '操作url：/tourism/index.php?s=/admin/menu/edit/id/135.html', '1', '1439366234');
INSERT INTO `tv_action_log` VALUES ('87', '10', '1', '2130706433', 'Menu', '135', '操作url：/tourism/index.php?s=/admin/menu/edit/id/135.html', '1', '1439366496');
INSERT INTO `tv_action_log` VALUES ('88', '6', '1', '2130706433', 'config', '20', '操作url：/tourism/index.php?s=/admin/config/edit/id/20.html', '1', '1439366637');
INSERT INTO `tv_action_log` VALUES ('89', '6', '1', '2130706433', 'config', '36', '操作url：/tourism/index.php?s=/admin/config/edit/id/36.html', '1', '1439368526');
INSERT INTO `tv_action_log` VALUES ('90', '6', '1', '2130706433', 'config', '37', '操作url：/tourism/index.php?s=/admin/config/edit/id/37.html', '1', '1439368557');
INSERT INTO `tv_action_log` VALUES ('91', '10', '1', '2130706433', 'Menu', '135', '操作url：/tourism/index.php?s=/admin/menu/edit/id/135.html', '1', '1439369029');
INSERT INTO `tv_action_log` VALUES ('92', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439427836');
INSERT INTO `tv_action_log` VALUES ('93', '10', '1', '2130706433', 'Menu', '136', '操作url：/tourism/index.php?s=/admin/menu/add/pid/0.html', '1', '1439435381');
INSERT INTO `tv_action_log` VALUES ('94', '10', '1', '2130706433', 'Menu', '137', '操作url：/tourism/index.php?s=/admin/menu/add/pid/136.html', '1', '1439435480');
INSERT INTO `tv_action_log` VALUES ('95', '10', '1', '2130706433', 'Menu', '136', '操作url：/tourism/index.php?s=/admin/menu/edit/id/136.html', '1', '1439437890');
INSERT INTO `tv_action_log` VALUES ('96', '10', '1', '2130706433', 'Menu', '137', '操作url：/tourism/index.php?s=/admin/menu/edit/id/137.html', '1', '1439438454');
INSERT INTO `tv_action_log` VALUES ('97', '10', '1', '2130706433', 'Menu', '138', '操作url：/tourism/index.php?s=/admin/menu/add/pid/136.html', '1', '1439438522');
INSERT INTO `tv_action_log` VALUES ('98', '10', '1', '2130706433', 'Menu', '139', '操作url：/tourism/index.php?s=/admin/menu/add/pid/68.html', '1', '1439443987');
INSERT INTO `tv_action_log` VALUES ('99', '6', '1', '2130706433', 'config', '41', '操作url：/tourism/index.php?s=/admin/config/edit/id/41.html', '1', '1439444267');
INSERT INTO `tv_action_log` VALUES ('100', '6', '1', '2130706433', 'config', '41', '操作url：/tourism/index.php?s=/admin/config/edit/id/41.html', '1', '1439444276');
INSERT INTO `tv_action_log` VALUES ('101', '6', '1', '2130706433', 'config', '41', '操作url：/tourism/index.php?s=/admin/config/edit/id/41.html', '1', '1439444668');
INSERT INTO `tv_action_log` VALUES ('102', '10', '1', '2130706433', 'Menu', '0', '操作url：/tourism/index.php?s=/admin/menu/del/id/139.html', '1', '1439445221');
INSERT INTO `tv_action_log` VALUES ('103', '10', '1', '2130706433', 'Menu', '140', '操作url：/tourism/index.php?s=/admin/menu/add/pid/138.html', '1', '1439446397');
INSERT INTO `tv_action_log` VALUES ('104', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439450857');
INSERT INTO `tv_action_log` VALUES ('105', '10', '1', '2130706433', 'Menu', '141', '操作url：/tourism/index.php?s=/admin/menu/add/pid/138.html', '1', '1439452722');
INSERT INTO `tv_action_log` VALUES ('106', '10', '1', '2130706433', 'Menu', '142', '操作url：/tourism/index.php?s=/admin/menu/add/pid/137.html', '1', '1439454797');
INSERT INTO `tv_action_log` VALUES ('107', '6', '1', '2130706433', 'config', '39', '操作url：/tourism/index.php?s=/admin/config/edit/id/39.html', '1', '1439460542');
INSERT INTO `tv_action_log` VALUES ('108', '6', '1', '2130706433', 'config', '40', '操作url：/tourism/index.php?s=/admin/config/edit/id/40.html', '1', '1439460578');
INSERT INTO `tv_action_log` VALUES ('109', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439460662');
INSERT INTO `tv_action_log` VALUES ('110', '6', '1', '2130706433', 'config', '35', '操作url：/tourism/index.php?s=/admin/config/edit/id/35.html', '1', '1439460957');
INSERT INTO `tv_action_log` VALUES ('111', '6', '1', '2130706433', 'config', '43', '操作url：/tourism/index.php?s=/admin/config/edit/id/43.html', '1', '1439461256');
INSERT INTO `tv_action_log` VALUES ('112', '6', '1', '2130706433', 'config', '35', '操作url：/tourism/index.php?s=/admin/config/edit/id/35.html', '1', '1439461494');
INSERT INTO `tv_action_log` VALUES ('113', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439515081');
INSERT INTO `tv_action_log` VALUES ('114', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439516205');
INSERT INTO `tv_action_log` VALUES ('115', '6', '1', '2130706433', 'config', '43', '操作url：/tourism/index.php?s=/admin/config/edit/id/43.html', '1', '1439517493');
INSERT INTO `tv_action_log` VALUES ('116', '6', '1', '2130706433', 'config', '35', '操作url：/tourism/index.php?s=/admin/config/edit/id/35.html', '1', '1439520873');
INSERT INTO `tv_action_log` VALUES ('117', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439545555');
INSERT INTO `tv_action_log` VALUES ('118', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439773319');
INSERT INTO `tv_action_log` VALUES ('119', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/home/user/login.html', '1', '1439773333');
INSERT INTO `tv_action_log` VALUES ('120', '1', '43', '2130706433', 'member', '43', '操作url：/tourism/index.php?s=/home/user/login.html', '1', '1439773842');
INSERT INTO `tv_action_log` VALUES ('121', '10', '1', '2130706433', 'Menu', '143', '操作url：/tourism/index.php?s=/admin/menu/add/pid/137.html', '1', '1439777533');
INSERT INTO `tv_action_log` VALUES ('122', '10', '1', '2130706433', 'Menu', '144', '操作url：/tourism/index.php?s=/admin/menu/add/pid/136.html', '1', '1439791358');
INSERT INTO `tv_action_log` VALUES ('123', '10', '1', '2130706433', 'Menu', '144', '操作url：/tourism/index.php?s=/admin/menu/edit/id/144.html', '1', '1439791410');
INSERT INTO `tv_action_log` VALUES ('124', '10', '1', '2130706433', 'Menu', '137', '操作url：/tourism/index.php?s=/admin/menu/edit/id/137.html', '1', '1439791431');
INSERT INTO `tv_action_log` VALUES ('125', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439795906');
INSERT INTO `tv_action_log` VALUES ('126', '1', '45', '2130706433', 'member', '45', '操作url：/tourism/index.php?s=/home/user/firstpwd.html', '1', '1439800401');
INSERT INTO `tv_action_log` VALUES ('127', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439815355');
INSERT INTO `tv_action_log` VALUES ('128', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439860598');
INSERT INTO `tv_action_log` VALUES ('129', '6', '1', '2130706433', 'config', '20', '操作url：/tourism/index.php?s=/admin/config/edit/id/20.html', '1', '1439862411');
INSERT INTO `tv_action_log` VALUES ('130', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/home/user/login.html', '1', '1439865803');
INSERT INTO `tv_action_log` VALUES ('131', '6', '1', '2130706433', 'config', '52', '操作url：/tourism/index.php?s=/admin/config/edit/id/52.html', '1', '1439874030');
INSERT INTO `tv_action_log` VALUES ('132', '6', '1', '2130706433', 'config', '51', '操作url：/tourism/index.php?s=/admin/config/edit/id/51.html', '1', '1439874041');
INSERT INTO `tv_action_log` VALUES ('133', '6', '1', '2130706433', 'config', '52', '操作url：/tourism/index.php?s=/admin/config/edit/id/52.html', '1', '1439874046');
INSERT INTO `tv_action_log` VALUES ('134', '6', '1', '2130706433', 'config', '50', '操作url：/tourism/index.php?s=/admin/config/edit/id/50.html', '1', '1439874052');
INSERT INTO `tv_action_log` VALUES ('135', '6', '1', '2130706433', 'config', '48', '操作url：/tourism/index.php?s=/admin/config/edit/id/48.html', '1', '1439874059');
INSERT INTO `tv_action_log` VALUES ('136', '6', '1', '2130706433', 'config', '47', '操作url：/tourism/index.php?s=/admin/config/edit/id/47.html', '1', '1439874065');
INSERT INTO `tv_action_log` VALUES ('137', '6', '1', '2130706433', 'config', '49', '操作url：/tourism/index.php?s=/admin/config/edit/id/49.html', '1', '1439874082');
INSERT INTO `tv_action_log` VALUES ('138', '10', '1', '2130706433', 'Menu', '145', '操作url：/tourism/index.php?s=/admin/menu/add/pid/136.html', '1', '1439878869');
INSERT INTO `tv_action_log` VALUES ('139', '10', '1', '2130706433', 'Menu', '145', '操作url：/tourism/index.php?s=/admin/menu/edit/id/145.html', '1', '1439879325');
INSERT INTO `tv_action_log` VALUES ('140', '10', '1', '2130706433', 'Menu', '145', '操作url：/tourism/index.php?s=/admin/menu/edit/id/145.html', '1', '1439879356');
INSERT INTO `tv_action_log` VALUES ('141', '10', '1', '2130706433', 'Menu', '146', '操作url：/tourism/index.php?s=/admin/menu/add/pid/145.html', '1', '1439880316');
INSERT INTO `tv_action_log` VALUES ('142', '10', '1', '2130706433', 'Menu', '147', '操作url：/tourism/index.php?s=/admin/menu/add/pid/145.html', '1', '1439890999');
INSERT INTO `tv_action_log` VALUES ('143', '10', '1', '2130706433', 'Menu', '148', '操作url：/tourism/index.php?s=/admin/menu/add/pid/144.html', '1', '1439892995');
INSERT INTO `tv_action_log` VALUES ('146', '10', '1', '2130706433', 'Menu', '150', '操作url：/tourism/index.php?s=/admin/menu/add/pid/121.html', '1', '1439978169');
INSERT INTO `tv_action_log` VALUES ('147', '10', '1', '2130706433', 'Menu', '121', '操作url：/tourism/index.php?s=/admin/menu/edit/id/121.html', '1', '1439978222');
INSERT INTO `tv_action_log` VALUES ('148', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439980749');
INSERT INTO `tv_action_log` VALUES ('149', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439980776');
INSERT INTO `tv_action_log` VALUES ('150', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439980927');
INSERT INTO `tv_action_log` VALUES ('151', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439981073');
INSERT INTO `tv_action_log` VALUES ('152', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439982650');
INSERT INTO `tv_action_log` VALUES ('153', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439982836');
INSERT INTO `tv_action_log` VALUES ('154', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439982989');
INSERT INTO `tv_action_log` VALUES ('155', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439983173');
INSERT INTO `tv_action_log` VALUES ('156', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439985610');
INSERT INTO `tv_action_log` VALUES ('157', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1439985856');
INSERT INTO `tv_action_log` VALUES ('158', '10', '1', '2130706433', 'Menu', '151', '操作url：/tourism/index.php?s=/admin/menu/add/pid/136.html', '1', '1439986814');
INSERT INTO `tv_action_log` VALUES ('159', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1440031941');
INSERT INTO `tv_action_log` VALUES ('160', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1440116342');
INSERT INTO `tv_action_log` VALUES ('161', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440125195');
INSERT INTO `tv_action_log` VALUES ('162', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440127033');
INSERT INTO `tv_action_log` VALUES ('163', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440134926');
INSERT INTO `tv_action_log` VALUES ('164', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440135107');
INSERT INTO `tv_action_log` VALUES ('165', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440135359');
INSERT INTO `tv_action_log` VALUES ('166', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440135394');
INSERT INTO `tv_action_log` VALUES ('167', '1', '41', '2130706433', 'member', '41', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440135510');
INSERT INTO `tv_action_log` VALUES ('168', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1440138230');
INSERT INTO `tv_action_log` VALUES ('169', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440138296');
INSERT INTO `tv_action_log` VALUES ('170', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440138355');
INSERT INTO `tv_action_log` VALUES ('171', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440138366');
INSERT INTO `tv_action_log` VALUES ('172', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440138413');
INSERT INTO `tv_action_log` VALUES ('173', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440138445');
INSERT INTO `tv_action_log` VALUES ('174', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440138460');
INSERT INTO `tv_action_log` VALUES ('175', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440138482');
INSERT INTO `tv_action_log` VALUES ('176', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440138503');
INSERT INTO `tv_action_log` VALUES ('177', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440138533');
INSERT INTO `tv_action_log` VALUES ('178', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440138549');
INSERT INTO `tv_action_log` VALUES ('179', '1', '44', '2130706433', 'member', '44', '操作url：/tourism/index.php?s=/facilitator/public/login.html', '1', '1440138588');
INSERT INTO `tv_action_log` VALUES ('180', '1', '41', '2130706433', 'member', '41', '操作url：/tourism/index.php?s=/home/user/login.html', '1', '1440139544');
INSERT INTO `tv_action_log` VALUES ('181', '10', '1', '2130706433', 'Menu', '162', '操作url：/index.php?s=/admin/menu/add/pid/151.html', '1', '1440146013');
INSERT INTO `tv_action_log` VALUES ('182', '10', '1', '2130706433', 'Menu', '163', '操作url：/index.php?s=/admin/menu/add/pid/151.html', '1', '1440146047');
INSERT INTO `tv_action_log` VALUES ('183', '10', '1', '2130706433', 'Menu', '164', '操作url：/index.php?s=/admin/menu/add/pid/151.html', '1', '1440146068');
INSERT INTO `tv_action_log` VALUES ('184', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1440146459');
INSERT INTO `tv_action_log` VALUES ('185', '1', '1', '2130706433', 'member', '1', '操作url：/index.php?s=/public/login.html', '1', '1440213454');
INSERT INTO `tv_action_log` VALUES ('186', '1', '1', '2130706433', 'member', '1', '操作url：/tourism/index.php?s=/admin/public/login.html', '1', '1440221740');
INSERT INTO `tv_action_log` VALUES ('187', '1', '1', '2130706433', 'member', '1', '操作url：/index.php?s=/public/login.html', '1', '1440223533');
INSERT INTO `tv_action_log` VALUES ('188', '1', '47', '2130706433', 'member', '47', '操作url：/index.php?s=%2Fhome%2Fuser%2Fregister', '1', '1440232065');
INSERT INTO `tv_action_log` VALUES ('189', '1', '48', '2130706433', 'member', '48', '操作url：/index.php?s=%2Fhome%2Fuser%2Fregister', '1', '1440233679');
INSERT INTO `tv_action_log` VALUES ('190', '1', '48', '2130706433', 'member', '48', '操作url：/index.php?s=%2Fhome%2Fuser%2Flogin', '1', '1440233717');
INSERT INTO `tv_action_log` VALUES ('191', '1', '48', '2130706433', 'member', '48', '操作url：/index.php?s=%2Fhome%2Fuser%2Flogin', '1', '1440233729');
INSERT INTO `tv_action_log` VALUES ('192', '1', '48', '1903434771', 'member', '48', '操作url：/index.php?s=%2Fhome%2Fuser%2Flogin', '1', '1440235545');
INSERT INTO `tv_action_log` VALUES ('193', '1', '48', '1903434771', 'member', '48', '操作url：/index.php?s=%2Fhome%2Fuser%2Flogin', '1', '1440235758');
INSERT INTO `tv_action_log` VALUES ('194', '1', '48', '1903434771', 'member', '48', '操作url：/index.php?s=%2Fhome%2Fuser%2Flogin', '1', '1440236755');
INSERT INTO `tv_action_log` VALUES ('195', '1', '48', '1903434771', 'member', '48', '操作url：/index.php?s=%2Fhome%2Fuser%2Flogin', '1', '1440249136');
INSERT INTO `tv_action_log` VALUES ('196', '1', '48', '1903434771', 'member', '48', '操作url：/index.php?s=%2Fhome%2Fuser%2Flogin', '1', '1440249145');
INSERT INTO `tv_action_log` VALUES ('197', '1', '48', '1903434771', 'member', '48', '操作url：/index.php?s=/home/user/login', '1', '1440249207');
INSERT INTO `tv_action_log` VALUES ('198', '1', '48', '1903434771', 'member', '48', '操作url：/index.php?s=/home/user/login', '1', '1440249333');
INSERT INTO `tv_action_log` VALUES ('199', '1', '1', '2130706433', 'member', '1', '操作url：/index.php?s=/public/login.html', '1', '1440373484');
INSERT INTO `tv_action_log` VALUES ('200', '1', '1', '2130706433', 'member', '1', '操作url：/index.php?s=/admin/public/login.html', '1', '1440378877');
INSERT INTO `tv_action_log` VALUES ('201', '10', '1', '2130706433', 'Menu', '0', '操作url：/index.php?s=/menu/del.html', '1', '1440382876');
INSERT INTO `tv_action_log` VALUES ('202', '1', '44', '2130706433', 'member', '44', '操作url：/index.php?s=/facilitator/public/login.html', '1', '1440383789');
INSERT INTO `tv_action_log` VALUES ('203', '1', '44', '2130706433', 'member', '44', '操作url：/index.php?s=/facilitator/public/login.html', '1', '1440386425');
INSERT INTO `tv_action_log` VALUES ('204', '1', '1', '1903434771', 'member', '1', '操作url：/index.php?s=/public/login.html', '1', '1440386664');
INSERT INTO `tv_action_log` VALUES ('205', '1', '1', '2130706433', 'member', '1', '操作url：/index.php?s=/public/login.html', '1', '1440387316');
INSERT INTO `tv_action_log` VALUES ('206', '1', '48', '2130706433', 'member', '48', '操作url：/index.php?s=%2Fhome%2Fuser%2Flogin', '1', '1440404744');
INSERT INTO `tv_action_log` VALUES ('207', '1', '1', '1901745056', 'member', '1', '操作url：/index.php?s=/public/login.html', '1', '1440405429');
INSERT INTO `tv_action_log` VALUES ('208', '10', '1', '2130706433', 'Menu', '165', '操作url：/index.php?s=/menu/add/pid/2.html', '1', '1440466728');
INSERT INTO `tv_action_log` VALUES ('209', '10', '1', '2130706433', 'Menu', '166', '操作url：/index.php?s=/menu/add/pid/2.html', '1', '1440466801');
INSERT INTO `tv_action_log` VALUES ('210', '11', '1', '2130706433', 'category', '41', '操作url：/index.php?s=/category/remove/id/41.html', '1', '1440480029');
INSERT INTO `tv_action_log` VALUES ('211', '11', '1', '2130706433', 'category', '42', '操作url：/index.php?s=/category/remove/id/42.html', '1', '1440480033');
INSERT INTO `tv_action_log` VALUES ('212', '11', '1', '2130706433', 'category', '39', '操作url：/index.php?s=/category/remove/id/39.html', '1', '1440480039');
INSERT INTO `tv_action_log` VALUES ('213', '11', '1', '2130706433', 'category', '4', '操作url：/index.php?s=/category/remove/id/4.html', '1', '1440480044');
INSERT INTO `tv_action_log` VALUES ('214', '11', '1', '2130706433', 'category', '3', '操作url：/index.php?s=/category/remove/id/3.html', '1', '1440480048');
INSERT INTO `tv_action_log` VALUES ('215', '11', '1', '2130706433', 'category', '2', '操作url：/index.php?s=/category/remove/id/2.html', '1', '1440480052');
INSERT INTO `tv_action_log` VALUES ('216', '11', '1', '2130706433', 'category', '1', '操作url：/index.php?s=/category/remove/id/1.html', '1', '1440480055');
INSERT INTO `tv_action_log` VALUES ('217', '10', '1', '2005438120', 'Menu', '0', '操作url：/index.php?s=/menu/del/id/3.html', '1', '1441002211');
INSERT INTO `tv_action_log` VALUES ('218', '10', '1', '2005438120', 'Menu', '0', '操作url：/index.php?s=/menu/del/id/13.html', '1', '1441002217');
INSERT INTO `tv_action_log` VALUES ('219', '11', '1', '2005438120', 'category', '43', '操作url：/index.php?s=/category/add.html', '1', '1441002321');
INSERT INTO `tv_action_log` VALUES ('220', '11', '1', '2005438120', 'category', '43', '操作url：/index.php?s=/category/remove/id/43.html', '1', '1441002370');
INSERT INTO `tv_action_log` VALUES ('221', '10', '1', '2130706433', 'Menu', '167', '操作url：/index.php?s=/menu/add/pid/151.html', '1', '1441008287');
INSERT INTO `tv_action_log` VALUES ('222', '10', '1', '2130706433', 'Menu', '163', '操作url：/index.php?s=/menu/edit/id/163.html', '1', '1441008319');
INSERT INTO `tv_action_log` VALUES ('223', '10', '1', '2130706433', 'Menu', '168', '操作url：/index.php?s=/menu/add/pid/2.html', '1', '1441014572');
INSERT INTO `tv_action_log` VALUES ('224', '10', '1', '2130706433', 'Menu', '169', '操作url：/index.php?s=/menu/add/pid/168.html', '1', '1441074421');
INSERT INTO `tv_action_log` VALUES ('225', '11', '1', '992491476', 'category', '44', '操作url：/index.php?s=/category/add.html', '1', '1441184636');
INSERT INTO `tv_action_log` VALUES ('226', '11', '1', '2130706433', 'category', '44', '操作url：/index.php?s=/category/remove/id/44.html', '1', '1441189280');
INSERT INTO `tv_action_log` VALUES ('227', '10', '1', '2130706433', 'Menu', '170', '操作url：/index.php?s=/menu/add/pid/2.html', '1', '1441423740');
INSERT INTO `tv_action_log` VALUES ('228', '10', '1', '2130706433', 'Menu', '171', '操作url：/index.php?s=/menu/add/pid/170.html', '1', '1441434109');
INSERT INTO `tv_action_log` VALUES ('229', '10', '1', '2130706433', 'Menu', '171', '操作url：/index.php?s=/menu/edit/id/171.html', '1', '1441434154');
INSERT INTO `tv_action_log` VALUES ('230', '10', '1', '2130706433', 'Menu', '2', '操作url：/index.php?s=/menu/edit/id/2.html', '1', '1441440931');
INSERT INTO `tv_action_log` VALUES ('231', '10', '1', '2130706433', 'Menu', '0', '操作url：/index.php?s=/menu/del/id/93.html', '1', '1441446361');
INSERT INTO `tv_action_log` VALUES ('232', '10', '1', '2130706433', 'Menu', '0', '操作url：/index.php?s=/menu/del/id/43.html', '1', '1441446370');
INSERT INTO `tv_action_log` VALUES ('233', '10', '1', '1902548597', 'Menu', '172', '操作url：/index.php?s=/menu/add/pid/168.html', '1', '1441502644');
INSERT INTO `tv_action_log` VALUES ('234', '10', '1', '2130706433', 'Menu', '168', '操作url：/index.php?s=/menu/edit/id/168.html', '1', '1441587668');
INSERT INTO `tv_action_log` VALUES ('235', '10', '1', '2130706433', 'Menu', '170', '操作url：/index.php?s=/menu/edit/id/170.html', '1', '1441587681');
INSERT INTO `tv_action_log` VALUES ('236', '10', '1', '2130706433', 'Menu', '173', '操作url：/index.php?s=/menu/add/pid/2.html', '1', '1441593349');
INSERT INTO `tv_action_log` VALUES ('237', '10', '1', '2130706433', 'Menu', '165', '操作url：/index.php?s=/menu/edit/id/165.html', '1', '1441593358');
INSERT INTO `tv_action_log` VALUES ('238', '10', '1', '2130706433', 'Menu', '166', '操作url：/index.php?s=/menu/edit/id/166.html', '1', '1441593366');
INSERT INTO `tv_action_log` VALUES ('239', '10', '1', '2130706433', 'Menu', '173', '操作url：/index.php?s=/menu/edit/id/173.html', '1', '1441593449');
INSERT INTO `tv_action_log` VALUES ('240', '10', '1', '2130706433', 'Menu', '174', '操作url：/index.php?s=/menu/add/pid/0.html', '1', '1441681918');
INSERT INTO `tv_action_log` VALUES ('241', '10', '1', '2130706433', 'Menu', '175', '操作url：/index.php?s=/menu/add/pid/174.html', '1', '1441681964');
INSERT INTO `tv_action_log` VALUES ('242', '10', '1', '2130706433', 'Menu', '176', '操作url：/index.php?s=/menu/add/pid/175.html', '1', '1441695569');
INSERT INTO `tv_action_log` VALUES ('243', '10', '1', '2130706433', 'Menu', '177', '操作url：/index.php?s=/menu/add/pid/2.html', '1', '1441939248');
INSERT INTO `tv_action_log` VALUES ('244', '10', '1', '2130706433', 'Menu', '170', '操作url：/index.php?s=/menu/edit/id/170.html', '1', '1441939274');
INSERT INTO `tv_action_log` VALUES ('245', '10', '1', '2130706433', 'Menu', '178', '操作url：/index.php?s=/menu/add/pid/150.html', '1', '1442041832');

-- -----------------------------
-- Table structure for `tv_addons`
-- -----------------------------
DROP TABLE IF EXISTS `tv_addons`;
CREATE TABLE `tv_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `tv_addons`
-- -----------------------------
INSERT INTO `tv_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"4\",\"editor_wysiwyg\":\"2\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0');
INSERT INTO `tv_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `tv_addons` VALUES ('3', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512022', '0');
INSERT INTO `tv_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `tv_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `tv_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `tv_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"\",\"comment_short_name_duoshuo\":\"\",\"comment_data_list_duoshuo\":\"\"}', 'thinkphp', '0.1', '1380273962', '0');

-- -----------------------------
-- Table structure for `tv_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `tv_attachment`;
CREATE TABLE `tv_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表\r\n@author   麦当苗儿\r\n@version  2013-06-19';


-- -----------------------------
-- Table structure for `tv_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `tv_attribute`;
CREATE TABLE `tv_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=188 DEFAULT CHARSET=utf8 COMMENT='模型属性表\r\n@author huajie';

-- -----------------------------
-- Records of `tv_attribute`
-- -----------------------------
INSERT INTO `tv_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233');
INSERT INTO `tv_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '\'\'', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233');
INSERT INTO `tv_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '\'\'', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233');
INSERT INTO `tv_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233');
INSERT INTO `tv_attribute` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '\'\'', '', '1', '', '1', '0', '1', '1383894927', '1383891233');
INSERT INTO `tv_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233');
INSERT INTO `tv_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233');
INSERT INTO `tv_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233');
INSERT INTO `tv_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233');
INSERT INTO `tv_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '1:列表推荐\r\n2:频道页推荐\r\n4:首页推荐', '1', '0', '1', '1383895640', '1383891233');
INSERT INTO `tv_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233');
INSERT INTO `tv_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233');
INSERT INTO `tv_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '0', '', '1', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1383896023', '1383891233');
INSERT INTO `tv_attribute` VALUES ('14', 'dateline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1383895812', '1383891233');
INSERT INTO `tv_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895825', '1383891233');
INSERT INTO `tv_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233');
INSERT INTO `tv_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233');
INSERT INTO `tv_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233');
INSERT INTO `tv_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233');
INSERT INTO `tv_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233');
INSERT INTO `tv_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233');
INSERT INTO `tv_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233');
INSERT INTO `tv_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243');
INSERT INTO `tv_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243');
INSERT INTO `tv_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '\'\'', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243');
INSERT INTO `tv_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243');
INSERT INTO `tv_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '1', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1383896487', '1383891252');
INSERT INTO `tv_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252');
INSERT INTO `tv_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '\'\'', '', '1', '', '3', '0', '1', '1383896429', '1383891252');
INSERT INTO `tv_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252');
INSERT INTO `tv_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252');
INSERT INTO `tv_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252');
INSERT INTO `tv_attribute` VALUES ('33', 'name', '行为唯一标识', 'char(30) NOT NULL ', 'string', '\'\'', '标识唯一', '1', '', '4', '0', '1', '1383897155', '1383891262');
INSERT INTO `tv_attribute` VALUES ('34', 'title', '行为说明', 'char(80) NOT NULL ', 'textarea', '\'\'', '', '1', '', '4', '0', '1', '1383897133', '1383891262');
INSERT INTO `tv_attribute` VALUES ('35', 'remark', '行为描述', 'char(140) NOT NULL ', 'textarea', '\'\'', '', '1', '', '4', '0', '1', '1383897032', '1383891262');
INSERT INTO `tv_attribute` VALUES ('36', 'rule', '行为规则', 'text NOT NULL ', 'textarea', '', '', '1', '', '4', '0', '1', '1383897011', '1383891262');
INSERT INTO `tv_attribute` VALUES ('37', 'type', '类型', 'tinyint(2) unsigned NOT NULL ', 'select', '1', '', '1', '1:系统\r\n2:用户', '4', '0', '1', '1383896955', '1383891262');
INSERT INTO `tv_attribute` VALUES ('38', 'status', '状态', 'tinyint(2) NOT NULL ', 'radio', '0', '', '1', '-1:已删除\r\n0:禁用\r\n1:正常', '4', '0', '1', '1383896868', '1383891262');
INSERT INTO `tv_attribute` VALUES ('39', 'update_time', '修改时间', 'int(11) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '4', '0', '1', '1383896756', '1383891262');
INSERT INTO `tv_attribute` VALUES ('40', 'action_id', '行为id', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '5', '0', '1', '1383897599', '1383891340');
INSERT INTO `tv_attribute` VALUES ('41', 'user_id', '执行用户id', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '5', '0', '1', '1383897587', '1383891340');
INSERT INTO `tv_attribute` VALUES ('42', 'action_ip', '执行行为者ip', 'bigint(20) NOT NULL ', 'string', '', '', '1', '', '5', '0', '1', '1383897570', '1383891341');
INSERT INTO `tv_attribute` VALUES ('43', 'model', '触发行为的表', 'varchar(50) NOT NULL ', 'string', '\'\'', '', '1', '', '5', '0', '1', '1383897523', '1383891341');
INSERT INTO `tv_attribute` VALUES ('44', 'record_id', '触发行为的数据id', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '5', '0', '1', '1383897512', '1383891341');
INSERT INTO `tv_attribute` VALUES ('45', 'remark', '日志备注', 'varchar(255) NOT NULL ', 'textarea', '\'\'', '', '1', '', '5', '0', '1', '1383897352', '1383891341');
INSERT INTO `tv_attribute` VALUES ('46', 'status', '状态', 'tinyint(2) NOT NULL ', 'checkbox', '1', '', '1', '-1:已删除\r\n0:禁用\r\n1:正常', '5', '0', '1', '1383897331', '1383891341');
INSERT INTO `tv_attribute` VALUES ('47', 'create_time', '执行行为的时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '5', '0', '1', '1383897274', '1383891341');
INSERT INTO `tv_attribute` VALUES ('48', 'name', '插件名或标识', 'varchar(40) NOT NULL ', 'string', '', '区分大小写', '1', '', '6', '0', '1', '1383898041', '1383891396');
INSERT INTO `tv_attribute` VALUES ('49', 'title', '中文名', 'varchar(20) NOT NULL ', 'string', '\'\'', '', '1', '', '6', '0', '1', '1383898024', '1383891396');
INSERT INTO `tv_attribute` VALUES ('50', 'description', '插件描述', 'text NULL ', 'editor', '', '', '1', '', '6', '0', '1', '1383897787', '1383891396');
INSERT INTO `tv_attribute` VALUES ('51', 'status', '状态', 'tinyint(1) NOT NULL ', 'radio', '1', '', '1', '1:启用\r\n0:禁用\r\n-1:损坏', '6', '0', '1', '1383897771', '1383891396');
INSERT INTO `tv_attribute` VALUES ('52', 'config', '配置', 'text NULL ', 'textarea', '', '序列化存放', '1', '', '6', '0', '1', '1383897747', '1383891396');
INSERT INTO `tv_attribute` VALUES ('53', 'author', '作者', 'varchar(40) NULL ', 'string', '\'\'', '', '1', '', '6', '0', '1', '1383897731', '1383891396');
INSERT INTO `tv_attribute` VALUES ('54', 'version', '版本号', 'varchar(20) NULL ', 'string', '\'\'', '', '1', '', '6', '0', '1', '1383897715', '1383891396');
INSERT INTO `tv_attribute` VALUES ('55', 'create_time', '安装时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '6', '0', '1', '1383897704', '1383891396');
INSERT INTO `tv_attribute` VALUES ('56', 'has_adminlist', '是否有后台列表', 'tinyint(1) unsigned NOT NULL ', 'bool', '0', '', '1', '1:有后台列表\r\n0:无后台列表', '6', '0', '1', '1383897682', '1383891396');
INSERT INTO `tv_attribute` VALUES ('57', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '7', '0', '1', '1383900457', '1383891410');
INSERT INTO `tv_attribute` VALUES ('58', 'title', '附件显示名', 'char(30) NOT NULL ', 'string', '\'\'', '', '1', '', '7', '0', '1', '1383900447', '1383891410');
INSERT INTO `tv_attribute` VALUES ('59', 'type', '附件类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '1', '0:目录\r\n1:外链\r\n2:文件', '7', '0', '1', '1383900433', '1383891410');
INSERT INTO `tv_attribute` VALUES ('60', 'source', '资源ID', 'int(10) unsigned NOT NULL ', 'num', '0', '0-目录， 大于0-当资源为文件时其值为file_id,当资源为外链时其值为link_id', '1', '', '7', '0', '1', '1383900405', '1383891410');
INSERT INTO `tv_attribute` VALUES ('61', 'record_id', '关联记录ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '7', '0', '1', '1383900384', '1383891410');
INSERT INTO `tv_attribute` VALUES ('62', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '7', '0', '1', '1383900376', '1383891410');
INSERT INTO `tv_attribute` VALUES ('63', 'size', '附件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '当附件为目录或外链时，该值为0', '1', '', '7', '0', '1', '1383900367', '1383891410');
INSERT INTO `tv_attribute` VALUES ('64', 'dir', '上级目录ID', 'int(12) unsigned NOT NULL ', 'num', '0', '0-根目录', '1', '', '7', '0', '1', '1383900283', '1383891410');
INSERT INTO `tv_attribute` VALUES ('65', 'sort', '排序', 'int(8) unsigned NOT NULL ', 'num', '0', '', '1', '', '7', '0', '1', '1383900264', '1383891410');
INSERT INTO `tv_attribute` VALUES ('66', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '7', '0', '1', '1383900256', '1383891410');
INSERT INTO `tv_attribute` VALUES ('67', 'update_time', '更新时间', 'int(11) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '7', '0', '1', '1383900249', '1383891410');
INSERT INTO `tv_attribute` VALUES ('68', 'status', '状态', 'tinyint(1) NOT NULL ', 'select', '0', '', '1', '-1:已删除\r\n0:禁用\r\n1:正常', '7', '0', '1', '1383900239', '1383891410');
INSERT INTO `tv_attribute` VALUES ('69', 'name', '字段名', 'varchar(30) NOT NULL ', 'string', '\'\'', '', '1', '', '8', '0', '1', '1383901456', '1383891441');
INSERT INTO `tv_attribute` VALUES ('70', 'title', '字段注释', 'varchar(100) NOT NULL ', 'textarea', '\'\'', '', '1', '', '8', '0', '1', '1383901439', '1383891441');
INSERT INTO `tv_attribute` VALUES ('71', 'field', '字段定义', 'varchar(100) NOT NULL ', 'string', '\'\'', '', '1', '', '8', '0', '1', '1383901414', '1383891441');
INSERT INTO `tv_attribute` VALUES ('72', 'type', '数据类型', 'varchar(20) NOT NULL ', 'string', '\'\'', '用于表单展示', '1', '', '8', '0', '1', '1383901399', '1383891441');
INSERT INTO `tv_attribute` VALUES ('73', 'value', '字段默认值', 'varchar(100) NOT NULL ', 'string', '\'\'', '', '1', '', '8', '0', '1', '1383901261', '1383891441');
INSERT INTO `tv_attribute` VALUES ('74', 'remark', '备注', 'varchar(100) NOT NULL ', 'textarea', '\'\'', '', '1', '', '8', '0', '1', '1383901247', '1383891441');
INSERT INTO `tv_attribute` VALUES ('75', 'is_show', '是否显示', 'tinyint(1) unsigned NOT NULL ', 'select', '1', '', '1', '0:不显示\r\n1:始终显示\r\n2:新增时显示\r\n3:编辑时显示', '8', '0', '1', '1383901027', '1383891441');
INSERT INTO `tv_attribute` VALUES ('76', 'extra', '参数', 'varchar(255) NOT NULL ', 'textarea', '\'\'', '表单显示', '1', '', '8', '0', '1', '1383900964', '1383891441');
INSERT INTO `tv_attribute` VALUES ('77', 'model_id', '模型id', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '8', '0', '1', '1383900862', '1383891441');
INSERT INTO `tv_attribute` VALUES ('78', 'is_must', '是否必填', 'tinyint(1) unsigned NOT NULL ', 'bool', '0', '', '1', '0:否\r\n1:是', '8', '0', '1', '1383900852', '1383891441');
INSERT INTO `tv_attribute` VALUES ('79', 'status', '状态', 'tinyint(2) NOT NULL ', 'select', '0', '', '1', '-1:已删除\r\n0:禁用\r\n1:正常', '8', '0', '1', '1383900822', '1383891441');
INSERT INTO `tv_attribute` VALUES ('80', 'update_time', '更新时间', 'int(11) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '8', '0', '1', '1383900771', '1383891441');
INSERT INTO `tv_attribute` VALUES ('81', 'create_time', '创建时间', 'int(11) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '8', '0', '1', '1383900759', '1383891441');
INSERT INTO `tv_attribute` VALUES ('82', 'name', '标志', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '9', '0', '1', '1383901549', '1383891453');
INSERT INTO `tv_attribute` VALUES ('83', 'title', '标题', 'varchar(50) NOT NULL ', 'string', '', '', '1', '', '9', '0', '1', '1383891453', '1383891453');
INSERT INTO `tv_attribute` VALUES ('84', 'pid', '上级分类ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '9', '0', '1', '1383901524', '1383891453');
INSERT INTO `tv_attribute` VALUES ('85', 'sort', '排序（同级有效）', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '9', '0', '1', '1383902180', '1383891453');
INSERT INTO `tv_attribute` VALUES ('86', 'list_row', '列表每页行数', 'tinyint(3) unsigned NOT NULL ', 'num', '10', '', '1', '', '9', '0', '1', '1383902154', '1383891453');
INSERT INTO `tv_attribute` VALUES ('87', 'meta_title', 'SEO的网页标题', 'varchar(50) NOT NULL ', 'string', '\'\'', '', '1', '', '9', '0', '1', '1383902118', '1383891453');
INSERT INTO `tv_attribute` VALUES ('88', 'keywords', '关键字', 'varchar(255) NOT NULL ', 'textarea', '\'\'', '', '1', '', '9', '0', '1', '1383902106', '1383891453');
INSERT INTO `tv_attribute` VALUES ('89', 'description', '描述', 'varchar(255) NOT NULL ', 'textarea', '\'\'', '', '1', '', '9', '0', '1', '1383902089', '1383891453');
INSERT INTO `tv_attribute` VALUES ('90', 'template_index', '频道页模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '9', '0', '1', '1383891453', '1383891453');
INSERT INTO `tv_attribute` VALUES ('91', 'template_lists', '列表页模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '9', '0', '1', '1383891453', '1383891453');
INSERT INTO `tv_attribute` VALUES ('92', 'template_detail', '详情页模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '9', '0', '1', '1383891453', '1383891453');
INSERT INTO `tv_attribute` VALUES ('93', 'template_edit', '编辑页模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '9', '0', '1', '1383891453', '1383891453');
INSERT INTO `tv_attribute` VALUES ('94', 'model', '关联模型', 'varchar(100) NOT NULL ', 'string', '\'\'', '', '1', '', '9', '0', '1', '1383902070', '1383891453');
INSERT INTO `tv_attribute` VALUES ('95', 'type', '允许发布的内容类型', 'varchar(100) NOT NULL ', 'radio', '\'\'', '', '1', '1:目录\r\n2:主题\r\n3:段落', '9', '0', '1', '1383902026', '1383891453');
INSERT INTO `tv_attribute` VALUES ('96', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID', '1', '', '9', '0', '1', '1383902007', '1383891453');
INSERT INTO `tv_attribute` VALUES ('97', 'allow_publish', '是否允许发布内容', 'tinyint(3) unsigned NOT NULL ', 'radio', '0', '（0-不允许，1-允许）', '1', '0:不允许\r\n1:仅允许后台\r\n2:允许前后台', '9', '0', '1', '1385343315', '1383891453');
INSERT INTO `tv_attribute` VALUES ('98', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '0', '', '1', '0:所有人可见\r\n1:管理员可见\r\n2:不可见', '9', '0', '1', '1383900863', '1383891453');
INSERT INTO `tv_attribute` VALUES ('99', 'reply', '是否允许回复', 'tinyint(3) unsigned NOT NULL ', 'radio', '0', '', '1', '1:允许\r\n0:不允许', '9', '0', '1', '1383900823', '1383891453');
INSERT INTO `tv_attribute` VALUES ('100', 'check', '发布的文章是否需要审核', 'tinyint(3) unsigned NOT NULL ', 'radio', '0', '0：不需要，1：需要', '1', '0:不需要\r\n1:需要', '9', '0', '1', '1383901976', '1383891453');
INSERT INTO `tv_attribute` VALUES ('101', 'reply_model', '', 'varchar(100) NOT NULL ', 'string', '\'\'', '', '1', '', '9', '0', '1', '1383901959', '1383891453');
INSERT INTO `tv_attribute` VALUES ('102', 'extend', '扩展设置', 'text NOT NULL ', 'textarea', '', 'JSON数据', '1', '', '9', '0', '1', '1383901931', '1383891453');
INSERT INTO `tv_attribute` VALUES ('103', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '9', '0', '1', '1383900444', '1383891453');
INSERT INTO `tv_attribute` VALUES ('104', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '9', '0', '1', '1383900436', '1383891453');
INSERT INTO `tv_attribute` VALUES ('105', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '-1-删除，0-禁用，1-正常，2-待审核', '1', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核', '9', '0', '1', '1383900393', '1383891453');
INSERT INTO `tv_attribute` VALUES ('106', 'pid', '上级频道ID', 'int(10) unsigned NOT NULL ', 'string', '0', '', '1', '', '10', '0', '1', '1383891460', '1383891460');
INSERT INTO `tv_attribute` VALUES ('107', 'title', '频道标题', 'char(30) NOT NULL ', 'string', '', '', '1', '', '10', '0', '1', '1383891460', '1383891460');
INSERT INTO `tv_attribute` VALUES ('108', 'url', '频道连接', 'char(100) NOT NULL ', 'string', '', '', '1', '', '10', '0', '1', '1383891460', '1383891460');
INSERT INTO `tv_attribute` VALUES ('109', 'sort', '导航排序', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '10', '0', '1', '1383900256', '1383891460');
INSERT INTO `tv_attribute` VALUES ('110', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '10', '0', '1', '1383900247', '1383891460');
INSERT INTO `tv_attribute` VALUES ('111', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '10', '0', '1', '1383900239', '1383891460');
INSERT INTO `tv_attribute` VALUES ('112', 'status', '状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '1', '1:正常\r\n0:禁用', '10', '0', '1', '1383900228', '1383891460');
INSERT INTO `tv_attribute` VALUES ('113', 'name', '配置名称', 'varchar(30) NOT NULL ', 'string', '\'\'', '', '1', '', '11', '0', '1', '1383901902', '1383891466');
INSERT INTO `tv_attribute` VALUES ('114', 'type', '配置类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '11', '0', '1', '1383901877', '1383891466');
INSERT INTO `tv_attribute` VALUES ('115', 'title', '配置说明', 'varchar(50) NOT NULL ', 'string', '\'\'', '', '1', '', '11', '0', '1', '1383901743', '1383891466');
INSERT INTO `tv_attribute` VALUES ('116', 'group', '配置分组', 'tinyint(3) unsigned NOT NULL ', 'radio', '0', '0-无分组，1-基本设置', '1', '0:无分组\r\n1:基本设置', '11', '0', '1', '1383901731', '1383891466');
INSERT INTO `tv_attribute` VALUES ('117', 'extra', '配置值', 'varchar(255) NOT NULL ', 'textarea', '\'\'', '', '1', '', '11', '0', '1', '1383901707', '1383891466');
INSERT INTO `tv_attribute` VALUES ('118', 'remark', '配置说明', 'varchar(100) NOT NULL ', 'textarea', '', '', '1', '', '11', '0', '1', '1383901666', '1383891466');
INSERT INTO `tv_attribute` VALUES ('119', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '11', '0', '1', '1383899711', '1383891466');
INSERT INTO `tv_attribute` VALUES ('120', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '11', '0', '1', '1383899704', '1383891466');
INSERT INTO `tv_attribute` VALUES ('121', 'status', '状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '1', '1:启用\r\n0:禁用', '11', '0', '1', '1383901650', '1383891466');
INSERT INTO `tv_attribute` VALUES ('122', 'value', '配置值', 'text NOT NULL ', 'textarea', '', '', '1', '', '11', '0', '1', '1383901634', '1383891466');
INSERT INTO `tv_attribute` VALUES ('123', 'sort', '排序', 'smallint(3) unsigned NOT NULL ', 'num', '0', '', '1', '', '11', '0', '1', '1383901610', '1383891467');
INSERT INTO `tv_attribute` VALUES ('124', 'name', '原始文件名', 'char(30) NOT NULL ', 'string', '\'\'', '', '1', '', '12', '0', '1', '1383902322', '1383891474');
INSERT INTO `tv_attribute` VALUES ('125', 'savename', '保存名称', 'char(20) NOT NULL ', 'string', '\'\'', '', '1', '', '12', '0', '1', '1383902308', '1383891474');
INSERT INTO `tv_attribute` VALUES ('126', 'savepath', '文件保存路径', 'char(30) NOT NULL ', 'string', '\'\'', '', '1', '', '12', '0', '1', '1383902297', '1383891474');
INSERT INTO `tv_attribute` VALUES ('127', 'ext', '文件后缀', 'char(5) NOT NULL ', 'string', '\'\'', '', '1', '', '12', '0', '1', '1383902285', '1383891474');
INSERT INTO `tv_attribute` VALUES ('128', 'mime', '文件mime类型', 'char(40) NOT NULL ', 'string', '\'\'', '', '1', '', '12', '0', '1', '1383902267', '1383891474');
INSERT INTO `tv_attribute` VALUES ('129', 'size', '文件大小', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '12', '0', '1', '1383902259', '1383891474');
INSERT INTO `tv_attribute` VALUES ('130', 'md5', '文件md5', 'char(32) NOT NULL ', 'string', '\'\'', '', '1', '', '12', '0', '1', '1383902245', '1383891474');
INSERT INTO `tv_attribute` VALUES ('131', 'sha1', '文件 sha1编码', 'char(40) NOT NULL ', 'string', '\'\'', '', '1', '', '12', '0', '1', '1383902236', '1383891474');
INSERT INTO `tv_attribute` VALUES ('132', 'location', '文件保存位置', 'tinyint(3) unsigned NOT NULL ', 'checkbox', '0', '', '1', '0:本地\r\n1:FTP', '12', '0', '1', '1383899469', '1383891474');
INSERT INTO `tv_attribute` VALUES ('133', 'create_time', '上传时间', 'int(10) unsigned NOT NULL ', 'datetime', '', '', '1', '', '12', '0', '1', '1383899436', '1383891474');
INSERT INTO `tv_attribute` VALUES ('134', 'name', '钩子名称', 'varchar(40) NOT NULL ', 'string', '\'\'', '', '1', '', '13', '0', '1', '1383902516', '1383891480');
INSERT INTO `tv_attribute` VALUES ('135', 'description', '描述', 'text NOT NULL ', 'editor', '', '', '1', '', '13', '0', '1', '1383902505', '1383891480');
INSERT INTO `tv_attribute` VALUES ('136', 'type', '类型', 'tinyint(1) unsigned NOT NULL ', 'select', '1', '', '1', '1:Controller\r\n2:Widget', '13', '0', '1', '1383902484', '1383891480');
INSERT INTO `tv_attribute` VALUES ('137', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '13', '0', '1', '1383902552', '1383891480');
INSERT INTO `tv_attribute` VALUES ('138', 'addons', '钩子挂载的插件 \'，\'分割', 'varchar(255) NULL ', 'string', '', '', '1', '', '13', '0', '1', '1383891480', '1383891480');
INSERT INTO `tv_attribute` VALUES ('139', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '14', '0', '1', '1383898187', '1383891488');
INSERT INTO `tv_attribute` VALUES ('140', 'nickname', '昵称', 'char(16) NOT NULL ', 'string', '\'\'', '', '1', '', '14', '0', '1', '1383902646', '1383891488');
INSERT INTO `tv_attribute` VALUES ('141', 'sex', '性别', 'tinyint(3) unsigned NOT NULL ', 'radio', '0', '', '1', '0:女\r\n1:男', '14', '0', '1', '1383898158', '1383891488');
INSERT INTO `tv_attribute` VALUES ('142', 'birthday', '生日', 'date NOT NULL ', 'string', '0000-00-00', '', '1', '', '14', '0', '1', '1383891488', '1383891488');
INSERT INTO `tv_attribute` VALUES ('143', 'qq', 'qq号', 'char(10) NOT NULL ', 'string', '\'\'', '', '1', '', '14', '0', '1', '1383902605', '1383891488');
INSERT INTO `tv_attribute` VALUES ('144', 'score', '用户积分', 'mediumint(8) NOT NULL ', 'num', '0', '', '1', '', '14', '0', '1', '1383898066', '1383891488');
INSERT INTO `tv_attribute` VALUES ('145', 'login', '登录次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '14', '0', '1', '1383898055', '1383891488');
INSERT INTO `tv_attribute` VALUES ('146', 'reg_ip', '注册IP', 'bigint(20) NOT NULL ', 'string', '0', '', '1', '', '14', '0', '1', '1383898045', '1383891488');
INSERT INTO `tv_attribute` VALUES ('147', 'reg_time', '注册时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '14', '0', '1', '1383897783', '1383891488');
INSERT INTO `tv_attribute` VALUES ('148', 'last_login_ip', '最后登录IP', 'bigint(20) NOT NULL ', 'string', '0', '', '1', '', '14', '0', '1', '1383891488', '1383891488');
INSERT INTO `tv_attribute` VALUES ('149', 'last_login_time', '最后登录时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '14', '0', '1', '1383897775', '1383891488');
INSERT INTO `tv_attribute` VALUES ('150', 'status', '会员状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '1', '1:正常\r\n0:禁用', '14', '0', '1', '1383898472', '1383891488');
INSERT INTO `tv_attribute` VALUES ('151', 'title', '标题', 'varchar(50) NOT NULL ', 'string', '\'\'', '', '1', '', '15', '0', '1', '1383902756', '1383891503');
INSERT INTO `tv_attribute` VALUES ('152', 'pid', '上级分类ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '15', '0', '1', '1383897737', '1383891503');
INSERT INTO `tv_attribute` VALUES ('153', 'sort', '排序（同级有效）', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '15', '0', '1', '1383902746', '1383891503');
INSERT INTO `tv_attribute` VALUES ('154', 'url', '链接地址', 'char(255) NOT NULL ', 'string', '\'\'', '', '1', '', '15', '0', '1', '1383902737', '1383891503');
INSERT INTO `tv_attribute` VALUES ('155', 'hide', '是否隐藏', 'tinyint(1) unsigned NOT NULL ', 'radio', '0', '', '1', '1:是\r\n0:否', '15', '0', '1', '1383902727', '1383891503');
INSERT INTO `tv_attribute` VALUES ('156', 'tip', '提示', 'varchar(255) NOT NULL ', 'textarea', '\'\'', '', '1', '', '15', '0', '1', '1383902703', '1383891503');
INSERT INTO `tv_attribute` VALUES ('157', 'group', '分组', 'varchar(50) NULL ', 'string', '\'\'', '', '1', '', '15', '0', '1', '1383902688', '1383891503');
INSERT INTO `tv_attribute` VALUES ('158', 'is_dev', '是否仅开发者模式可见', 'tinyint(1) unsigned NOT NULL ', 'radio', '0', '', '1', '1:开发者模式可见\r\n0:开发者模式不可见', '15', '0', '1', '1383902676', '1383891503');
INSERT INTO `tv_attribute` VALUES ('159', 'name', '模型标识', 'char(30) NOT NULL ', 'string', '\'\'', '', '1', '', '16', '0', '1', '1383903045', '1383891514');
INSERT INTO `tv_attribute` VALUES ('160', 'title', '模型名称', 'char(30) NOT NULL ', 'string', '\'\'', '', '1', '', '16', '0', '1', '1383903037', '1383891514');
INSERT INTO `tv_attribute` VALUES ('161', 'extend', '继承的模型', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '16', '0', '1', '1383903026', '1383891514');
INSERT INTO `tv_attribute` VALUES ('162', 'relation', '继承与被继承模型的关联字段', 'varchar(30) NOT NULL ', 'string', '', '', '1', '', '16', '0', '1', '1383891514', '1383891514');
INSERT INTO `tv_attribute` VALUES ('163', 'need_pk', '新建表时是否需要主键字段', 'tinyint(1) unsigned NOT NULL ', 'radio', '1', '', '1', '1:是\r\n0:否', '16', '0', '1', '1383903004', '1383891514');
INSERT INTO `tv_attribute` VALUES ('164', 'field_sort', '表单字段排序', 'text NOT NULL ', 'textarea', '', '', '1', '', '16', '0', '1', '1383902978', '1383891514');
INSERT INTO `tv_attribute` VALUES ('165', 'field_group', '字段分组', 'varchar(255) NOT NULL ', 'string', '1:基础', '', '1', '', '16', '0', '1', '1383891514', '1383891514');
INSERT INTO `tv_attribute` VALUES ('166', 'attribute_list', '属性列表（表的字段）', 'text NOT NULL ', 'textarea', '', '', '1', '', '16', '0', '1', '1383902908', '1383891514');
INSERT INTO `tv_attribute` VALUES ('167', 'template_list', '列表模板', 'varchar(100) NOT NULL ', 'string', '\'\'', '', '1', '', '16', '0', '1', '1383902888', '1383891514');
INSERT INTO `tv_attribute` VALUES ('168', 'template_add', '新增模板', 'varchar(100) NOT NULL ', 'string', '\'\'', '', '1', '', '16', '0', '1', '1383902878', '1383891514');
INSERT INTO `tv_attribute` VALUES ('169', 'template_edit', '编辑模板', 'varchar(100) NOT NULL ', 'string', '\'\'', '', '1', '', '16', '0', '1', '1383902869', '1383891514');
INSERT INTO `tv_attribute` VALUES ('170', 'list_grid', '列表定义', 'varchar(255) NOT NULL ', 'textarea', '\'\'', '', '1', '', '16', '0', '1', '1383902861', '1383891514');
INSERT INTO `tv_attribute` VALUES ('171', 'list_row', '列表数据长度', 'smallint(2) unsigned NOT NULL ', 'num', '10', '', '1', '', '16', '0', '1', '1383897602', '1383891514');
INSERT INTO `tv_attribute` VALUES ('172', 'search_key', '默认搜索字段', 'varchar(50) NOT NULL ', 'string', '\'\'', '', '1', '', '16', '0', '1', '1383902840', '1383891514');
INSERT INTO `tv_attribute` VALUES ('173', 'search_list', '高级搜索的字段', 'varchar(255) NOT NULL ', 'string', '\'\'', '', '1', '', '16', '0', '1', '1383902828', '1383891514');
INSERT INTO `tv_attribute` VALUES ('174', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '16', '0', '1', '1383897557', '1383891514');
INSERT INTO `tv_attribute` VALUES ('175', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '16', '0', '1', '1383897549', '1383891514');
INSERT INTO `tv_attribute` VALUES ('176', 'status', '状态', 'tinyint(3) unsigned NOT NULL ', 'radio', '0', '', '1', '-1:已删除\r\n0:禁用\r\n1:正常', '16', '0', '1', '1383902811', '1383891514');
INSERT INTO `tv_attribute` VALUES ('177', 'path', '路径', 'varchar(255) NOT NULL ', 'string', '\'\'', '', '1', '', '17', '0', '1', '1383903110', '1383891522');
INSERT INTO `tv_attribute` VALUES ('178', 'url', '图片链接', 'varchar(255) NOT NULL ', 'string', '\'\'', '', '1', '', '17', '0', '1', '1383903103', '1383891522');
INSERT INTO `tv_attribute` VALUES ('179', 'md5', '文件md5', 'char(32) NOT NULL ', 'string', '\'\'', '', '1', '', '17', '0', '1', '1383903093', '1383891522');
INSERT INTO `tv_attribute` VALUES ('180', 'sha1', '文件 sha1编码', 'char(40) NOT NULL ', 'string', '\'\'', '', '1', '', '17', '0', '1', '1383903084', '1383891522');
INSERT INTO `tv_attribute` VALUES ('181', 'status', '状态', 'tinyint(2) NOT NULL ', 'radio', '0', '', '1', '-1:已删除\r\n0:禁用\r\n1:正常', '17', '0', '1', '1383903075', '1383891522');
INSERT INTO `tv_attribute` VALUES ('182', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '17', '0', '1', '1383897491', '1383891522');
INSERT INTO `tv_attribute` VALUES ('183', 'url', '链接地址', 'char(255) NOT NULL ', 'string', '\'\'', '', '1', '', '18', '0', '1', '1383903175', '1383891532');
INSERT INTO `tv_attribute` VALUES ('184', 'short', '短网址', 'char(100) NOT NULL ', 'string', '\'\'', '', '1', '', '18', '0', '1', '1383903162', '1383891532');
INSERT INTO `tv_attribute` VALUES ('185', 'status', '状态', 'tinyint(2) NOT NULL ', 'radio', '2', '', '1', '-1:已删除\r\n0:禁用\r\n1:正常\r\n2:未审核', '18', '0', '1', '1383903153', '1383891532');
INSERT INTO `tv_attribute` VALUES ('186', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '18', '0', '1', '1383903130', '1383891532');
INSERT INTO `tv_attribute` VALUES ('187', 'upload_time', '', 'int(10) NOT NULL', 'datetime', '', '', '1', '', '17', '0', '1', '1439272529', '1439272529');

-- -----------------------------
-- Table structure for `tv_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `tv_auth_extend`;
CREATE TABLE `tv_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `tv_auth_extend`
-- -----------------------------
INSERT INTO `tv_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `tv_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `tv_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `tv_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `tv_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `tv_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `tv_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `tv_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `tv_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `tv_auth_group`;
CREATE TABLE `tv_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_auth_group`
-- -----------------------------
INSERT INTO `tv_auth_group` VALUES ('1', 'admin', '1', '默认用户组', '', '2', '1,2,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,96,97,100,102,103,105,106');
INSERT INTO `tv_auth_group` VALUES ('3', 'admin', '1', '二级管理员', '', '2', '');
INSERT INTO `tv_auth_group` VALUES ('4', 'admin', '1', '服务商', '', '2', '1,3,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,94,95,107,108,109,110,213,214,215,216,217,218,219,220,221,222,223,224,229,230,231,232,233,234,235,236,237');

-- -----------------------------
-- Table structure for `tv_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `tv_auth_group_access`;
CREATE TABLE `tv_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_auth_group_access`
-- -----------------------------
INSERT INTO `tv_auth_group_access` VALUES ('19', '1');
INSERT INTO `tv_auth_group_access` VALUES ('20', '1');
INSERT INTO `tv_auth_group_access` VALUES ('24', '2');
INSERT INTO `tv_auth_group_access` VALUES ('25', '2');
INSERT INTO `tv_auth_group_access` VALUES ('42', '4');
INSERT INTO `tv_auth_group_access` VALUES ('44', '4');

-- -----------------------------
-- Table structure for `tv_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `tv_auth_rule`;
CREATE TABLE `tv_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`module`,`name`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=239 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_auth_rule`
-- -----------------------------
INSERT INTO `tv_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/mydocument', '文章', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('6', 'admin', '1', 'Admin/Index/index', '首页', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('17', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addAction', '新增用户行为', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editAction', '编辑用户行为', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户列表', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('211', 'admin', '2', 'Admin/Order/index', '订单', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('212', 'admin', '2', 'Admin/facilitator/index', '服务商', '-1', '');
INSERT INTO `tv_auth_rule` VALUES ('213', 'admin', '1', 'Admin/vip/user', 'VIP用户', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('214', 'admin', '1', 'Admin/vip/category', 'VIP类目', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('215', 'admin', '1', 'Admin/facilitator/index', '服务商', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('216', 'admin', '1', 'Admin/vip/add', '新增类目', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('217', 'admin', '1', 'Admin/vip/user_add', '新增vip用户', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('218', 'admin', '1', 'Admin/vip/edit', '编辑类目', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('219', 'admin', '1', 'Admin/vip/user_edit', '编辑vip用户', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('220', 'admin', '1', 'Admin/facilitator/add', '新增服务商用户', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('221', 'admin', '1', 'Admin/facilitator/edit', '编辑服务商用户', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('222', 'admin', '1', 'Admin/Points/uslist', '积分进出', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('223', 'admin', '2', 'Admin/Product/rmlist', '产品', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('224', 'admin', '1', 'Admin/Product/rmlist', '房源列表', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('225', 'admin', '1', 'Admin/Product/lvlist', '类目列表', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('226', 'admin', '1', 'Admin/product/lvadd', '新增产品栏目', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('227', 'admin', '1', 'Admin/product/lvedit', '编辑产品类目', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('228', 'admin', '1', 'Admin/product/rmadd', '添加房源', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('229', 'admin', '1', 'Admin/product/rmedit', '编辑房源', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('230', 'admin', '1', 'Admin/Product/eatlist', '餐饮列表', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('231', 'admin', '1', 'Admin/Product/pylist', '游玩列表', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('232', 'admin', '1', 'Admin/product/pyadd', '添加景点', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('233', 'admin', '1', 'Admin/product/pyedit', '编辑景点', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('234', 'admin', '1', 'Admin/product/eatadd', '添加餐饮', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('235', 'admin', '1', 'Admin/product/eatedit', '编辑餐饮', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('236', 'admin', '1', 'Admin/Order/ordlist', '订单列表', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('237', 'admin', '2', 'Admin/Order/ordlist', '订单', '1', '');
INSERT INTO `tv_auth_rule` VALUES ('238', 'admin', '1', 'Admin/product/relist', '线路列表', '1', '');

-- -----------------------------
-- Table structure for `tv_cart`
-- -----------------------------
DROP TABLE IF EXISTS `tv_cart`;
CREATE TABLE `tv_cart` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `pro_id` int(11) NOT NULL COMMENT '产品id',
  `pro_type` varchar(2) NOT NULL COMMENT '产品类型',
  `insert_time` varchar(10) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_cart`
-- -----------------------------
INSERT INTO `tv_cart` VALUES ('1', '44', '9', '4', '1441942999');
INSERT INTO `tv_cart` VALUES ('2', '44', '3', '1', '1441944130');
INSERT INTO `tv_cart` VALUES ('3', '44', '11', '4', '1441944142');
INSERT INTO `tv_cart` VALUES ('4', '44', '1', '2', '1441944151');
INSERT INTO `tv_cart` VALUES ('5', '44', '2', '2', '1441944158');
INSERT INTO `tv_cart` VALUES ('6', '44', '2', '3', '1441944173');
INSERT INTO `tv_cart` VALUES ('7', '44', '3', '3', '1441944175');
INSERT INTO `tv_cart` VALUES ('8', '44', '10', '4', '1441944202');

-- -----------------------------
-- Table structure for `tv_category`
-- -----------------------------
DROP TABLE IF EXISTS `tv_category`;
CREATE TABLE `tv_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COMMENT='分类表\r\n@author   麦当苗儿\r\n@version  2013-05-21';


-- -----------------------------
-- Table structure for `tv_channel`
-- -----------------------------
DROP TABLE IF EXISTS `tv_channel`;
CREATE TABLE `tv_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_channel`
-- -----------------------------
INSERT INTO `tv_channel` VALUES ('1', '0', '首页', 'Index/index', '2', '1379475111', '1379923177', '1');
INSERT INTO `tv_channel` VALUES ('2', '0', '博客', 'Article/index?category=blog', '0', '1379475131', '1379483713', '1');
INSERT INTO `tv_channel` VALUES ('3', '0', '讨论', 'Article/index?category=topic', '0', '1379475154', '1379483726', '1');

-- -----------------------------
-- Table structure for `tv_comment`
-- -----------------------------
DROP TABLE IF EXISTS `tv_comment`;
CREATE TABLE `tv_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `pro_type` varchar(11) NOT NULL COMMENT '产品类型(1:房源 2:餐饮 3:景点)',
  `pro_id` varchar(11) NOT NULL COMMENT '产品id',
  `content` text NOT NULL COMMENT '内容',
  `score` varchar(2) DEFAULT NULL COMMENT '星级',
  `insert_time` varchar(10) NOT NULL COMMENT '评论时间',
  `status` varchar(1) DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_comment`
-- -----------------------------
INSERT INTO `tv_comment` VALUES ('2', '1', '2', '1', '环境舒适，前台、房间及廊道等装修设计令人赏心悦目，灯光柔和，是阖家旅行、商务出差或接待等最佳选择，下次来北京必再来！', '', '1441596240', '');
INSERT INTO `tv_comment` VALUES ('3', '1', '3', '3', '环境舒适，前台、房间及廊道等装修设计令人赏心悦目，灯光柔和，是阖家旅行、商务出差或接待等最佳选择，下次来北京必再来！', '', '1441596240', '');
INSERT INTO `tv_comment` VALUES ('4', '1', '1', '3', '环境舒适，前台、房间及廊道等装修设计令人赏心悦目，灯光柔和，是阖家旅行、商务出差或接待等最佳选择，下次来北京必再来！', '', '1441596240', '');
INSERT INTO `tv_comment` VALUES ('5', '1', '4', '9', '环境舒适，前台、房间及廊道等装修设计令人赏心悦目，灯光柔和，是阖家旅行、商务出差或接待等最佳选择，下次来北京必再来！', '', '1441596240', '');
INSERT INTO `tv_comment` VALUES ('6', '1', '2', '1', '环境舒适，前台、房间及廊道等装修设计令人赏心悦目，灯光柔和，是阖家旅行、商务出差或接待等最佳选择，下次来北京必再来！', '', '1441596240', '');
INSERT INTO `tv_comment` VALUES ('7', '1', '3', '3', '环境舒适，前台、房间及廊道等装修设计令人赏心悦目，灯光柔和，是阖家旅行、商务出差或接待等最佳选择，下次来北京必再来！', '', '1441596240', '');
INSERT INTO `tv_comment` VALUES ('8', '1', '1', '3', '环境舒适，前台、房间及廊道等装修设计令人赏心悦目，灯光柔和，是阖家旅行、商务出差或接待等最佳选择，下次来北京必再来！', '', '1441596240', '');
INSERT INTO `tv_comment` VALUES ('9', '1', '4', '9', '环境舒适，前台、房间及廊道等装修设计令人赏心悦目，灯光柔和，是阖家旅行、商务出差或接待等最佳选择，下次来北京必再来！', '', '1441596240', '');

-- -----------------------------
-- Table structure for `tv_config`
-- -----------------------------
DROP TABLE IF EXISTS `tv_config`;
CREATE TABLE `tv_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_config`
-- -----------------------------
INSERT INTO `tv_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', '海乐游', '0');
INSERT INTO `tv_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '吃喝玩乐', '1');
INSERT INTO `tv_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', 'Tourism|海乐游', '3');
INSERT INTO `tv_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '0');
INSERT INTO `tv_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '0');
INSERT INTO `tv_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '4');
INSERT INTO `tv_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表页推荐\r\n2:频道页推荐\r\n4:网站首页推荐', '0');
INSERT INTO `tv_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '0');
INSERT INTO `tv_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'default_color', '5');
INSERT INTO `tv_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1439862411', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统\r\n5:图片\r\n6:积分\r\n7:邮件', '0');
INSERT INTO `tv_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '0');
INSERT INTO `tv_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '0');
INSERT INTO `tv_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '0', '0');
INSERT INTO `tv_config` VALUES ('24', 'AOTUSAVE_DRAFT', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1379484574', '1', '60', '0');
INSERT INTO `tv_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '5');
INSERT INTO `tv_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '0');
INSERT INTO `tv_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '0');
INSERT INTO `tv_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '0');
INSERT INTO `tv_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '0');
INSERT INTO `tv_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '0');
INSERT INTO `tv_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '0');
INSERT INTO `tv_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '0');
INSERT INTO `tv_config` VALUES ('33', 'IMG_MAX_SIZE', '0', '图片最大上传大小', '5', '', '图片最大上传大小(M)', '1439363659', '1439364296', '1', '3', '0');
INSERT INTO `tv_config` VALUES ('34', 'IMG_PIC_SUFFIX', '1', '图片后缀', '5', '', '允许文件上传后缀', '1439363885', '1439363885', '1', 'jpg gif png jpeg', '0');
INSERT INTO `tv_config` VALUES ('35', 'SWITCH_MARK', '4', '水印图', '5', '0:关闭水印图片生成,1:开启水印图片生成', '是否生成水印图', '1439364191', '1439520873', '1', '1', '1');
INSERT INTO `tv_config` VALUES ('46', 'SWITCHIMG_SWITCH', '4', '缩略图', '5', '0:关闭缩略图片生成,1:开启缩略图片生成', '是否生成缩略图', '1439461536', '1439461536', '1', '1', '0');
INSERT INTO `tv_config` VALUES ('36', 'CONSUMPTION', '0', '消费获取积分', '6', '', '消费多少金额获取：一积分【元】', '1439366818', '1439368526', '1', '200', '0');
INSERT INTO `tv_config` VALUES ('37', 'USING_INTEGRAL', '0', '积分抵用消费', '6', '', '一积分抵用多少消费金额【元】', '1439368462', '1439368557', '1', '0.02', '0');
INSERT INTO `tv_config` VALUES ('38', 'POINTS_ON_OFF', '4', '积分开关', '6', '0:禁用\r\n1:启用\r\n', '是否启用', '1439368764', '1439368764', '1', '1', '0');
INSERT INTO `tv_config` VALUES ('39', 'MAX_WIDTH', '0', '缩略图宽度', '5', '', 'px', '1439371695', '1439460542', '1', '200', '0');
INSERT INTO `tv_config` VALUES ('40', 'MAX_HEIGHT', '0', '缩略图高度', '5', '', 'px', '1439371737', '1439460578', '1', '200', '0');
INSERT INTO `tv_config` VALUES ('41', 'PRODUC_TYPE', '3', '产品类目', '0', '', '', '1439439185', '1439444668', '1', '1:房源\r\n2:餐饮\r\n3:游玩', '0');
INSERT INTO `tv_config` VALUES ('42', 'ROOM_TYPE', '3', '房源配置类目', '0', '', '', '1439445356', '1439445356', '1', '1:房间类型\r\n2:房间设备\r\n3:房间床型', '0');
INSERT INTO `tv_config` VALUES ('43', 'WATERMARK', '2', '水印', '5', '', '只能填写英文', '1439461148', '1439517493', '1', 'HAI_LE_YOU', '0');
INSERT INTO `tv_config` VALUES ('44', 'WATERMARK_WIDTH', '0', '水印图像宽度', '5', '', 'px', '1439461248', '1439461248', '1', '300', '0');
INSERT INTO `tv_config` VALUES ('45', 'WATERMARK_HEIGHT', '0', '水印图高度', '5', '', 'px', '1439461307', '1439461307', '1', '400', '0');
INSERT INTO `tv_config` VALUES ('47', 'MAIL_ADDRESS', '1', '邮箱地址', '7', '', 'Mail', '1439862560', '1439874065', '1', '977639814@qq.com', '0');
INSERT INTO `tv_config` VALUES ('48', 'MAIL_SMTP', '1', '邮箱SMTP服务器', '7', '', 'Mail', '1439866213', '1439874059', '1', 'smtp.qq.com', '0');
INSERT INTO `tv_config` VALUES ('49', 'MAIL_LOGINNAME', '1', '邮箱登录帐号', '7', '', 'Mail', '1439866254', '1439874082', '1', '977639814', '0');
INSERT INTO `tv_config` VALUES ('50', 'MAIL_PASSWORD', '1', '邮箱密码', '7', '', 'Mail', '1439866282', '1439874052', '1', 'yang12304012144', '0');
INSERT INTO `tv_config` VALUES ('51', 'MAIL_CHARSET', '1', '编码', '7', '', 'Mail', '1439866350', '1439874041', '1', 'UTF-8', '0');
INSERT INTO `tv_config` VALUES ('52', 'MAIL_AUTH', '4', '邮箱认证', '7', 'false:关闭\r\ntrue:开启', 'Mail', '1439866440', '1439874046', '1', 'true', '0');
INSERT INTO `tv_config` VALUES ('53', 'MAIL_HTML', '4', '格式', '7', 'false:TXT\r\ntrue:HTML', 'true HTML格式 false TXT格式', '1439866498', '1439866498', '1', 'true', '0');

-- -----------------------------
-- Table structure for `tv_document`
-- -----------------------------
DROP TABLE IF EXISTS `tv_document`;
CREATE TABLE `tv_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`type`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表\r\n@author   麦当苗儿\r\n@version  2013-05-21';


-- -----------------------------
-- Table structure for `tv_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `tv_document_article`;
CREATE TABLE `tv_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表\r\n@author   麦当苗儿\r\n@version  2013-05-24';


-- -----------------------------
-- Table structure for `tv_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `tv_document_download`;
CREATE TABLE `tv_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表\r\n@author   麦当苗儿\r\n@version  2013-05-24';


-- -----------------------------
-- Table structure for `tv_facilitator_data`
-- -----------------------------
DROP TABLE IF EXISTS `tv_facilitator_data`;
CREATE TABLE `tv_facilitator_data` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL COMMENT '用户id',
  `type` int(1) NOT NULL DEFAULT '0' COMMENT '类型（个人/企业）',
  `realname` varchar(25) NOT NULL COMMENT '真实姓名/法人',
  `IDcard` varchar(25) NOT NULL COMMENT '个人/法人身份证号码',
  `business_licence` varchar(25) DEFAULT NULL COMMENT '营业执照号码',
  `IDcard_url` varchar(200) NOT NULL COMMENT '身份证相片url',
  `business_licence_url` varchar(100) DEFAULT NULL COMMENT '营业执照图片url',
  `tel` varchar(20) NOT NULL COMMENT '公司电话',
  `mobile` varchar(20) DEFAULT NULL COMMENT '移动电话号码',
  `operations_type` varchar(50) DEFAULT NULL COMMENT '公司运营类型（旅游，食品）',
  `region` varchar(200) DEFAULT NULL COMMENT '公司省市区',
  `address` varchar(200) NOT NULL COMMENT '运营所在地址',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态（0：禁用1：审核通过，2：删除，3：待审核4：审核不通过）',
  `feedback` text COMMENT '审核原因反馈',
  `insert_time` varchar(10) NOT NULL COMMENT '用户上传时间',
  `update_time` varchar(10) DEFAULT NULL COMMENT '更新时间',
  `finish_time` varchar(10) DEFAULT NULL COMMENT '审核时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='服务商资料表';

-- -----------------------------
-- Records of `tv_facilitator_data`
-- -----------------------------
INSERT INTO `tv_facilitator_data` VALUES ('20', '45', '2', '杨艺平1', '440233199309', '45454545', '392,393', '', '45455', '', '45', '', '4555', '1', '', '', '', '');

-- -----------------------------
-- Table structure for `tv_file`
-- -----------------------------
DROP TABLE IF EXISTS `tv_file`;
CREATE TABLE `tv_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='文件表\r\n@author   麦当苗儿\r\n@version  2013-05-21';


-- -----------------------------
-- Table structure for `tv_global_region`
-- -----------------------------
DROP TABLE IF EXISTS `tv_global_region`;
CREATE TABLE `tv_global_region` (
  `region_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `region_name` varchar(120) NOT NULL DEFAULT '',
  `region_type` tinyint(1) NOT NULL DEFAULT '2',
  PRIMARY KEY (`region_id`),
  KEY `parent_id` (`parent_id`),
  KEY `region_type` (`region_type`)
) ENGINE=MyISAM AUTO_INCREMENT=3409 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_global_region`
-- -----------------------------
INSERT INTO `tv_global_region` VALUES ('1', '0', '中国', '0');
INSERT INTO `tv_global_region` VALUES ('2', '1', '北京', '1');
INSERT INTO `tv_global_region` VALUES ('3', '1', '安徽', '1');
INSERT INTO `tv_global_region` VALUES ('4', '1', '福建', '1');
INSERT INTO `tv_global_region` VALUES ('5', '1', '甘肃', '1');
INSERT INTO `tv_global_region` VALUES ('6', '1', '广东', '1');
INSERT INTO `tv_global_region` VALUES ('7', '1', '广西', '1');
INSERT INTO `tv_global_region` VALUES ('8', '1', '贵州', '1');
INSERT INTO `tv_global_region` VALUES ('9', '1', '海南', '1');
INSERT INTO `tv_global_region` VALUES ('10', '1', '河北', '1');
INSERT INTO `tv_global_region` VALUES ('11', '1', '河南', '1');
INSERT INTO `tv_global_region` VALUES ('12', '1', '黑龙江', '1');
INSERT INTO `tv_global_region` VALUES ('13', '1', '湖北', '1');
INSERT INTO `tv_global_region` VALUES ('14', '1', '湖南', '1');
INSERT INTO `tv_global_region` VALUES ('15', '1', '吉林', '1');
INSERT INTO `tv_global_region` VALUES ('16', '1', '江苏', '1');
INSERT INTO `tv_global_region` VALUES ('17', '1', '江西', '1');
INSERT INTO `tv_global_region` VALUES ('18', '1', '辽宁', '1');
INSERT INTO `tv_global_region` VALUES ('19', '1', '内蒙古', '1');
INSERT INTO `tv_global_region` VALUES ('20', '1', '宁夏', '1');
INSERT INTO `tv_global_region` VALUES ('21', '1', '青海', '1');
INSERT INTO `tv_global_region` VALUES ('22', '1', '山东', '1');
INSERT INTO `tv_global_region` VALUES ('23', '1', '山西', '1');
INSERT INTO `tv_global_region` VALUES ('24', '1', '陕西', '1');
INSERT INTO `tv_global_region` VALUES ('25', '1', '上海', '1');
INSERT INTO `tv_global_region` VALUES ('26', '1', '四川', '1');
INSERT INTO `tv_global_region` VALUES ('27', '1', '天津', '1');
INSERT INTO `tv_global_region` VALUES ('28', '1', '西藏', '1');
INSERT INTO `tv_global_region` VALUES ('29', '1', '新疆', '1');
INSERT INTO `tv_global_region` VALUES ('30', '1', '云南', '1');
INSERT INTO `tv_global_region` VALUES ('31', '1', '浙江', '1');
INSERT INTO `tv_global_region` VALUES ('32', '1', '重庆', '1');
INSERT INTO `tv_global_region` VALUES ('33', '1', '香港', '1');
INSERT INTO `tv_global_region` VALUES ('34', '1', '澳门', '1');
INSERT INTO `tv_global_region` VALUES ('35', '1', '台湾', '1');
INSERT INTO `tv_global_region` VALUES ('36', '3', '安庆', '2');
INSERT INTO `tv_global_region` VALUES ('37', '3', '蚌埠', '2');
INSERT INTO `tv_global_region` VALUES ('38', '3', '巢湖', '2');
INSERT INTO `tv_global_region` VALUES ('39', '3', '池州', '2');
INSERT INTO `tv_global_region` VALUES ('40', '3', '滁州', '2');
INSERT INTO `tv_global_region` VALUES ('41', '3', '阜阳', '2');
INSERT INTO `tv_global_region` VALUES ('42', '3', '淮北', '2');
INSERT INTO `tv_global_region` VALUES ('43', '3', '淮南', '2');
INSERT INTO `tv_global_region` VALUES ('44', '3', '黄山', '2');
INSERT INTO `tv_global_region` VALUES ('45', '3', '六安', '2');
INSERT INTO `tv_global_region` VALUES ('46', '3', '马鞍山', '2');
INSERT INTO `tv_global_region` VALUES ('47', '3', '宿州', '2');
INSERT INTO `tv_global_region` VALUES ('48', '3', '铜陵', '2');
INSERT INTO `tv_global_region` VALUES ('49', '3', '芜湖', '2');
INSERT INTO `tv_global_region` VALUES ('50', '3', '宣城', '2');
INSERT INTO `tv_global_region` VALUES ('51', '3', '亳州', '2');
INSERT INTO `tv_global_region` VALUES ('52', '2', '北京', '2');
INSERT INTO `tv_global_region` VALUES ('53', '4', '福州', '2');
INSERT INTO `tv_global_region` VALUES ('54', '4', '龙岩', '2');
INSERT INTO `tv_global_region` VALUES ('55', '4', '南平', '2');
INSERT INTO `tv_global_region` VALUES ('56', '4', '宁德', '2');
INSERT INTO `tv_global_region` VALUES ('57', '4', '莆田', '2');
INSERT INTO `tv_global_region` VALUES ('58', '4', '泉州', '2');
INSERT INTO `tv_global_region` VALUES ('59', '4', '三明', '2');
INSERT INTO `tv_global_region` VALUES ('60', '4', '厦门', '2');
INSERT INTO `tv_global_region` VALUES ('61', '4', '漳州', '2');
INSERT INTO `tv_global_region` VALUES ('62', '5', '兰州', '2');
INSERT INTO `tv_global_region` VALUES ('63', '5', '白银', '2');
INSERT INTO `tv_global_region` VALUES ('64', '5', '定西', '2');
INSERT INTO `tv_global_region` VALUES ('65', '5', '甘南', '2');
INSERT INTO `tv_global_region` VALUES ('66', '5', '嘉峪关', '2');
INSERT INTO `tv_global_region` VALUES ('67', '5', '金昌', '2');
INSERT INTO `tv_global_region` VALUES ('68', '5', '酒泉', '2');
INSERT INTO `tv_global_region` VALUES ('69', '5', '临夏', '2');
INSERT INTO `tv_global_region` VALUES ('70', '5', '陇南', '2');
INSERT INTO `tv_global_region` VALUES ('71', '5', '平凉', '2');
INSERT INTO `tv_global_region` VALUES ('72', '5', '庆阳', '2');
INSERT INTO `tv_global_region` VALUES ('73', '5', '天水', '2');
INSERT INTO `tv_global_region` VALUES ('74', '5', '武威', '2');
INSERT INTO `tv_global_region` VALUES ('75', '5', '张掖', '2');
INSERT INTO `tv_global_region` VALUES ('76', '6', '广州', '2');
INSERT INTO `tv_global_region` VALUES ('77', '6', '深圳', '2');
INSERT INTO `tv_global_region` VALUES ('78', '6', '潮州', '2');
INSERT INTO `tv_global_region` VALUES ('79', '6', '东莞', '2');
INSERT INTO `tv_global_region` VALUES ('80', '6', '佛山', '2');
INSERT INTO `tv_global_region` VALUES ('81', '6', '河源', '2');
INSERT INTO `tv_global_region` VALUES ('82', '6', '惠州', '2');
INSERT INTO `tv_global_region` VALUES ('83', '6', '江门', '2');
INSERT INTO `tv_global_region` VALUES ('84', '6', '揭阳', '2');
INSERT INTO `tv_global_region` VALUES ('85', '6', '茂名', '2');
INSERT INTO `tv_global_region` VALUES ('86', '6', '梅州', '2');
INSERT INTO `tv_global_region` VALUES ('87', '6', '清远', '2');
INSERT INTO `tv_global_region` VALUES ('88', '6', '汕头', '2');
INSERT INTO `tv_global_region` VALUES ('89', '6', '汕尾', '2');
INSERT INTO `tv_global_region` VALUES ('90', '6', '韶关', '2');
INSERT INTO `tv_global_region` VALUES ('91', '6', '阳江', '2');
INSERT INTO `tv_global_region` VALUES ('92', '6', '云浮', '2');
INSERT INTO `tv_global_region` VALUES ('93', '6', '湛江', '2');
INSERT INTO `tv_global_region` VALUES ('94', '6', '肇庆', '2');
INSERT INTO `tv_global_region` VALUES ('95', '6', '中山', '2');
INSERT INTO `tv_global_region` VALUES ('96', '6', '珠海', '2');
INSERT INTO `tv_global_region` VALUES ('97', '7', '南宁', '2');
INSERT INTO `tv_global_region` VALUES ('98', '7', '桂林', '2');
INSERT INTO `tv_global_region` VALUES ('99', '7', '百色', '2');
INSERT INTO `tv_global_region` VALUES ('100', '7', '北海', '2');
INSERT INTO `tv_global_region` VALUES ('101', '7', '崇左', '2');
INSERT INTO `tv_global_region` VALUES ('102', '7', '防城港', '2');
INSERT INTO `tv_global_region` VALUES ('103', '7', '贵港', '2');
INSERT INTO `tv_global_region` VALUES ('104', '7', '河池', '2');
INSERT INTO `tv_global_region` VALUES ('105', '7', '贺州', '2');
INSERT INTO `tv_global_region` VALUES ('106', '7', '来宾', '2');
INSERT INTO `tv_global_region` VALUES ('107', '7', '柳州', '2');
INSERT INTO `tv_global_region` VALUES ('108', '7', '钦州', '2');
INSERT INTO `tv_global_region` VALUES ('109', '7', '梧州', '2');
INSERT INTO `tv_global_region` VALUES ('110', '7', '玉林', '2');
INSERT INTO `tv_global_region` VALUES ('111', '8', '贵阳', '2');
INSERT INTO `tv_global_region` VALUES ('112', '8', '安顺', '2');
INSERT INTO `tv_global_region` VALUES ('113', '8', '毕节', '2');
INSERT INTO `tv_global_region` VALUES ('114', '8', '六盘水', '2');
INSERT INTO `tv_global_region` VALUES ('115', '8', '黔东南', '2');
INSERT INTO `tv_global_region` VALUES ('116', '8', '黔南', '2');
INSERT INTO `tv_global_region` VALUES ('117', '8', '黔西南', '2');
INSERT INTO `tv_global_region` VALUES ('118', '8', '铜仁', '2');
INSERT INTO `tv_global_region` VALUES ('119', '8', '遵义', '2');
INSERT INTO `tv_global_region` VALUES ('120', '9', '海口', '2');
INSERT INTO `tv_global_region` VALUES ('121', '9', '三亚', '2');
INSERT INTO `tv_global_region` VALUES ('122', '9', '白沙', '2');
INSERT INTO `tv_global_region` VALUES ('123', '9', '保亭', '2');
INSERT INTO `tv_global_region` VALUES ('124', '9', '昌江', '2');
INSERT INTO `tv_global_region` VALUES ('125', '9', '澄迈县', '2');
INSERT INTO `tv_global_region` VALUES ('126', '9', '定安县', '2');
INSERT INTO `tv_global_region` VALUES ('127', '9', '东方', '2');
INSERT INTO `tv_global_region` VALUES ('128', '9', '乐东', '2');
INSERT INTO `tv_global_region` VALUES ('129', '9', '临高县', '2');
INSERT INTO `tv_global_region` VALUES ('130', '9', '陵水', '2');
INSERT INTO `tv_global_region` VALUES ('131', '9', '琼海', '2');
INSERT INTO `tv_global_region` VALUES ('132', '9', '琼中', '2');
INSERT INTO `tv_global_region` VALUES ('133', '9', '屯昌县', '2');
INSERT INTO `tv_global_region` VALUES ('134', '9', '万宁', '2');
INSERT INTO `tv_global_region` VALUES ('135', '9', '文昌', '2');
INSERT INTO `tv_global_region` VALUES ('136', '9', '五指山', '2');
INSERT INTO `tv_global_region` VALUES ('137', '9', '儋州', '2');
INSERT INTO `tv_global_region` VALUES ('138', '10', '石家庄', '2');
INSERT INTO `tv_global_region` VALUES ('139', '10', '保定', '2');
INSERT INTO `tv_global_region` VALUES ('140', '10', '沧州', '2');
INSERT INTO `tv_global_region` VALUES ('141', '10', '承德', '2');
INSERT INTO `tv_global_region` VALUES ('142', '10', '邯郸', '2');
INSERT INTO `tv_global_region` VALUES ('143', '10', '衡水', '2');
INSERT INTO `tv_global_region` VALUES ('144', '10', '廊坊', '2');
INSERT INTO `tv_global_region` VALUES ('145', '10', '秦皇岛', '2');
INSERT INTO `tv_global_region` VALUES ('146', '10', '唐山', '2');
INSERT INTO `tv_global_region` VALUES ('147', '10', '邢台', '2');
INSERT INTO `tv_global_region` VALUES ('148', '10', '张家口', '2');
INSERT INTO `tv_global_region` VALUES ('149', '11', '郑州', '2');
INSERT INTO `tv_global_region` VALUES ('150', '11', '洛阳', '2');
INSERT INTO `tv_global_region` VALUES ('151', '11', '开封', '2');
INSERT INTO `tv_global_region` VALUES ('152', '11', '安阳', '2');
INSERT INTO `tv_global_region` VALUES ('153', '11', '鹤壁', '2');
INSERT INTO `tv_global_region` VALUES ('154', '11', '济源', '2');
INSERT INTO `tv_global_region` VALUES ('155', '11', '焦作', '2');
INSERT INTO `tv_global_region` VALUES ('156', '11', '南阳', '2');
INSERT INTO `tv_global_region` VALUES ('157', '11', '平顶山', '2');
INSERT INTO `tv_global_region` VALUES ('158', '11', '三门峡', '2');
INSERT INTO `tv_global_region` VALUES ('159', '11', '商丘', '2');
INSERT INTO `tv_global_region` VALUES ('160', '11', '新乡', '2');
INSERT INTO `tv_global_region` VALUES ('161', '11', '信阳', '2');
INSERT INTO `tv_global_region` VALUES ('162', '11', '许昌', '2');
INSERT INTO `tv_global_region` VALUES ('163', '11', '周口', '2');
INSERT INTO `tv_global_region` VALUES ('164', '11', '驻马店', '2');
INSERT INTO `tv_global_region` VALUES ('165', '11', '漯河', '2');
INSERT INTO `tv_global_region` VALUES ('166', '11', '濮阳', '2');
INSERT INTO `tv_global_region` VALUES ('167', '12', '哈尔滨', '2');
INSERT INTO `tv_global_region` VALUES ('168', '12', '大庆', '2');
INSERT INTO `tv_global_region` VALUES ('169', '12', '大兴安岭', '2');
INSERT INTO `tv_global_region` VALUES ('170', '12', '鹤岗', '2');
INSERT INTO `tv_global_region` VALUES ('171', '12', '黑河', '2');
INSERT INTO `tv_global_region` VALUES ('172', '12', '鸡西', '2');
INSERT INTO `tv_global_region` VALUES ('173', '12', '佳木斯', '2');
INSERT INTO `tv_global_region` VALUES ('174', '12', '牡丹江', '2');
INSERT INTO `tv_global_region` VALUES ('175', '12', '七台河', '2');
INSERT INTO `tv_global_region` VALUES ('176', '12', '齐齐哈尔', '2');
INSERT INTO `tv_global_region` VALUES ('177', '12', '双鸭山', '2');
INSERT INTO `tv_global_region` VALUES ('178', '12', '绥化', '2');
INSERT INTO `tv_global_region` VALUES ('179', '12', '伊春', '2');
INSERT INTO `tv_global_region` VALUES ('180', '13', '武汉', '2');
INSERT INTO `tv_global_region` VALUES ('181', '13', '仙桃', '2');
INSERT INTO `tv_global_region` VALUES ('182', '13', '鄂州', '2');
INSERT INTO `tv_global_region` VALUES ('183', '13', '黄冈', '2');
INSERT INTO `tv_global_region` VALUES ('184', '13', '黄石', '2');
INSERT INTO `tv_global_region` VALUES ('185', '13', '荆门', '2');
INSERT INTO `tv_global_region` VALUES ('186', '13', '荆州', '2');
INSERT INTO `tv_global_region` VALUES ('187', '13', '潜江', '2');
INSERT INTO `tv_global_region` VALUES ('188', '13', '神农架林区', '2');
INSERT INTO `tv_global_region` VALUES ('189', '13', '十堰', '2');
INSERT INTO `tv_global_region` VALUES ('190', '13', '随州', '2');
INSERT INTO `tv_global_region` VALUES ('191', '13', '天门', '2');
INSERT INTO `tv_global_region` VALUES ('192', '13', '咸宁', '2');
INSERT INTO `tv_global_region` VALUES ('193', '13', '襄樊', '2');
INSERT INTO `tv_global_region` VALUES ('194', '13', '孝感', '2');
INSERT INTO `tv_global_region` VALUES ('195', '13', '宜昌', '2');
INSERT INTO `tv_global_region` VALUES ('196', '13', '恩施', '2');
INSERT INTO `tv_global_region` VALUES ('197', '14', '长沙', '2');
INSERT INTO `tv_global_region` VALUES ('198', '14', '张家界', '2');
INSERT INTO `tv_global_region` VALUES ('199', '14', '常德', '2');
INSERT INTO `tv_global_region` VALUES ('200', '14', '郴州', '2');
INSERT INTO `tv_global_region` VALUES ('201', '14', '衡阳', '2');
INSERT INTO `tv_global_region` VALUES ('202', '14', '怀化', '2');
INSERT INTO `tv_global_region` VALUES ('203', '14', '娄底', '2');
INSERT INTO `tv_global_region` VALUES ('204', '14', '邵阳', '2');
INSERT INTO `tv_global_region` VALUES ('205', '14', '湘潭', '2');
INSERT INTO `tv_global_region` VALUES ('206', '14', '湘西', '2');
INSERT INTO `tv_global_region` VALUES ('207', '14', '益阳', '2');
INSERT INTO `tv_global_region` VALUES ('208', '14', '永州', '2');
INSERT INTO `tv_global_region` VALUES ('209', '14', '岳阳', '2');
INSERT INTO `tv_global_region` VALUES ('210', '14', '株洲', '2');
INSERT INTO `tv_global_region` VALUES ('211', '15', '长春', '2');
INSERT INTO `tv_global_region` VALUES ('212', '15', '吉林', '2');
INSERT INTO `tv_global_region` VALUES ('213', '15', '白城', '2');
INSERT INTO `tv_global_region` VALUES ('214', '15', '白山', '2');
INSERT INTO `tv_global_region` VALUES ('215', '15', '辽源', '2');
INSERT INTO `tv_global_region` VALUES ('216', '15', '四平', '2');
INSERT INTO `tv_global_region` VALUES ('217', '15', '松原', '2');
INSERT INTO `tv_global_region` VALUES ('218', '15', '通化', '2');
INSERT INTO `tv_global_region` VALUES ('219', '15', '延边', '2');
INSERT INTO `tv_global_region` VALUES ('220', '16', '南京', '2');
INSERT INTO `tv_global_region` VALUES ('221', '16', '苏州', '2');
INSERT INTO `tv_global_region` VALUES ('222', '16', '无锡', '2');
INSERT INTO `tv_global_region` VALUES ('223', '16', '常州', '2');
INSERT INTO `tv_global_region` VALUES ('224', '16', '淮安', '2');
INSERT INTO `tv_global_region` VALUES ('225', '16', '连云港', '2');
INSERT INTO `tv_global_region` VALUES ('226', '16', '南通', '2');
INSERT INTO `tv_global_region` VALUES ('227', '16', '宿迁', '2');
INSERT INTO `tv_global_region` VALUES ('228', '16', '泰州', '2');
INSERT INTO `tv_global_region` VALUES ('229', '16', '徐州', '2');
INSERT INTO `tv_global_region` VALUES ('230', '16', '盐城', '2');
INSERT INTO `tv_global_region` VALUES ('231', '16', '扬州', '2');
INSERT INTO `tv_global_region` VALUES ('232', '16', '镇江', '2');
INSERT INTO `tv_global_region` VALUES ('233', '17', '南昌', '2');
INSERT INTO `tv_global_region` VALUES ('234', '17', '抚州', '2');
INSERT INTO `tv_global_region` VALUES ('235', '17', '赣州', '2');
INSERT INTO `tv_global_region` VALUES ('236', '17', '吉安', '2');
INSERT INTO `tv_global_region` VALUES ('237', '17', '景德镇', '2');
INSERT INTO `tv_global_region` VALUES ('238', '17', '九江', '2');
INSERT INTO `tv_global_region` VALUES ('239', '17', '萍乡', '2');
INSERT INTO `tv_global_region` VALUES ('240', '17', '上饶', '2');
INSERT INTO `tv_global_region` VALUES ('241', '17', '新余', '2');
INSERT INTO `tv_global_region` VALUES ('242', '17', '宜春', '2');
INSERT INTO `tv_global_region` VALUES ('243', '17', '鹰潭', '2');
INSERT INTO `tv_global_region` VALUES ('244', '18', '沈阳', '2');
INSERT INTO `tv_global_region` VALUES ('245', '18', '大连', '2');
INSERT INTO `tv_global_region` VALUES ('246', '18', '鞍山', '2');
INSERT INTO `tv_global_region` VALUES ('247', '18', '本溪', '2');
INSERT INTO `tv_global_region` VALUES ('248', '18', '朝阳', '2');
INSERT INTO `tv_global_region` VALUES ('249', '18', '丹东', '2');
INSERT INTO `tv_global_region` VALUES ('250', '18', '抚顺', '2');
INSERT INTO `tv_global_region` VALUES ('251', '18', '阜新', '2');
INSERT INTO `tv_global_region` VALUES ('252', '18', '葫芦岛', '2');
INSERT INTO `tv_global_region` VALUES ('253', '18', '锦州', '2');
INSERT INTO `tv_global_region` VALUES ('254', '18', '辽阳', '2');
INSERT INTO `tv_global_region` VALUES ('255', '18', '盘锦', '2');
INSERT INTO `tv_global_region` VALUES ('256', '18', '铁岭', '2');
INSERT INTO `tv_global_region` VALUES ('257', '18', '营口', '2');
INSERT INTO `tv_global_region` VALUES ('258', '19', '呼和浩特', '2');
INSERT INTO `tv_global_region` VALUES ('259', '19', '阿拉善盟', '2');
INSERT INTO `tv_global_region` VALUES ('260', '19', '巴彦淖尔盟', '2');
INSERT INTO `tv_global_region` VALUES ('261', '19', '包头', '2');
INSERT INTO `tv_global_region` VALUES ('262', '19', '赤峰', '2');
INSERT INTO `tv_global_region` VALUES ('263', '19', '鄂尔多斯', '2');
INSERT INTO `tv_global_region` VALUES ('264', '19', '呼伦贝尔', '2');
INSERT INTO `tv_global_region` VALUES ('265', '19', '通辽', '2');
INSERT INTO `tv_global_region` VALUES ('266', '19', '乌海', '2');
INSERT INTO `tv_global_region` VALUES ('267', '19', '乌兰察布市', '2');
INSERT INTO `tv_global_region` VALUES ('268', '19', '锡林郭勒盟', '2');
INSERT INTO `tv_global_region` VALUES ('269', '19', '兴安盟', '2');
INSERT INTO `tv_global_region` VALUES ('270', '20', '银川', '2');
INSERT INTO `tv_global_region` VALUES ('271', '20', '固原', '2');
INSERT INTO `tv_global_region` VALUES ('272', '20', '石嘴山', '2');
INSERT INTO `tv_global_region` VALUES ('273', '20', '吴忠', '2');
INSERT INTO `tv_global_region` VALUES ('274', '20', '中卫', '2');
INSERT INTO `tv_global_region` VALUES ('275', '21', '西宁', '2');
INSERT INTO `tv_global_region` VALUES ('276', '21', '果洛', '2');
INSERT INTO `tv_global_region` VALUES ('277', '21', '海北', '2');
INSERT INTO `tv_global_region` VALUES ('278', '21', '海东', '2');
INSERT INTO `tv_global_region` VALUES ('279', '21', '海南', '2');
INSERT INTO `tv_global_region` VALUES ('280', '21', '海西', '2');
INSERT INTO `tv_global_region` VALUES ('281', '21', '黄南', '2');
INSERT INTO `tv_global_region` VALUES ('282', '21', '玉树', '2');
INSERT INTO `tv_global_region` VALUES ('283', '22', '济南', '2');
INSERT INTO `tv_global_region` VALUES ('284', '22', '青岛', '2');
INSERT INTO `tv_global_region` VALUES ('285', '22', '滨州', '2');
INSERT INTO `tv_global_region` VALUES ('286', '22', '德州', '2');
INSERT INTO `tv_global_region` VALUES ('287', '22', '东营', '2');
INSERT INTO `tv_global_region` VALUES ('288', '22', '菏泽', '2');
INSERT INTO `tv_global_region` VALUES ('289', '22', '济宁', '2');
INSERT INTO `tv_global_region` VALUES ('290', '22', '莱芜', '2');
INSERT INTO `tv_global_region` VALUES ('291', '22', '聊城', '2');
INSERT INTO `tv_global_region` VALUES ('292', '22', '临沂', '2');
INSERT INTO `tv_global_region` VALUES ('293', '22', '日照', '2');
INSERT INTO `tv_global_region` VALUES ('294', '22', '泰安', '2');
INSERT INTO `tv_global_region` VALUES ('295', '22', '威海', '2');
INSERT INTO `tv_global_region` VALUES ('296', '22', '潍坊', '2');
INSERT INTO `tv_global_region` VALUES ('297', '22', '烟台', '2');
INSERT INTO `tv_global_region` VALUES ('298', '22', '枣庄', '2');
INSERT INTO `tv_global_region` VALUES ('299', '22', '淄博', '2');
INSERT INTO `tv_global_region` VALUES ('300', '23', '太原', '2');
INSERT INTO `tv_global_region` VALUES ('301', '23', '长治', '2');
INSERT INTO `tv_global_region` VALUES ('302', '23', '大同', '2');
INSERT INTO `tv_global_region` VALUES ('303', '23', '晋城', '2');
INSERT INTO `tv_global_region` VALUES ('304', '23', '晋中', '2');
INSERT INTO `tv_global_region` VALUES ('305', '23', '临汾', '2');
INSERT INTO `tv_global_region` VALUES ('306', '23', '吕梁', '2');
INSERT INTO `tv_global_region` VALUES ('307', '23', '朔州', '2');
INSERT INTO `tv_global_region` VALUES ('308', '23', '忻州', '2');
INSERT INTO `tv_global_region` VALUES ('309', '23', '阳泉', '2');
INSERT INTO `tv_global_region` VALUES ('310', '23', '运城', '2');
INSERT INTO `tv_global_region` VALUES ('311', '24', '西安', '2');
INSERT INTO `tv_global_region` VALUES ('312', '24', '安康', '2');
INSERT INTO `tv_global_region` VALUES ('313', '24', '宝鸡', '2');
INSERT INTO `tv_global_region` VALUES ('314', '24', '汉中', '2');
INSERT INTO `tv_global_region` VALUES ('315', '24', '商洛', '2');
INSERT INTO `tv_global_region` VALUES ('316', '24', '铜川', '2');
INSERT INTO `tv_global_region` VALUES ('317', '24', '渭南', '2');
INSERT INTO `tv_global_region` VALUES ('318', '24', '咸阳', '2');
INSERT INTO `tv_global_region` VALUES ('319', '24', '延安', '2');
INSERT INTO `tv_global_region` VALUES ('320', '24', '榆林', '2');
INSERT INTO `tv_global_region` VALUES ('321', '25', '上海', '2');
INSERT INTO `tv_global_region` VALUES ('322', '26', '成都', '2');
INSERT INTO `tv_global_region` VALUES ('323', '26', '绵阳', '2');
INSERT INTO `tv_global_region` VALUES ('324', '26', '阿坝', '2');
INSERT INTO `tv_global_region` VALUES ('325', '26', '巴中', '2');
INSERT INTO `tv_global_region` VALUES ('326', '26', '达州', '2');
INSERT INTO `tv_global_region` VALUES ('327', '26', '德阳', '2');
INSERT INTO `tv_global_region` VALUES ('328', '26', '甘孜', '2');
INSERT INTO `tv_global_region` VALUES ('329', '26', '广安', '2');
INSERT INTO `tv_global_region` VALUES ('330', '26', '广元', '2');
INSERT INTO `tv_global_region` VALUES ('331', '26', '乐山', '2');
INSERT INTO `tv_global_region` VALUES ('332', '26', '凉山', '2');
INSERT INTO `tv_global_region` VALUES ('333', '26', '眉山', '2');
INSERT INTO `tv_global_region` VALUES ('334', '26', '南充', '2');
INSERT INTO `tv_global_region` VALUES ('335', '26', '内江', '2');
INSERT INTO `tv_global_region` VALUES ('336', '26', '攀枝花', '2');
INSERT INTO `tv_global_region` VALUES ('337', '26', '遂宁', '2');
INSERT INTO `tv_global_region` VALUES ('338', '26', '雅安', '2');
INSERT INTO `tv_global_region` VALUES ('339', '26', '宜宾', '2');
INSERT INTO `tv_global_region` VALUES ('340', '26', '资阳', '2');
INSERT INTO `tv_global_region` VALUES ('341', '26', '自贡', '2');
INSERT INTO `tv_global_region` VALUES ('342', '26', '泸州', '2');
INSERT INTO `tv_global_region` VALUES ('343', '27', '天津', '2');
INSERT INTO `tv_global_region` VALUES ('344', '28', '拉萨', '2');
INSERT INTO `tv_global_region` VALUES ('345', '28', '阿里', '2');
INSERT INTO `tv_global_region` VALUES ('346', '28', '昌都', '2');
INSERT INTO `tv_global_region` VALUES ('347', '28', '林芝', '2');
INSERT INTO `tv_global_region` VALUES ('348', '28', '那曲', '2');
INSERT INTO `tv_global_region` VALUES ('349', '28', '日喀则', '2');
INSERT INTO `tv_global_region` VALUES ('350', '28', '山南', '2');
INSERT INTO `tv_global_region` VALUES ('351', '29', '乌鲁木齐', '2');
INSERT INTO `tv_global_region` VALUES ('352', '29', '阿克苏', '2');
INSERT INTO `tv_global_region` VALUES ('353', '29', '阿拉尔', '2');
INSERT INTO `tv_global_region` VALUES ('354', '29', '巴音郭楞', '2');
INSERT INTO `tv_global_region` VALUES ('355', '29', '博尔塔拉', '2');
INSERT INTO `tv_global_region` VALUES ('356', '29', '昌吉', '2');
INSERT INTO `tv_global_region` VALUES ('357', '29', '哈密', '2');
INSERT INTO `tv_global_region` VALUES ('358', '29', '和田', '2');
INSERT INTO `tv_global_region` VALUES ('359', '29', '喀什', '2');
INSERT INTO `tv_global_region` VALUES ('360', '29', '克拉玛依', '2');
INSERT INTO `tv_global_region` VALUES ('361', '29', '克孜勒苏', '2');
INSERT INTO `tv_global_region` VALUES ('362', '29', '石河子', '2');
INSERT INTO `tv_global_region` VALUES ('363', '29', '图木舒克', '2');
INSERT INTO `tv_global_region` VALUES ('364', '29', '吐鲁番', '2');
INSERT INTO `tv_global_region` VALUES ('365', '29', '五家渠', '2');
INSERT INTO `tv_global_region` VALUES ('366', '29', '伊犁', '2');
INSERT INTO `tv_global_region` VALUES ('367', '30', '昆明', '2');
INSERT INTO `tv_global_region` VALUES ('368', '30', '怒江', '2');
INSERT INTO `tv_global_region` VALUES ('369', '30', '普洱', '2');
INSERT INTO `tv_global_region` VALUES ('370', '30', '丽江', '2');
INSERT INTO `tv_global_region` VALUES ('371', '30', '保山', '2');
INSERT INTO `tv_global_region` VALUES ('372', '30', '楚雄', '2');
INSERT INTO `tv_global_region` VALUES ('373', '30', '大理', '2');
INSERT INTO `tv_global_region` VALUES ('374', '30', '德宏', '2');
INSERT INTO `tv_global_region` VALUES ('375', '30', '迪庆', '2');
INSERT INTO `tv_global_region` VALUES ('376', '30', '红河', '2');
INSERT INTO `tv_global_region` VALUES ('377', '30', '临沧', '2');
INSERT INTO `tv_global_region` VALUES ('378', '30', '曲靖', '2');
INSERT INTO `tv_global_region` VALUES ('379', '30', '文山', '2');
INSERT INTO `tv_global_region` VALUES ('380', '30', '西双版纳', '2');
INSERT INTO `tv_global_region` VALUES ('381', '30', '玉溪', '2');
INSERT INTO `tv_global_region` VALUES ('382', '30', '昭通', '2');
INSERT INTO `tv_global_region` VALUES ('383', '31', '杭州', '2');
INSERT INTO `tv_global_region` VALUES ('384', '31', '湖州', '2');
INSERT INTO `tv_global_region` VALUES ('385', '31', '嘉兴', '2');
INSERT INTO `tv_global_region` VALUES ('386', '31', '金华', '2');
INSERT INTO `tv_global_region` VALUES ('387', '31', '丽水', '2');
INSERT INTO `tv_global_region` VALUES ('388', '31', '宁波', '2');
INSERT INTO `tv_global_region` VALUES ('389', '31', '绍兴', '2');
INSERT INTO `tv_global_region` VALUES ('390', '31', '台州', '2');
INSERT INTO `tv_global_region` VALUES ('391', '31', '温州', '2');
INSERT INTO `tv_global_region` VALUES ('392', '31', '舟山', '2');
INSERT INTO `tv_global_region` VALUES ('393', '31', '衢州', '2');
INSERT INTO `tv_global_region` VALUES ('394', '32', '重庆', '2');
INSERT INTO `tv_global_region` VALUES ('395', '33', '香港', '2');
INSERT INTO `tv_global_region` VALUES ('396', '34', '澳门', '2');
INSERT INTO `tv_global_region` VALUES ('397', '35', '台湾', '2');
INSERT INTO `tv_global_region` VALUES ('398', '36', '迎江区', '3');
INSERT INTO `tv_global_region` VALUES ('399', '36', '大观区', '3');
INSERT INTO `tv_global_region` VALUES ('400', '36', '宜秀区', '3');
INSERT INTO `tv_global_region` VALUES ('401', '36', '桐城市', '3');
INSERT INTO `tv_global_region` VALUES ('402', '36', '怀宁县', '3');
INSERT INTO `tv_global_region` VALUES ('403', '36', '枞阳县', '3');
INSERT INTO `tv_global_region` VALUES ('404', '36', '潜山县', '3');
INSERT INTO `tv_global_region` VALUES ('405', '36', '太湖县', '3');
INSERT INTO `tv_global_region` VALUES ('406', '36', '宿松县', '3');
INSERT INTO `tv_global_region` VALUES ('407', '36', '望江县', '3');
INSERT INTO `tv_global_region` VALUES ('408', '36', '岳西县', '3');
INSERT INTO `tv_global_region` VALUES ('409', '37', '中市区', '3');
INSERT INTO `tv_global_region` VALUES ('410', '37', '东市区', '3');
INSERT INTO `tv_global_region` VALUES ('411', '37', '西市区', '3');
INSERT INTO `tv_global_region` VALUES ('412', '37', '郊区', '3');
INSERT INTO `tv_global_region` VALUES ('413', '37', '怀远县', '3');
INSERT INTO `tv_global_region` VALUES ('414', '37', '五河县', '3');
INSERT INTO `tv_global_region` VALUES ('415', '37', '固镇县', '3');
INSERT INTO `tv_global_region` VALUES ('416', '38', '居巢区', '3');
INSERT INTO `tv_global_region` VALUES ('417', '38', '庐江县', '3');
INSERT INTO `tv_global_region` VALUES ('418', '38', '无为县', '3');
INSERT INTO `tv_global_region` VALUES ('419', '38', '含山县', '3');
INSERT INTO `tv_global_region` VALUES ('420', '38', '和县', '3');
INSERT INTO `tv_global_region` VALUES ('421', '39', '贵池区', '3');
INSERT INTO `tv_global_region` VALUES ('422', '39', '东至县', '3');
INSERT INTO `tv_global_region` VALUES ('423', '39', '石台县', '3');
INSERT INTO `tv_global_region` VALUES ('424', '39', '青阳县', '3');
INSERT INTO `tv_global_region` VALUES ('425', '40', '琅琊区', '3');
INSERT INTO `tv_global_region` VALUES ('426', '40', '南谯区', '3');
INSERT INTO `tv_global_region` VALUES ('427', '40', '天长市', '3');
INSERT INTO `tv_global_region` VALUES ('428', '40', '明光市', '3');
INSERT INTO `tv_global_region` VALUES ('429', '40', '来安县', '3');
INSERT INTO `tv_global_region` VALUES ('430', '40', '全椒县', '3');
INSERT INTO `tv_global_region` VALUES ('431', '40', '定远县', '3');
INSERT INTO `tv_global_region` VALUES ('432', '40', '凤阳县', '3');
INSERT INTO `tv_global_region` VALUES ('433', '41', '蚌山区', '3');
INSERT INTO `tv_global_region` VALUES ('434', '41', '龙子湖区', '3');
INSERT INTO `tv_global_region` VALUES ('435', '41', '禹会区', '3');
INSERT INTO `tv_global_region` VALUES ('436', '41', '淮上区', '3');
INSERT INTO `tv_global_region` VALUES ('437', '41', '颍州区', '3');
INSERT INTO `tv_global_region` VALUES ('438', '41', '颍东区', '3');
INSERT INTO `tv_global_region` VALUES ('439', '41', '颍泉区', '3');
INSERT INTO `tv_global_region` VALUES ('440', '41', '界首市', '3');
INSERT INTO `tv_global_region` VALUES ('441', '41', '临泉县', '3');
INSERT INTO `tv_global_region` VALUES ('442', '41', '太和县', '3');
INSERT INTO `tv_global_region` VALUES ('443', '41', '阜南县', '3');
INSERT INTO `tv_global_region` VALUES ('444', '41', '颖上县', '3');
INSERT INTO `tv_global_region` VALUES ('445', '42', '相山区', '3');
INSERT INTO `tv_global_region` VALUES ('446', '42', '杜集区', '3');
INSERT INTO `tv_global_region` VALUES ('447', '42', '烈山区', '3');
INSERT INTO `tv_global_region` VALUES ('448', '42', '濉溪县', '3');
INSERT INTO `tv_global_region` VALUES ('449', '43', '田家庵区', '3');
INSERT INTO `tv_global_region` VALUES ('450', '43', '大通区', '3');
INSERT INTO `tv_global_region` VALUES ('451', '43', '谢家集区', '3');
INSERT INTO `tv_global_region` VALUES ('452', '43', '八公山区', '3');
INSERT INTO `tv_global_region` VALUES ('453', '43', '潘集区', '3');
INSERT INTO `tv_global_region` VALUES ('454', '43', '凤台县', '3');
INSERT INTO `tv_global_region` VALUES ('455', '44', '屯溪区', '3');
INSERT INTO `tv_global_region` VALUES ('456', '44', '黄山区', '3');
INSERT INTO `tv_global_region` VALUES ('457', '44', '徽州区', '3');
INSERT INTO `tv_global_region` VALUES ('458', '44', '歙县', '3');
INSERT INTO `tv_global_region` VALUES ('459', '44', '休宁县', '3');
INSERT INTO `tv_global_region` VALUES ('460', '44', '黟县', '3');
INSERT INTO `tv_global_region` VALUES ('461', '44', '祁门县', '3');
INSERT INTO `tv_global_region` VALUES ('462', '45', '金安区', '3');
INSERT INTO `tv_global_region` VALUES ('463', '45', '裕安区', '3');
INSERT INTO `tv_global_region` VALUES ('464', '45', '寿县', '3');
INSERT INTO `tv_global_region` VALUES ('465', '45', '霍邱县', '3');
INSERT INTO `tv_global_region` VALUES ('466', '45', '舒城县', '3');
INSERT INTO `tv_global_region` VALUES ('467', '45', '金寨县', '3');
INSERT INTO `tv_global_region` VALUES ('468', '45', '霍山县', '3');
INSERT INTO `tv_global_region` VALUES ('469', '46', '雨山区', '3');
INSERT INTO `tv_global_region` VALUES ('470', '46', '花山区', '3');
INSERT INTO `tv_global_region` VALUES ('471', '46', '金家庄区', '3');
INSERT INTO `tv_global_region` VALUES ('472', '46', '当涂县', '3');
INSERT INTO `tv_global_region` VALUES ('473', '47', '埇桥区', '3');
INSERT INTO `tv_global_region` VALUES ('474', '47', '砀山县', '3');
INSERT INTO `tv_global_region` VALUES ('475', '47', '萧县', '3');
INSERT INTO `tv_global_region` VALUES ('476', '47', '灵璧县', '3');
INSERT INTO `tv_global_region` VALUES ('477', '47', '泗县', '3');
INSERT INTO `tv_global_region` VALUES ('478', '48', '铜官山区', '3');
INSERT INTO `tv_global_region` VALUES ('479', '48', '狮子山区', '3');
INSERT INTO `tv_global_region` VALUES ('480', '48', '郊区', '3');
INSERT INTO `tv_global_region` VALUES ('481', '48', '铜陵县', '3');
INSERT INTO `tv_global_region` VALUES ('482', '49', '镜湖区', '3');
INSERT INTO `tv_global_region` VALUES ('483', '49', '弋江区', '3');
INSERT INTO `tv_global_region` VALUES ('484', '49', '鸠江区', '3');
INSERT INTO `tv_global_region` VALUES ('485', '49', '三山区', '3');
INSERT INTO `tv_global_region` VALUES ('486', '49', '芜湖县', '3');
INSERT INTO `tv_global_region` VALUES ('487', '49', '繁昌县', '3');
INSERT INTO `tv_global_region` VALUES ('488', '49', '南陵县', '3');
INSERT INTO `tv_global_region` VALUES ('489', '50', '宣州区', '3');
INSERT INTO `tv_global_region` VALUES ('490', '50', '宁国市', '3');
INSERT INTO `tv_global_region` VALUES ('491', '50', '郎溪县', '3');
INSERT INTO `tv_global_region` VALUES ('492', '50', '广德县', '3');
INSERT INTO `tv_global_region` VALUES ('493', '50', '泾县', '3');
INSERT INTO `tv_global_region` VALUES ('494', '50', '绩溪县', '3');
INSERT INTO `tv_global_region` VALUES ('495', '50', '旌德县', '3');
INSERT INTO `tv_global_region` VALUES ('496', '51', '涡阳县', '3');
INSERT INTO `tv_global_region` VALUES ('497', '51', '蒙城县', '3');
INSERT INTO `tv_global_region` VALUES ('498', '51', '利辛县', '3');
INSERT INTO `tv_global_region` VALUES ('499', '51', '谯城区', '3');
INSERT INTO `tv_global_region` VALUES ('500', '52', '东城区', '3');
INSERT INTO `tv_global_region` VALUES ('501', '52', '西城区', '3');
INSERT INTO `tv_global_region` VALUES ('502', '52', '海淀区', '3');
INSERT INTO `tv_global_region` VALUES ('503', '52', '朝阳区', '3');
INSERT INTO `tv_global_region` VALUES ('504', '52', '崇文区', '3');
INSERT INTO `tv_global_region` VALUES ('505', '52', '宣武区', '3');
INSERT INTO `tv_global_region` VALUES ('506', '52', '丰台区', '3');
INSERT INTO `tv_global_region` VALUES ('507', '52', '石景山区', '3');
INSERT INTO `tv_global_region` VALUES ('508', '52', '房山区', '3');
INSERT INTO `tv_global_region` VALUES ('509', '52', '门头沟区', '3');
INSERT INTO `tv_global_region` VALUES ('510', '52', '通州区', '3');
INSERT INTO `tv_global_region` VALUES ('511', '52', '顺义区', '3');
INSERT INTO `tv_global_region` VALUES ('512', '52', '昌平区', '3');
INSERT INTO `tv_global_region` VALUES ('513', '52', '怀柔区', '3');
INSERT INTO `tv_global_region` VALUES ('514', '52', '平谷区', '3');
INSERT INTO `tv_global_region` VALUES ('515', '52', '大兴区', '3');
INSERT INTO `tv_global_region` VALUES ('516', '52', '密云县', '3');
INSERT INTO `tv_global_region` VALUES ('517', '52', '延庆县', '3');
INSERT INTO `tv_global_region` VALUES ('518', '53', '鼓楼区', '3');
INSERT INTO `tv_global_region` VALUES ('519', '53', '台江区', '3');
INSERT INTO `tv_global_region` VALUES ('520', '53', '仓山区', '3');
INSERT INTO `tv_global_region` VALUES ('521', '53', '马尾区', '3');
INSERT INTO `tv_global_region` VALUES ('522', '53', '晋安区', '3');
INSERT INTO `tv_global_region` VALUES ('523', '53', '福清市', '3');
INSERT INTO `tv_global_region` VALUES ('524', '53', '长乐市', '3');
INSERT INTO `tv_global_region` VALUES ('525', '53', '闽侯县', '3');
INSERT INTO `tv_global_region` VALUES ('526', '53', '连江县', '3');
INSERT INTO `tv_global_region` VALUES ('527', '53', '罗源县', '3');
INSERT INTO `tv_global_region` VALUES ('528', '53', '闽清县', '3');
INSERT INTO `tv_global_region` VALUES ('529', '53', '永泰县', '3');
INSERT INTO `tv_global_region` VALUES ('530', '53', '平潭县', '3');
INSERT INTO `tv_global_region` VALUES ('531', '54', '新罗区', '3');
INSERT INTO `tv_global_region` VALUES ('532', '54', '漳平市', '3');
INSERT INTO `tv_global_region` VALUES ('533', '54', '长汀县', '3');
INSERT INTO `tv_global_region` VALUES ('534', '54', '永定县', '3');
INSERT INTO `tv_global_region` VALUES ('535', '54', '上杭县', '3');
INSERT INTO `tv_global_region` VALUES ('536', '54', '武平县', '3');
INSERT INTO `tv_global_region` VALUES ('537', '54', '连城县', '3');
INSERT INTO `tv_global_region` VALUES ('538', '55', '延平区', '3');
INSERT INTO `tv_global_region` VALUES ('539', '55', '邵武市', '3');
INSERT INTO `tv_global_region` VALUES ('540', '55', '武夷山市', '3');
INSERT INTO `tv_global_region` VALUES ('541', '55', '建瓯市', '3');
INSERT INTO `tv_global_region` VALUES ('542', '55', '建阳市', '3');
INSERT INTO `tv_global_region` VALUES ('543', '55', '顺昌县', '3');
INSERT INTO `tv_global_region` VALUES ('544', '55', '浦城县', '3');
INSERT INTO `tv_global_region` VALUES ('545', '55', '光泽县', '3');
INSERT INTO `tv_global_region` VALUES ('546', '55', '松溪县', '3');
INSERT INTO `tv_global_region` VALUES ('547', '55', '政和县', '3');
INSERT INTO `tv_global_region` VALUES ('548', '56', '蕉城区', '3');
INSERT INTO `tv_global_region` VALUES ('549', '56', '福安市', '3');
INSERT INTO `tv_global_region` VALUES ('550', '56', '福鼎市', '3');
INSERT INTO `tv_global_region` VALUES ('551', '56', '霞浦县', '3');
INSERT INTO `tv_global_region` VALUES ('552', '56', '古田县', '3');
INSERT INTO `tv_global_region` VALUES ('553', '56', '屏南县', '3');
INSERT INTO `tv_global_region` VALUES ('554', '56', '寿宁县', '3');
INSERT INTO `tv_global_region` VALUES ('555', '56', '周宁县', '3');
INSERT INTO `tv_global_region` VALUES ('556', '56', '柘荣县', '3');
INSERT INTO `tv_global_region` VALUES ('557', '57', '城厢区', '3');
INSERT INTO `tv_global_region` VALUES ('558', '57', '涵江区', '3');
INSERT INTO `tv_global_region` VALUES ('559', '57', '荔城区', '3');
INSERT INTO `tv_global_region` VALUES ('560', '57', '秀屿区', '3');
INSERT INTO `tv_global_region` VALUES ('561', '57', '仙游县', '3');
INSERT INTO `tv_global_region` VALUES ('562', '58', '鲤城区', '3');
INSERT INTO `tv_global_region` VALUES ('563', '58', '丰泽区', '3');
INSERT INTO `tv_global_region` VALUES ('564', '58', '洛江区', '3');
INSERT INTO `tv_global_region` VALUES ('565', '58', '清濛开发区', '3');
INSERT INTO `tv_global_region` VALUES ('566', '58', '泉港区', '3');
INSERT INTO `tv_global_region` VALUES ('567', '58', '石狮市', '3');
INSERT INTO `tv_global_region` VALUES ('568', '58', '晋江市', '3');
INSERT INTO `tv_global_region` VALUES ('569', '58', '南安市', '3');
INSERT INTO `tv_global_region` VALUES ('570', '58', '惠安县', '3');
INSERT INTO `tv_global_region` VALUES ('571', '58', '安溪县', '3');
INSERT INTO `tv_global_region` VALUES ('572', '58', '永春县', '3');
INSERT INTO `tv_global_region` VALUES ('573', '58', '德化县', '3');
INSERT INTO `tv_global_region` VALUES ('574', '58', '金门县', '3');
INSERT INTO `tv_global_region` VALUES ('575', '59', '梅列区', '3');
INSERT INTO `tv_global_region` VALUES ('576', '59', '三元区', '3');
INSERT INTO `tv_global_region` VALUES ('577', '59', '永安市', '3');
INSERT INTO `tv_global_region` VALUES ('578', '59', '明溪县', '3');
INSERT INTO `tv_global_region` VALUES ('579', '59', '清流县', '3');
INSERT INTO `tv_global_region` VALUES ('580', '59', '宁化县', '3');
INSERT INTO `tv_global_region` VALUES ('581', '59', '大田县', '3');
INSERT INTO `tv_global_region` VALUES ('582', '59', '尤溪县', '3');
INSERT INTO `tv_global_region` VALUES ('583', '59', '沙县', '3');
INSERT INTO `tv_global_region` VALUES ('584', '59', '将乐县', '3');
INSERT INTO `tv_global_region` VALUES ('585', '59', '泰宁县', '3');
INSERT INTO `tv_global_region` VALUES ('586', '59', '建宁县', '3');
INSERT INTO `tv_global_region` VALUES ('587', '60', '思明区', '3');
INSERT INTO `tv_global_region` VALUES ('588', '60', '海沧区', '3');
INSERT INTO `tv_global_region` VALUES ('589', '60', '湖里区', '3');
INSERT INTO `tv_global_region` VALUES ('590', '60', '集美区', '3');
INSERT INTO `tv_global_region` VALUES ('591', '60', '同安区', '3');
INSERT INTO `tv_global_region` VALUES ('592', '60', '翔安区', '3');
INSERT INTO `tv_global_region` VALUES ('593', '61', '芗城区', '3');
INSERT INTO `tv_global_region` VALUES ('594', '61', '龙文区', '3');
INSERT INTO `tv_global_region` VALUES ('595', '61', '龙海市', '3');
INSERT INTO `tv_global_region` VALUES ('596', '61', '云霄县', '3');
INSERT INTO `tv_global_region` VALUES ('597', '61', '漳浦县', '3');
INSERT INTO `tv_global_region` VALUES ('598', '61', '诏安县', '3');
INSERT INTO `tv_global_region` VALUES ('599', '61', '长泰县', '3');
INSERT INTO `tv_global_region` VALUES ('600', '61', '东山县', '3');
INSERT INTO `tv_global_region` VALUES ('601', '61', '南靖县', '3');
INSERT INTO `tv_global_region` VALUES ('602', '61', '平和县', '3');
INSERT INTO `tv_global_region` VALUES ('603', '61', '华安县', '3');
INSERT INTO `tv_global_region` VALUES ('604', '62', '皋兰县', '3');
INSERT INTO `tv_global_region` VALUES ('605', '62', '城关区', '3');
INSERT INTO `tv_global_region` VALUES ('606', '62', '七里河区', '3');
INSERT INTO `tv_global_region` VALUES ('607', '62', '西固区', '3');
INSERT INTO `tv_global_region` VALUES ('608', '62', '安宁区', '3');
INSERT INTO `tv_global_region` VALUES ('609', '62', '红古区', '3');
INSERT INTO `tv_global_region` VALUES ('610', '62', '永登县', '3');
INSERT INTO `tv_global_region` VALUES ('611', '62', '榆中县', '3');
INSERT INTO `tv_global_region` VALUES ('612', '63', '白银区', '3');
INSERT INTO `tv_global_region` VALUES ('613', '63', '平川区', '3');
INSERT INTO `tv_global_region` VALUES ('614', '63', '会宁县', '3');
INSERT INTO `tv_global_region` VALUES ('615', '63', '景泰县', '3');
INSERT INTO `tv_global_region` VALUES ('616', '63', '靖远县', '3');
INSERT INTO `tv_global_region` VALUES ('617', '64', '临洮县', '3');
INSERT INTO `tv_global_region` VALUES ('618', '64', '陇西县', '3');
INSERT INTO `tv_global_region` VALUES ('619', '64', '通渭县', '3');
INSERT INTO `tv_global_region` VALUES ('620', '64', '渭源县', '3');
INSERT INTO `tv_global_region` VALUES ('621', '64', '漳县', '3');
INSERT INTO `tv_global_region` VALUES ('622', '64', '岷县', '3');
INSERT INTO `tv_global_region` VALUES ('623', '64', '安定区', '3');
INSERT INTO `tv_global_region` VALUES ('624', '64', '安定区', '3');
INSERT INTO `tv_global_region` VALUES ('625', '65', '合作市', '3');
INSERT INTO `tv_global_region` VALUES ('626', '65', '临潭县', '3');
INSERT INTO `tv_global_region` VALUES ('627', '65', '卓尼县', '3');
INSERT INTO `tv_global_region` VALUES ('628', '65', '舟曲县', '3');
INSERT INTO `tv_global_region` VALUES ('629', '65', '迭部县', '3');
INSERT INTO `tv_global_region` VALUES ('630', '65', '玛曲县', '3');
INSERT INTO `tv_global_region` VALUES ('631', '65', '碌曲县', '3');
INSERT INTO `tv_global_region` VALUES ('632', '65', '夏河县', '3');
INSERT INTO `tv_global_region` VALUES ('633', '66', '嘉峪关市', '3');
INSERT INTO `tv_global_region` VALUES ('634', '67', '金川区', '3');
INSERT INTO `tv_global_region` VALUES ('635', '67', '永昌县', '3');
INSERT INTO `tv_global_region` VALUES ('636', '68', '肃州区', '3');
INSERT INTO `tv_global_region` VALUES ('637', '68', '玉门市', '3');
INSERT INTO `tv_global_region` VALUES ('638', '68', '敦煌市', '3');
INSERT INTO `tv_global_region` VALUES ('639', '68', '金塔县', '3');
INSERT INTO `tv_global_region` VALUES ('640', '68', '瓜州县', '3');
INSERT INTO `tv_global_region` VALUES ('641', '68', '肃北', '3');
INSERT INTO `tv_global_region` VALUES ('642', '68', '阿克塞', '3');
INSERT INTO `tv_global_region` VALUES ('643', '69', '临夏市', '3');
INSERT INTO `tv_global_region` VALUES ('644', '69', '临夏县', '3');
INSERT INTO `tv_global_region` VALUES ('645', '69', '康乐县', '3');
INSERT INTO `tv_global_region` VALUES ('646', '69', '永靖县', '3');
INSERT INTO `tv_global_region` VALUES ('647', '69', '广河县', '3');
INSERT INTO `tv_global_region` VALUES ('648', '69', '和政县', '3');
INSERT INTO `tv_global_region` VALUES ('649', '69', '东乡族自治县', '3');
INSERT INTO `tv_global_region` VALUES ('650', '69', '积石山', '3');
INSERT INTO `tv_global_region` VALUES ('651', '70', '成县', '3');
INSERT INTO `tv_global_region` VALUES ('652', '70', '徽县', '3');
INSERT INTO `tv_global_region` VALUES ('653', '70', '康县', '3');
INSERT INTO `tv_global_region` VALUES ('654', '70', '礼县', '3');
INSERT INTO `tv_global_region` VALUES ('655', '70', '两当县', '3');
INSERT INTO `tv_global_region` VALUES ('656', '70', '文县', '3');
INSERT INTO `tv_global_region` VALUES ('657', '70', '西和县', '3');
INSERT INTO `tv_global_region` VALUES ('658', '70', '宕昌县', '3');
INSERT INTO `tv_global_region` VALUES ('659', '70', '武都区', '3');
INSERT INTO `tv_global_region` VALUES ('660', '71', '崇信县', '3');
INSERT INTO `tv_global_region` VALUES ('661', '71', '华亭县', '3');
INSERT INTO `tv_global_region` VALUES ('662', '71', '静宁县', '3');
INSERT INTO `tv_global_region` VALUES ('663', '71', '灵台县', '3');
INSERT INTO `tv_global_region` VALUES ('664', '71', '崆峒区', '3');
INSERT INTO `tv_global_region` VALUES ('665', '71', '庄浪县', '3');
INSERT INTO `tv_global_region` VALUES ('666', '71', '泾川县', '3');
INSERT INTO `tv_global_region` VALUES ('667', '72', '合水县', '3');
INSERT INTO `tv_global_region` VALUES ('668', '72', '华池县', '3');
INSERT INTO `tv_global_region` VALUES ('669', '72', '环县', '3');
INSERT INTO `tv_global_region` VALUES ('670', '72', '宁县', '3');
INSERT INTO `tv_global_region` VALUES ('671', '72', '庆城县', '3');
INSERT INTO `tv_global_region` VALUES ('672', '72', '西峰区', '3');
INSERT INTO `tv_global_region` VALUES ('673', '72', '镇原县', '3');
INSERT INTO `tv_global_region` VALUES ('674', '72', '正宁县', '3');
INSERT INTO `tv_global_region` VALUES ('675', '73', '甘谷县', '3');
INSERT INTO `tv_global_region` VALUES ('676', '73', '秦安县', '3');
INSERT INTO `tv_global_region` VALUES ('677', '73', '清水县', '3');
INSERT INTO `tv_global_region` VALUES ('678', '73', '秦州区', '3');
INSERT INTO `tv_global_region` VALUES ('679', '73', '麦积区', '3');
INSERT INTO `tv_global_region` VALUES ('680', '73', '武山县', '3');
INSERT INTO `tv_global_region` VALUES ('681', '73', '张家川', '3');
INSERT INTO `tv_global_region` VALUES ('682', '74', '古浪县', '3');
INSERT INTO `tv_global_region` VALUES ('683', '74', '民勤县', '3');
INSERT INTO `tv_global_region` VALUES ('684', '74', '天祝', '3');
INSERT INTO `tv_global_region` VALUES ('685', '74', '凉州区', '3');
INSERT INTO `tv_global_region` VALUES ('686', '75', '高台县', '3');
INSERT INTO `tv_global_region` VALUES ('687', '75', '临泽县', '3');
INSERT INTO `tv_global_region` VALUES ('688', '75', '民乐县', '3');
INSERT INTO `tv_global_region` VALUES ('689', '75', '山丹县', '3');
INSERT INTO `tv_global_region` VALUES ('690', '75', '肃南', '3');
INSERT INTO `tv_global_region` VALUES ('691', '75', '甘州区', '3');
INSERT INTO `tv_global_region` VALUES ('692', '76', '从化市', '3');
INSERT INTO `tv_global_region` VALUES ('693', '76', '天河区', '3');
INSERT INTO `tv_global_region` VALUES ('694', '76', '东山区', '3');
INSERT INTO `tv_global_region` VALUES ('695', '76', '白云区', '3');
INSERT INTO `tv_global_region` VALUES ('696', '76', '海珠区', '3');
INSERT INTO `tv_global_region` VALUES ('697', '76', '荔湾区', '3');
INSERT INTO `tv_global_region` VALUES ('698', '76', '越秀区', '3');
INSERT INTO `tv_global_region` VALUES ('699', '76', '黄埔区', '3');
INSERT INTO `tv_global_region` VALUES ('700', '76', '番禺区', '3');
INSERT INTO `tv_global_region` VALUES ('701', '76', '花都区', '3');
INSERT INTO `tv_global_region` VALUES ('702', '76', '增城区', '3');
INSERT INTO `tv_global_region` VALUES ('703', '76', '从化区', '3');
INSERT INTO `tv_global_region` VALUES ('704', '76', '市郊', '3');
INSERT INTO `tv_global_region` VALUES ('705', '77', '福田区', '3');
INSERT INTO `tv_global_region` VALUES ('706', '77', '罗湖区', '3');
INSERT INTO `tv_global_region` VALUES ('707', '77', '南山区', '3');
INSERT INTO `tv_global_region` VALUES ('708', '77', '宝安区', '3');
INSERT INTO `tv_global_region` VALUES ('709', '77', '龙岗区', '3');
INSERT INTO `tv_global_region` VALUES ('710', '77', '盐田区', '3');
INSERT INTO `tv_global_region` VALUES ('711', '78', '湘桥区', '3');
INSERT INTO `tv_global_region` VALUES ('712', '78', '潮安县', '3');
INSERT INTO `tv_global_region` VALUES ('713', '78', '饶平县', '3');
INSERT INTO `tv_global_region` VALUES ('714', '79', '南城区', '3');
INSERT INTO `tv_global_region` VALUES ('715', '79', '东城区', '3');
INSERT INTO `tv_global_region` VALUES ('716', '79', '万江区', '3');
INSERT INTO `tv_global_region` VALUES ('717', '79', '莞城区', '3');
INSERT INTO `tv_global_region` VALUES ('718', '79', '石龙镇', '3');
INSERT INTO `tv_global_region` VALUES ('719', '79', '虎门镇', '3');
INSERT INTO `tv_global_region` VALUES ('720', '79', '麻涌镇', '3');
INSERT INTO `tv_global_region` VALUES ('721', '79', '道滘镇', '3');
INSERT INTO `tv_global_region` VALUES ('722', '79', '石碣镇', '3');
INSERT INTO `tv_global_region` VALUES ('723', '79', '沙田镇', '3');
INSERT INTO `tv_global_region` VALUES ('724', '79', '望牛墩镇', '3');
INSERT INTO `tv_global_region` VALUES ('725', '79', '洪梅镇', '3');
INSERT INTO `tv_global_region` VALUES ('726', '79', '茶山镇', '3');
INSERT INTO `tv_global_region` VALUES ('727', '79', '寮步镇', '3');
INSERT INTO `tv_global_region` VALUES ('728', '79', '大岭山镇', '3');
INSERT INTO `tv_global_region` VALUES ('729', '79', '大朗镇', '3');
INSERT INTO `tv_global_region` VALUES ('730', '79', '黄江镇', '3');
INSERT INTO `tv_global_region` VALUES ('731', '79', '樟木头', '3');
INSERT INTO `tv_global_region` VALUES ('732', '79', '凤岗镇', '3');
INSERT INTO `tv_global_region` VALUES ('733', '79', '塘厦镇', '3');
INSERT INTO `tv_global_region` VALUES ('734', '79', '谢岗镇', '3');
INSERT INTO `tv_global_region` VALUES ('735', '79', '厚街镇', '3');
INSERT INTO `tv_global_region` VALUES ('736', '79', '清溪镇', '3');
INSERT INTO `tv_global_region` VALUES ('737', '79', '常平镇', '3');
INSERT INTO `tv_global_region` VALUES ('738', '79', '桥头镇', '3');
INSERT INTO `tv_global_region` VALUES ('739', '79', '横沥镇', '3');
INSERT INTO `tv_global_region` VALUES ('740', '79', '东坑镇', '3');
INSERT INTO `tv_global_region` VALUES ('741', '79', '企石镇', '3');
INSERT INTO `tv_global_region` VALUES ('742', '79', '石排镇', '3');
INSERT INTO `tv_global_region` VALUES ('743', '79', '长安镇', '3');
INSERT INTO `tv_global_region` VALUES ('744', '79', '中堂镇', '3');
INSERT INTO `tv_global_region` VALUES ('745', '79', '高埗镇', '3');
INSERT INTO `tv_global_region` VALUES ('746', '80', '禅城区', '3');
INSERT INTO `tv_global_region` VALUES ('747', '80', '南海区', '3');
INSERT INTO `tv_global_region` VALUES ('748', '80', '顺德区', '3');
INSERT INTO `tv_global_region` VALUES ('749', '80', '三水区', '3');
INSERT INTO `tv_global_region` VALUES ('750', '80', '高明区', '3');
INSERT INTO `tv_global_region` VALUES ('751', '81', '东源县', '3');
INSERT INTO `tv_global_region` VALUES ('752', '81', '和平县', '3');
INSERT INTO `tv_global_region` VALUES ('753', '81', '源城区', '3');
INSERT INTO `tv_global_region` VALUES ('754', '81', '连平县', '3');
INSERT INTO `tv_global_region` VALUES ('755', '81', '龙川县', '3');
INSERT INTO `tv_global_region` VALUES ('756', '81', '紫金县', '3');
INSERT INTO `tv_global_region` VALUES ('757', '82', '惠阳区', '3');
INSERT INTO `tv_global_region` VALUES ('758', '82', '惠城区', '3');
INSERT INTO `tv_global_region` VALUES ('759', '82', '大亚湾', '3');
INSERT INTO `tv_global_region` VALUES ('760', '82', '博罗县', '3');
INSERT INTO `tv_global_region` VALUES ('761', '82', '惠东县', '3');
INSERT INTO `tv_global_region` VALUES ('762', '82', '龙门县', '3');
INSERT INTO `tv_global_region` VALUES ('763', '83', '江海区', '3');
INSERT INTO `tv_global_region` VALUES ('764', '83', '蓬江区', '3');
INSERT INTO `tv_global_region` VALUES ('765', '83', '新会区', '3');
INSERT INTO `tv_global_region` VALUES ('766', '83', '台山市', '3');
INSERT INTO `tv_global_region` VALUES ('767', '83', '开平市', '3');
INSERT INTO `tv_global_region` VALUES ('768', '83', '鹤山市', '3');
INSERT INTO `tv_global_region` VALUES ('769', '83', '恩平市', '3');
INSERT INTO `tv_global_region` VALUES ('770', '84', '榕城区', '3');
INSERT INTO `tv_global_region` VALUES ('771', '84', '普宁市', '3');
INSERT INTO `tv_global_region` VALUES ('772', '84', '揭东县', '3');
INSERT INTO `tv_global_region` VALUES ('773', '84', '揭西县', '3');
INSERT INTO `tv_global_region` VALUES ('774', '84', '惠来县', '3');
INSERT INTO `tv_global_region` VALUES ('775', '85', '茂南区', '3');
INSERT INTO `tv_global_region` VALUES ('776', '85', '茂港区', '3');
INSERT INTO `tv_global_region` VALUES ('777', '85', '高州市', '3');
INSERT INTO `tv_global_region` VALUES ('778', '85', '化州市', '3');
INSERT INTO `tv_global_region` VALUES ('779', '85', '信宜市', '3');
INSERT INTO `tv_global_region` VALUES ('780', '85', '电白县', '3');
INSERT INTO `tv_global_region` VALUES ('781', '86', '梅县', '3');
INSERT INTO `tv_global_region` VALUES ('782', '86', '梅江区', '3');
INSERT INTO `tv_global_region` VALUES ('783', '86', '兴宁市', '3');
INSERT INTO `tv_global_region` VALUES ('784', '86', '大埔县', '3');
INSERT INTO `tv_global_region` VALUES ('785', '86', '丰顺县', '3');
INSERT INTO `tv_global_region` VALUES ('786', '86', '五华县', '3');
INSERT INTO `tv_global_region` VALUES ('787', '86', '平远县', '3');
INSERT INTO `tv_global_region` VALUES ('788', '86', '蕉岭县', '3');
INSERT INTO `tv_global_region` VALUES ('789', '87', '清城区', '3');
INSERT INTO `tv_global_region` VALUES ('790', '87', '英德市', '3');
INSERT INTO `tv_global_region` VALUES ('791', '87', '连州市', '3');
INSERT INTO `tv_global_region` VALUES ('792', '87', '佛冈县', '3');
INSERT INTO `tv_global_region` VALUES ('793', '87', '阳山县', '3');
INSERT INTO `tv_global_region` VALUES ('794', '87', '清新县', '3');
INSERT INTO `tv_global_region` VALUES ('795', '87', '连山', '3');
INSERT INTO `tv_global_region` VALUES ('796', '87', '连南', '3');
INSERT INTO `tv_global_region` VALUES ('797', '88', '南澳县', '3');
INSERT INTO `tv_global_region` VALUES ('798', '88', '潮阳区', '3');
INSERT INTO `tv_global_region` VALUES ('799', '88', '澄海区', '3');
INSERT INTO `tv_global_region` VALUES ('800', '88', '龙湖区', '3');
INSERT INTO `tv_global_region` VALUES ('801', '88', '金平区', '3');
INSERT INTO `tv_global_region` VALUES ('802', '88', '濠江区', '3');
INSERT INTO `tv_global_region` VALUES ('803', '88', '潮南区', '3');
INSERT INTO `tv_global_region` VALUES ('804', '89', '城区', '3');
INSERT INTO `tv_global_region` VALUES ('805', '89', '陆丰市', '3');
INSERT INTO `tv_global_region` VALUES ('806', '89', '海丰县', '3');
INSERT INTO `tv_global_region` VALUES ('807', '89', '陆河县', '3');
INSERT INTO `tv_global_region` VALUES ('808', '90', '曲江县', '3');
INSERT INTO `tv_global_region` VALUES ('809', '90', '浈江区', '3');
INSERT INTO `tv_global_region` VALUES ('810', '90', '武江区', '3');
INSERT INTO `tv_global_region` VALUES ('811', '90', '曲江区', '3');
INSERT INTO `tv_global_region` VALUES ('812', '90', '乐昌市', '3');
INSERT INTO `tv_global_region` VALUES ('813', '90', '南雄市', '3');
INSERT INTO `tv_global_region` VALUES ('814', '90', '始兴县', '3');
INSERT INTO `tv_global_region` VALUES ('815', '90', '仁化县', '3');
INSERT INTO `tv_global_region` VALUES ('816', '90', '翁源县', '3');
INSERT INTO `tv_global_region` VALUES ('817', '90', '新丰县', '3');
INSERT INTO `tv_global_region` VALUES ('818', '90', '乳源', '3');
INSERT INTO `tv_global_region` VALUES ('819', '91', '江城区', '3');
INSERT INTO `tv_global_region` VALUES ('820', '91', '阳春市', '3');
INSERT INTO `tv_global_region` VALUES ('821', '91', '阳西县', '3');
INSERT INTO `tv_global_region` VALUES ('822', '91', '阳东县', '3');
INSERT INTO `tv_global_region` VALUES ('823', '92', '云城区', '3');
INSERT INTO `tv_global_region` VALUES ('824', '92', '罗定市', '3');
INSERT INTO `tv_global_region` VALUES ('825', '92', '新兴县', '3');
INSERT INTO `tv_global_region` VALUES ('826', '92', '郁南县', '3');
INSERT INTO `tv_global_region` VALUES ('827', '92', '云安县', '3');
INSERT INTO `tv_global_region` VALUES ('828', '93', '赤坎区', '3');
INSERT INTO `tv_global_region` VALUES ('829', '93', '霞山区', '3');
INSERT INTO `tv_global_region` VALUES ('830', '93', '坡头区', '3');
INSERT INTO `tv_global_region` VALUES ('831', '93', '麻章区', '3');
INSERT INTO `tv_global_region` VALUES ('832', '93', '廉江市', '3');
INSERT INTO `tv_global_region` VALUES ('833', '93', '雷州市', '3');
INSERT INTO `tv_global_region` VALUES ('834', '93', '吴川市', '3');
INSERT INTO `tv_global_region` VALUES ('835', '93', '遂溪县', '3');
INSERT INTO `tv_global_region` VALUES ('836', '93', '徐闻县', '3');
INSERT INTO `tv_global_region` VALUES ('837', '94', '肇庆市', '3');
INSERT INTO `tv_global_region` VALUES ('838', '94', '高要市', '3');
INSERT INTO `tv_global_region` VALUES ('839', '94', '四会市', '3');
INSERT INTO `tv_global_region` VALUES ('840', '94', '广宁县', '3');
INSERT INTO `tv_global_region` VALUES ('841', '94', '怀集县', '3');
INSERT INTO `tv_global_region` VALUES ('842', '94', '封开县', '3');
INSERT INTO `tv_global_region` VALUES ('843', '94', '德庆县', '3');
INSERT INTO `tv_global_region` VALUES ('844', '95', '石岐街道', '3');
INSERT INTO `tv_global_region` VALUES ('845', '95', '东区街道', '3');
INSERT INTO `tv_global_region` VALUES ('846', '95', '西区街道', '3');
INSERT INTO `tv_global_region` VALUES ('847', '95', '环城街道', '3');
INSERT INTO `tv_global_region` VALUES ('848', '95', '中山港街道', '3');
INSERT INTO `tv_global_region` VALUES ('849', '95', '五桂山街道', '3');
INSERT INTO `tv_global_region` VALUES ('850', '96', '香洲区', '3');
INSERT INTO `tv_global_region` VALUES ('851', '96', '斗门区', '3');
INSERT INTO `tv_global_region` VALUES ('852', '96', '金湾区', '3');
INSERT INTO `tv_global_region` VALUES ('853', '97', '邕宁区', '3');
INSERT INTO `tv_global_region` VALUES ('854', '97', '青秀区', '3');
INSERT INTO `tv_global_region` VALUES ('855', '97', '兴宁区', '3');
INSERT INTO `tv_global_region` VALUES ('856', '97', '良庆区', '3');
INSERT INTO `tv_global_region` VALUES ('857', '97', '西乡塘区', '3');
INSERT INTO `tv_global_region` VALUES ('858', '97', '江南区', '3');
INSERT INTO `tv_global_region` VALUES ('859', '97', '武鸣县', '3');
INSERT INTO `tv_global_region` VALUES ('860', '97', '隆安县', '3');
INSERT INTO `tv_global_region` VALUES ('861', '97', '马山县', '3');
INSERT INTO `tv_global_region` VALUES ('862', '97', '上林县', '3');
INSERT INTO `tv_global_region` VALUES ('863', '97', '宾阳县', '3');
INSERT INTO `tv_global_region` VALUES ('864', '97', '横县', '3');
INSERT INTO `tv_global_region` VALUES ('865', '98', '秀峰区', '3');
INSERT INTO `tv_global_region` VALUES ('866', '98', '叠彩区', '3');
INSERT INTO `tv_global_region` VALUES ('867', '98', '象山区', '3');
INSERT INTO `tv_global_region` VALUES ('868', '98', '七星区', '3');
INSERT INTO `tv_global_region` VALUES ('869', '98', '雁山区', '3');
INSERT INTO `tv_global_region` VALUES ('870', '98', '阳朔县', '3');
INSERT INTO `tv_global_region` VALUES ('871', '98', '临桂县', '3');
INSERT INTO `tv_global_region` VALUES ('872', '98', '灵川县', '3');
INSERT INTO `tv_global_region` VALUES ('873', '98', '全州县', '3');
INSERT INTO `tv_global_region` VALUES ('874', '98', '平乐县', '3');
INSERT INTO `tv_global_region` VALUES ('875', '98', '兴安县', '3');
INSERT INTO `tv_global_region` VALUES ('876', '98', '灌阳县', '3');
INSERT INTO `tv_global_region` VALUES ('877', '98', '荔浦县', '3');
INSERT INTO `tv_global_region` VALUES ('878', '98', '资源县', '3');
INSERT INTO `tv_global_region` VALUES ('879', '98', '永福县', '3');
INSERT INTO `tv_global_region` VALUES ('880', '98', '龙胜', '3');
INSERT INTO `tv_global_region` VALUES ('881', '98', '恭城', '3');
INSERT INTO `tv_global_region` VALUES ('882', '99', '右江区', '3');
INSERT INTO `tv_global_region` VALUES ('883', '99', '凌云县', '3');
INSERT INTO `tv_global_region` VALUES ('884', '99', '平果县', '3');
INSERT INTO `tv_global_region` VALUES ('885', '99', '西林县', '3');
INSERT INTO `tv_global_region` VALUES ('886', '99', '乐业县', '3');
INSERT INTO `tv_global_region` VALUES ('887', '99', '德保县', '3');
INSERT INTO `tv_global_region` VALUES ('888', '99', '田林县', '3');
INSERT INTO `tv_global_region` VALUES ('889', '99', '田阳县', '3');
INSERT INTO `tv_global_region` VALUES ('890', '99', '靖西县', '3');
INSERT INTO `tv_global_region` VALUES ('891', '99', '田东县', '3');
INSERT INTO `tv_global_region` VALUES ('892', '99', '那坡县', '3');
INSERT INTO `tv_global_region` VALUES ('893', '99', '隆林', '3');
INSERT INTO `tv_global_region` VALUES ('894', '100', '海城区', '3');
INSERT INTO `tv_global_region` VALUES ('895', '100', '银海区', '3');
INSERT INTO `tv_global_region` VALUES ('896', '100', '铁山港区', '3');
INSERT INTO `tv_global_region` VALUES ('897', '100', '合浦县', '3');
INSERT INTO `tv_global_region` VALUES ('898', '101', '江州区', '3');
INSERT INTO `tv_global_region` VALUES ('899', '101', '凭祥市', '3');
INSERT INTO `tv_global_region` VALUES ('900', '101', '宁明县', '3');
INSERT INTO `tv_global_region` VALUES ('901', '101', '扶绥县', '3');
INSERT INTO `tv_global_region` VALUES ('902', '101', '龙州县', '3');
INSERT INTO `tv_global_region` VALUES ('903', '101', '大新县', '3');
INSERT INTO `tv_global_region` VALUES ('904', '101', '天等县', '3');
INSERT INTO `tv_global_region` VALUES ('905', '102', '港口区', '3');
INSERT INTO `tv_global_region` VALUES ('906', '102', '防城区', '3');
INSERT INTO `tv_global_region` VALUES ('907', '102', '东兴市', '3');
INSERT INTO `tv_global_region` VALUES ('908', '102', '上思县', '3');
INSERT INTO `tv_global_region` VALUES ('909', '103', '港北区', '3');
INSERT INTO `tv_global_region` VALUES ('910', '103', '港南区', '3');
INSERT INTO `tv_global_region` VALUES ('911', '103', '覃塘区', '3');
INSERT INTO `tv_global_region` VALUES ('912', '103', '桂平市', '3');
INSERT INTO `tv_global_region` VALUES ('913', '103', '平南县', '3');
INSERT INTO `tv_global_region` VALUES ('914', '104', '金城江区', '3');
INSERT INTO `tv_global_region` VALUES ('915', '104', '宜州市', '3');
INSERT INTO `tv_global_region` VALUES ('916', '104', '天峨县', '3');
INSERT INTO `tv_global_region` VALUES ('917', '104', '凤山县', '3');
INSERT INTO `tv_global_region` VALUES ('918', '104', '南丹县', '3');
INSERT INTO `tv_global_region` VALUES ('919', '104', '东兰县', '3');
INSERT INTO `tv_global_region` VALUES ('920', '104', '都安', '3');
INSERT INTO `tv_global_region` VALUES ('921', '104', '罗城', '3');
INSERT INTO `tv_global_region` VALUES ('922', '104', '巴马', '3');
INSERT INTO `tv_global_region` VALUES ('923', '104', '环江', '3');
INSERT INTO `tv_global_region` VALUES ('924', '104', '大化', '3');
INSERT INTO `tv_global_region` VALUES ('925', '105', '八步区', '3');
INSERT INTO `tv_global_region` VALUES ('926', '105', '钟山县', '3');
INSERT INTO `tv_global_region` VALUES ('927', '105', '昭平县', '3');
INSERT INTO `tv_global_region` VALUES ('928', '105', '富川', '3');
INSERT INTO `tv_global_region` VALUES ('929', '106', '兴宾区', '3');
INSERT INTO `tv_global_region` VALUES ('930', '106', '合山市', '3');
INSERT INTO `tv_global_region` VALUES ('931', '106', '象州县', '3');
INSERT INTO `tv_global_region` VALUES ('932', '106', '武宣县', '3');
INSERT INTO `tv_global_region` VALUES ('933', '106', '忻城县', '3');
INSERT INTO `tv_global_region` VALUES ('934', '106', '金秀', '3');
INSERT INTO `tv_global_region` VALUES ('935', '107', '城中区', '3');
INSERT INTO `tv_global_region` VALUES ('936', '107', '鱼峰区', '3');
INSERT INTO `tv_global_region` VALUES ('937', '107', '柳北区', '3');
INSERT INTO `tv_global_region` VALUES ('938', '107', '柳南区', '3');
INSERT INTO `tv_global_region` VALUES ('939', '107', '柳江县', '3');
INSERT INTO `tv_global_region` VALUES ('940', '107', '柳城县', '3');
INSERT INTO `tv_global_region` VALUES ('941', '107', '鹿寨县', '3');
INSERT INTO `tv_global_region` VALUES ('942', '107', '融安县', '3');
INSERT INTO `tv_global_region` VALUES ('943', '107', '融水', '3');
INSERT INTO `tv_global_region` VALUES ('944', '107', '三江', '3');
INSERT INTO `tv_global_region` VALUES ('945', '108', '钦南区', '3');
INSERT INTO `tv_global_region` VALUES ('946', '108', '钦北区', '3');
INSERT INTO `tv_global_region` VALUES ('947', '108', '灵山县', '3');
INSERT INTO `tv_global_region` VALUES ('948', '108', '浦北县', '3');
INSERT INTO `tv_global_region` VALUES ('949', '109', '万秀区', '3');
INSERT INTO `tv_global_region` VALUES ('950', '109', '蝶山区', '3');
INSERT INTO `tv_global_region` VALUES ('951', '109', '长洲区', '3');
INSERT INTO `tv_global_region` VALUES ('952', '109', '岑溪市', '3');
INSERT INTO `tv_global_region` VALUES ('953', '109', '苍梧县', '3');
INSERT INTO `tv_global_region` VALUES ('954', '109', '藤县', '3');
INSERT INTO `tv_global_region` VALUES ('955', '109', '蒙山县', '3');
INSERT INTO `tv_global_region` VALUES ('956', '110', '玉州区', '3');
INSERT INTO `tv_global_region` VALUES ('957', '110', '北流市', '3');
INSERT INTO `tv_global_region` VALUES ('958', '110', '容县', '3');
INSERT INTO `tv_global_region` VALUES ('959', '110', '陆川县', '3');
INSERT INTO `tv_global_region` VALUES ('960', '110', '博白县', '3');
INSERT INTO `tv_global_region` VALUES ('961', '110', '兴业县', '3');
INSERT INTO `tv_global_region` VALUES ('962', '111', '南明区', '3');
INSERT INTO `tv_global_region` VALUES ('963', '111', '云岩区', '3');
INSERT INTO `tv_global_region` VALUES ('964', '111', '花溪区', '3');
INSERT INTO `tv_global_region` VALUES ('965', '111', '乌当区', '3');
INSERT INTO `tv_global_region` VALUES ('966', '111', '白云区', '3');
INSERT INTO `tv_global_region` VALUES ('967', '111', '小河区', '3');
INSERT INTO `tv_global_region` VALUES ('968', '111', '金阳新区', '3');
INSERT INTO `tv_global_region` VALUES ('969', '111', '新天园区', '3');
INSERT INTO `tv_global_region` VALUES ('970', '111', '清镇市', '3');
INSERT INTO `tv_global_region` VALUES ('971', '111', '开阳县', '3');
INSERT INTO `tv_global_region` VALUES ('972', '111', '修文县', '3');
INSERT INTO `tv_global_region` VALUES ('973', '111', '息烽县', '3');
INSERT INTO `tv_global_region` VALUES ('974', '112', '西秀区', '3');
INSERT INTO `tv_global_region` VALUES ('975', '112', '关岭', '3');
INSERT INTO `tv_global_region` VALUES ('976', '112', '镇宁', '3');
INSERT INTO `tv_global_region` VALUES ('977', '112', '紫云', '3');
INSERT INTO `tv_global_region` VALUES ('978', '112', '平坝县', '3');
INSERT INTO `tv_global_region` VALUES ('979', '112', '普定县', '3');
INSERT INTO `tv_global_region` VALUES ('980', '113', '毕节市', '3');
INSERT INTO `tv_global_region` VALUES ('981', '113', '大方县', '3');
INSERT INTO `tv_global_region` VALUES ('982', '113', '黔西县', '3');
INSERT INTO `tv_global_region` VALUES ('983', '113', '金沙县', '3');
INSERT INTO `tv_global_region` VALUES ('984', '113', '织金县', '3');
INSERT INTO `tv_global_region` VALUES ('985', '113', '纳雍县', '3');
INSERT INTO `tv_global_region` VALUES ('986', '113', '赫章县', '3');
INSERT INTO `tv_global_region` VALUES ('987', '113', '威宁', '3');
INSERT INTO `tv_global_region` VALUES ('988', '114', '钟山区', '3');
INSERT INTO `tv_global_region` VALUES ('989', '114', '六枝特区', '3');
INSERT INTO `tv_global_region` VALUES ('990', '114', '水城县', '3');
INSERT INTO `tv_global_region` VALUES ('991', '114', '盘县', '3');
INSERT INTO `tv_global_region` VALUES ('992', '115', '凯里市', '3');
INSERT INTO `tv_global_region` VALUES ('993', '115', '黄平县', '3');
INSERT INTO `tv_global_region` VALUES ('994', '115', '施秉县', '3');
INSERT INTO `tv_global_region` VALUES ('995', '115', '三穗县', '3');
INSERT INTO `tv_global_region` VALUES ('996', '115', '镇远县', '3');
INSERT INTO `tv_global_region` VALUES ('997', '115', '岑巩县', '3');
INSERT INTO `tv_global_region` VALUES ('998', '115', '天柱县', '3');
INSERT INTO `tv_global_region` VALUES ('999', '115', '锦屏县', '3');
INSERT INTO `tv_global_region` VALUES ('1000', '115', '剑河县', '3');
INSERT INTO `tv_global_region` VALUES ('1001', '115', '台江县', '3');
INSERT INTO `tv_global_region` VALUES ('1002', '115', '黎平县', '3');
INSERT INTO `tv_global_region` VALUES ('1003', '115', '榕江县', '3');
INSERT INTO `tv_global_region` VALUES ('1004', '115', '从江县', '3');
INSERT INTO `tv_global_region` VALUES ('1005', '115', '雷山县', '3');
INSERT INTO `tv_global_region` VALUES ('1006', '115', '麻江县', '3');
INSERT INTO `tv_global_region` VALUES ('1007', '115', '丹寨县', '3');
INSERT INTO `tv_global_region` VALUES ('1008', '116', '都匀市', '3');
INSERT INTO `tv_global_region` VALUES ('1009', '116', '福泉市', '3');
INSERT INTO `tv_global_region` VALUES ('1010', '116', '荔波县', '3');
INSERT INTO `tv_global_region` VALUES ('1011', '116', '贵定县', '3');
INSERT INTO `tv_global_region` VALUES ('1012', '116', '瓮安县', '3');
INSERT INTO `tv_global_region` VALUES ('1013', '116', '独山县', '3');
INSERT INTO `tv_global_region` VALUES ('1014', '116', '平塘县', '3');
INSERT INTO `tv_global_region` VALUES ('1015', '116', '罗甸县', '3');
INSERT INTO `tv_global_region` VALUES ('1016', '116', '长顺县', '3');
INSERT INTO `tv_global_region` VALUES ('1017', '116', '龙里县', '3');
INSERT INTO `tv_global_region` VALUES ('1018', '116', '惠水县', '3');
INSERT INTO `tv_global_region` VALUES ('1019', '116', '三都', '3');
INSERT INTO `tv_global_region` VALUES ('1020', '117', '兴义市', '3');
INSERT INTO `tv_global_region` VALUES ('1021', '117', '兴仁县', '3');
INSERT INTO `tv_global_region` VALUES ('1022', '117', '普安县', '3');
INSERT INTO `tv_global_region` VALUES ('1023', '117', '晴隆县', '3');
INSERT INTO `tv_global_region` VALUES ('1024', '117', '贞丰县', '3');
INSERT INTO `tv_global_region` VALUES ('1025', '117', '望谟县', '3');
INSERT INTO `tv_global_region` VALUES ('1026', '117', '册亨县', '3');
INSERT INTO `tv_global_region` VALUES ('1027', '117', '安龙县', '3');
INSERT INTO `tv_global_region` VALUES ('1028', '118', '铜仁市', '3');
INSERT INTO `tv_global_region` VALUES ('1029', '118', '江口县', '3');
INSERT INTO `tv_global_region` VALUES ('1030', '118', '石阡县', '3');
INSERT INTO `tv_global_region` VALUES ('1031', '118', '思南县', '3');
INSERT INTO `tv_global_region` VALUES ('1032', '118', '德江县', '3');
INSERT INTO `tv_global_region` VALUES ('1033', '118', '玉屏', '3');
INSERT INTO `tv_global_region` VALUES ('1034', '118', '印江', '3');
INSERT INTO `tv_global_region` VALUES ('1035', '118', '沿河', '3');
INSERT INTO `tv_global_region` VALUES ('1036', '118', '松桃', '3');
INSERT INTO `tv_global_region` VALUES ('1037', '118', '万山特区', '3');
INSERT INTO `tv_global_region` VALUES ('1038', '119', '红花岗区', '3');
INSERT INTO `tv_global_region` VALUES ('1039', '119', '务川县', '3');
INSERT INTO `tv_global_region` VALUES ('1040', '119', '道真县', '3');
INSERT INTO `tv_global_region` VALUES ('1041', '119', '汇川区', '3');
INSERT INTO `tv_global_region` VALUES ('1042', '119', '赤水市', '3');
INSERT INTO `tv_global_region` VALUES ('1043', '119', '仁怀市', '3');
INSERT INTO `tv_global_region` VALUES ('1044', '119', '遵义县', '3');
INSERT INTO `tv_global_region` VALUES ('1045', '119', '桐梓县', '3');
INSERT INTO `tv_global_region` VALUES ('1046', '119', '绥阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1047', '119', '正安县', '3');
INSERT INTO `tv_global_region` VALUES ('1048', '119', '凤冈县', '3');
INSERT INTO `tv_global_region` VALUES ('1049', '119', '湄潭县', '3');
INSERT INTO `tv_global_region` VALUES ('1050', '119', '余庆县', '3');
INSERT INTO `tv_global_region` VALUES ('1051', '119', '习水县', '3');
INSERT INTO `tv_global_region` VALUES ('1052', '119', '道真', '3');
INSERT INTO `tv_global_region` VALUES ('1053', '119', '务川', '3');
INSERT INTO `tv_global_region` VALUES ('1054', '120', '秀英区', '3');
INSERT INTO `tv_global_region` VALUES ('1055', '120', '龙华区', '3');
INSERT INTO `tv_global_region` VALUES ('1056', '120', '琼山区', '3');
INSERT INTO `tv_global_region` VALUES ('1057', '120', '美兰区', '3');
INSERT INTO `tv_global_region` VALUES ('1058', '137', '市区', '3');
INSERT INTO `tv_global_region` VALUES ('1059', '137', '洋浦开发区', '3');
INSERT INTO `tv_global_region` VALUES ('1060', '137', '那大镇', '3');
INSERT INTO `tv_global_region` VALUES ('1061', '137', '王五镇', '3');
INSERT INTO `tv_global_region` VALUES ('1062', '137', '雅星镇', '3');
INSERT INTO `tv_global_region` VALUES ('1063', '137', '大成镇', '3');
INSERT INTO `tv_global_region` VALUES ('1064', '137', '中和镇', '3');
INSERT INTO `tv_global_region` VALUES ('1065', '137', '峨蔓镇', '3');
INSERT INTO `tv_global_region` VALUES ('1066', '137', '南丰镇', '3');
INSERT INTO `tv_global_region` VALUES ('1067', '137', '白马井镇', '3');
INSERT INTO `tv_global_region` VALUES ('1068', '137', '兰洋镇', '3');
INSERT INTO `tv_global_region` VALUES ('1069', '137', '和庆镇', '3');
INSERT INTO `tv_global_region` VALUES ('1070', '137', '海头镇', '3');
INSERT INTO `tv_global_region` VALUES ('1071', '137', '排浦镇', '3');
INSERT INTO `tv_global_region` VALUES ('1072', '137', '东成镇', '3');
INSERT INTO `tv_global_region` VALUES ('1073', '137', '光村镇', '3');
INSERT INTO `tv_global_region` VALUES ('1074', '137', '木棠镇', '3');
INSERT INTO `tv_global_region` VALUES ('1075', '137', '新州镇', '3');
INSERT INTO `tv_global_region` VALUES ('1076', '137', '三都镇', '3');
INSERT INTO `tv_global_region` VALUES ('1077', '137', '其他', '3');
INSERT INTO `tv_global_region` VALUES ('1078', '138', '长安区', '3');
INSERT INTO `tv_global_region` VALUES ('1079', '138', '桥东区', '3');
INSERT INTO `tv_global_region` VALUES ('1080', '138', '桥西区', '3');
INSERT INTO `tv_global_region` VALUES ('1081', '138', '新华区', '3');
INSERT INTO `tv_global_region` VALUES ('1082', '138', '裕华区', '3');
INSERT INTO `tv_global_region` VALUES ('1083', '138', '井陉矿区', '3');
INSERT INTO `tv_global_region` VALUES ('1084', '138', '高新区', '3');
INSERT INTO `tv_global_region` VALUES ('1085', '138', '辛集市', '3');
INSERT INTO `tv_global_region` VALUES ('1086', '138', '藁城市', '3');
INSERT INTO `tv_global_region` VALUES ('1087', '138', '晋州市', '3');
INSERT INTO `tv_global_region` VALUES ('1088', '138', '新乐市', '3');
INSERT INTO `tv_global_region` VALUES ('1089', '138', '鹿泉市', '3');
INSERT INTO `tv_global_region` VALUES ('1090', '138', '井陉县', '3');
INSERT INTO `tv_global_region` VALUES ('1091', '138', '正定县', '3');
INSERT INTO `tv_global_region` VALUES ('1092', '138', '栾城县', '3');
INSERT INTO `tv_global_region` VALUES ('1093', '138', '行唐县', '3');
INSERT INTO `tv_global_region` VALUES ('1094', '138', '灵寿县', '3');
INSERT INTO `tv_global_region` VALUES ('1095', '138', '高邑县', '3');
INSERT INTO `tv_global_region` VALUES ('1096', '138', '深泽县', '3');
INSERT INTO `tv_global_region` VALUES ('1097', '138', '赞皇县', '3');
INSERT INTO `tv_global_region` VALUES ('1098', '138', '无极县', '3');
INSERT INTO `tv_global_region` VALUES ('1099', '138', '平山县', '3');
INSERT INTO `tv_global_region` VALUES ('1100', '138', '元氏县', '3');
INSERT INTO `tv_global_region` VALUES ('1101', '138', '赵县', '3');
INSERT INTO `tv_global_region` VALUES ('1102', '139', '新市区', '3');
INSERT INTO `tv_global_region` VALUES ('1103', '139', '南市区', '3');
INSERT INTO `tv_global_region` VALUES ('1104', '139', '北市区', '3');
INSERT INTO `tv_global_region` VALUES ('1105', '139', '涿州市', '3');
INSERT INTO `tv_global_region` VALUES ('1106', '139', '定州市', '3');
INSERT INTO `tv_global_region` VALUES ('1107', '139', '安国市', '3');
INSERT INTO `tv_global_region` VALUES ('1108', '139', '高碑店市', '3');
INSERT INTO `tv_global_region` VALUES ('1109', '139', '满城县', '3');
INSERT INTO `tv_global_region` VALUES ('1110', '139', '清苑县', '3');
INSERT INTO `tv_global_region` VALUES ('1111', '139', '涞水县', '3');
INSERT INTO `tv_global_region` VALUES ('1112', '139', '阜平县', '3');
INSERT INTO `tv_global_region` VALUES ('1113', '139', '徐水县', '3');
INSERT INTO `tv_global_region` VALUES ('1114', '139', '定兴县', '3');
INSERT INTO `tv_global_region` VALUES ('1115', '139', '唐县', '3');
INSERT INTO `tv_global_region` VALUES ('1116', '139', '高阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1117', '139', '容城县', '3');
INSERT INTO `tv_global_region` VALUES ('1118', '139', '涞源县', '3');
INSERT INTO `tv_global_region` VALUES ('1119', '139', '望都县', '3');
INSERT INTO `tv_global_region` VALUES ('1120', '139', '安新县', '3');
INSERT INTO `tv_global_region` VALUES ('1121', '139', '易县', '3');
INSERT INTO `tv_global_region` VALUES ('1122', '139', '曲阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1123', '139', '蠡县', '3');
INSERT INTO `tv_global_region` VALUES ('1124', '139', '顺平县', '3');
INSERT INTO `tv_global_region` VALUES ('1125', '139', '博野县', '3');
INSERT INTO `tv_global_region` VALUES ('1126', '139', '雄县', '3');
INSERT INTO `tv_global_region` VALUES ('1127', '140', '运河区', '3');
INSERT INTO `tv_global_region` VALUES ('1128', '140', '新华区', '3');
INSERT INTO `tv_global_region` VALUES ('1129', '140', '泊头市', '3');
INSERT INTO `tv_global_region` VALUES ('1130', '140', '任丘市', '3');
INSERT INTO `tv_global_region` VALUES ('1131', '140', '黄骅市', '3');
INSERT INTO `tv_global_region` VALUES ('1132', '140', '河间市', '3');
INSERT INTO `tv_global_region` VALUES ('1133', '140', '沧县', '3');
INSERT INTO `tv_global_region` VALUES ('1134', '140', '青县', '3');
INSERT INTO `tv_global_region` VALUES ('1135', '140', '东光县', '3');
INSERT INTO `tv_global_region` VALUES ('1136', '140', '海兴县', '3');
INSERT INTO `tv_global_region` VALUES ('1137', '140', '盐山县', '3');
INSERT INTO `tv_global_region` VALUES ('1138', '140', '肃宁县', '3');
INSERT INTO `tv_global_region` VALUES ('1139', '140', '南皮县', '3');
INSERT INTO `tv_global_region` VALUES ('1140', '140', '吴桥县', '3');
INSERT INTO `tv_global_region` VALUES ('1141', '140', '献县', '3');
INSERT INTO `tv_global_region` VALUES ('1142', '140', '孟村', '3');
INSERT INTO `tv_global_region` VALUES ('1143', '141', '双桥区', '3');
INSERT INTO `tv_global_region` VALUES ('1144', '141', '双滦区', '3');
INSERT INTO `tv_global_region` VALUES ('1145', '141', '鹰手营子矿区', '3');
INSERT INTO `tv_global_region` VALUES ('1146', '141', '承德县', '3');
INSERT INTO `tv_global_region` VALUES ('1147', '141', '兴隆县', '3');
INSERT INTO `tv_global_region` VALUES ('1148', '141', '平泉县', '3');
INSERT INTO `tv_global_region` VALUES ('1149', '141', '滦平县', '3');
INSERT INTO `tv_global_region` VALUES ('1150', '141', '隆化县', '3');
INSERT INTO `tv_global_region` VALUES ('1151', '141', '丰宁', '3');
INSERT INTO `tv_global_region` VALUES ('1152', '141', '宽城', '3');
INSERT INTO `tv_global_region` VALUES ('1153', '141', '围场', '3');
INSERT INTO `tv_global_region` VALUES ('1154', '142', '从台区', '3');
INSERT INTO `tv_global_region` VALUES ('1155', '142', '复兴区', '3');
INSERT INTO `tv_global_region` VALUES ('1156', '142', '邯山区', '3');
INSERT INTO `tv_global_region` VALUES ('1157', '142', '峰峰矿区', '3');
INSERT INTO `tv_global_region` VALUES ('1158', '142', '武安市', '3');
INSERT INTO `tv_global_region` VALUES ('1159', '142', '邯郸县', '3');
INSERT INTO `tv_global_region` VALUES ('1160', '142', '临漳县', '3');
INSERT INTO `tv_global_region` VALUES ('1161', '142', '成安县', '3');
INSERT INTO `tv_global_region` VALUES ('1162', '142', '大名县', '3');
INSERT INTO `tv_global_region` VALUES ('1163', '142', '涉县', '3');
INSERT INTO `tv_global_region` VALUES ('1164', '142', '磁县', '3');
INSERT INTO `tv_global_region` VALUES ('1165', '142', '肥乡县', '3');
INSERT INTO `tv_global_region` VALUES ('1166', '142', '永年县', '3');
INSERT INTO `tv_global_region` VALUES ('1167', '142', '邱县', '3');
INSERT INTO `tv_global_region` VALUES ('1168', '142', '鸡泽县', '3');
INSERT INTO `tv_global_region` VALUES ('1169', '142', '广平县', '3');
INSERT INTO `tv_global_region` VALUES ('1170', '142', '馆陶县', '3');
INSERT INTO `tv_global_region` VALUES ('1171', '142', '魏县', '3');
INSERT INTO `tv_global_region` VALUES ('1172', '142', '曲周县', '3');
INSERT INTO `tv_global_region` VALUES ('1173', '143', '桃城区', '3');
INSERT INTO `tv_global_region` VALUES ('1174', '143', '冀州市', '3');
INSERT INTO `tv_global_region` VALUES ('1175', '143', '深州市', '3');
INSERT INTO `tv_global_region` VALUES ('1176', '143', '枣强县', '3');
INSERT INTO `tv_global_region` VALUES ('1177', '143', '武邑县', '3');
INSERT INTO `tv_global_region` VALUES ('1178', '143', '武强县', '3');
INSERT INTO `tv_global_region` VALUES ('1179', '143', '饶阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1180', '143', '安平县', '3');
INSERT INTO `tv_global_region` VALUES ('1181', '143', '故城县', '3');
INSERT INTO `tv_global_region` VALUES ('1182', '143', '景县', '3');
INSERT INTO `tv_global_region` VALUES ('1183', '143', '阜城县', '3');
INSERT INTO `tv_global_region` VALUES ('1184', '144', '安次区', '3');
INSERT INTO `tv_global_region` VALUES ('1185', '144', '广阳区', '3');
INSERT INTO `tv_global_region` VALUES ('1186', '144', '霸州市', '3');
INSERT INTO `tv_global_region` VALUES ('1187', '144', '三河市', '3');
INSERT INTO `tv_global_region` VALUES ('1188', '144', '固安县', '3');
INSERT INTO `tv_global_region` VALUES ('1189', '144', '永清县', '3');
INSERT INTO `tv_global_region` VALUES ('1190', '144', '香河县', '3');
INSERT INTO `tv_global_region` VALUES ('1191', '144', '大城县', '3');
INSERT INTO `tv_global_region` VALUES ('1192', '144', '文安县', '3');
INSERT INTO `tv_global_region` VALUES ('1193', '144', '大厂', '3');
INSERT INTO `tv_global_region` VALUES ('1194', '145', '海港区', '3');
INSERT INTO `tv_global_region` VALUES ('1195', '145', '山海关区', '3');
INSERT INTO `tv_global_region` VALUES ('1196', '145', '北戴河区', '3');
INSERT INTO `tv_global_region` VALUES ('1197', '145', '昌黎县', '3');
INSERT INTO `tv_global_region` VALUES ('1198', '145', '抚宁县', '3');
INSERT INTO `tv_global_region` VALUES ('1199', '145', '卢龙县', '3');
INSERT INTO `tv_global_region` VALUES ('1200', '145', '青龙', '3');
INSERT INTO `tv_global_region` VALUES ('1201', '146', '路北区', '3');
INSERT INTO `tv_global_region` VALUES ('1202', '146', '路南区', '3');
INSERT INTO `tv_global_region` VALUES ('1203', '146', '古冶区', '3');
INSERT INTO `tv_global_region` VALUES ('1204', '146', '开平区', '3');
INSERT INTO `tv_global_region` VALUES ('1205', '146', '丰南区', '3');
INSERT INTO `tv_global_region` VALUES ('1206', '146', '丰润区', '3');
INSERT INTO `tv_global_region` VALUES ('1207', '146', '遵化市', '3');
INSERT INTO `tv_global_region` VALUES ('1208', '146', '迁安市', '3');
INSERT INTO `tv_global_region` VALUES ('1209', '146', '滦县', '3');
INSERT INTO `tv_global_region` VALUES ('1210', '146', '滦南县', '3');
INSERT INTO `tv_global_region` VALUES ('1211', '146', '乐亭县', '3');
INSERT INTO `tv_global_region` VALUES ('1212', '146', '迁西县', '3');
INSERT INTO `tv_global_region` VALUES ('1213', '146', '玉田县', '3');
INSERT INTO `tv_global_region` VALUES ('1214', '146', '唐海县', '3');
INSERT INTO `tv_global_region` VALUES ('1215', '147', '桥东区', '3');
INSERT INTO `tv_global_region` VALUES ('1216', '147', '桥西区', '3');
INSERT INTO `tv_global_region` VALUES ('1217', '147', '南宫市', '3');
INSERT INTO `tv_global_region` VALUES ('1218', '147', '沙河市', '3');
INSERT INTO `tv_global_region` VALUES ('1219', '147', '邢台县', '3');
INSERT INTO `tv_global_region` VALUES ('1220', '147', '临城县', '3');
INSERT INTO `tv_global_region` VALUES ('1221', '147', '内丘县', '3');
INSERT INTO `tv_global_region` VALUES ('1222', '147', '柏乡县', '3');
INSERT INTO `tv_global_region` VALUES ('1223', '147', '隆尧县', '3');
INSERT INTO `tv_global_region` VALUES ('1224', '147', '任县', '3');
INSERT INTO `tv_global_region` VALUES ('1225', '147', '南和县', '3');
INSERT INTO `tv_global_region` VALUES ('1226', '147', '宁晋县', '3');
INSERT INTO `tv_global_region` VALUES ('1227', '147', '巨鹿县', '3');
INSERT INTO `tv_global_region` VALUES ('1228', '147', '新河县', '3');
INSERT INTO `tv_global_region` VALUES ('1229', '147', '广宗县', '3');
INSERT INTO `tv_global_region` VALUES ('1230', '147', '平乡县', '3');
INSERT INTO `tv_global_region` VALUES ('1231', '147', '威县', '3');
INSERT INTO `tv_global_region` VALUES ('1232', '147', '清河县', '3');
INSERT INTO `tv_global_region` VALUES ('1233', '147', '临西县', '3');
INSERT INTO `tv_global_region` VALUES ('1234', '148', '桥西区', '3');
INSERT INTO `tv_global_region` VALUES ('1235', '148', '桥东区', '3');
INSERT INTO `tv_global_region` VALUES ('1236', '148', '宣化区', '3');
INSERT INTO `tv_global_region` VALUES ('1237', '148', '下花园区', '3');
INSERT INTO `tv_global_region` VALUES ('1238', '148', '宣化县', '3');
INSERT INTO `tv_global_region` VALUES ('1239', '148', '张北县', '3');
INSERT INTO `tv_global_region` VALUES ('1240', '148', '康保县', '3');
INSERT INTO `tv_global_region` VALUES ('1241', '148', '沽源县', '3');
INSERT INTO `tv_global_region` VALUES ('1242', '148', '尚义县', '3');
INSERT INTO `tv_global_region` VALUES ('1243', '148', '蔚县', '3');
INSERT INTO `tv_global_region` VALUES ('1244', '148', '阳原县', '3');
INSERT INTO `tv_global_region` VALUES ('1245', '148', '怀安县', '3');
INSERT INTO `tv_global_region` VALUES ('1246', '148', '万全县', '3');
INSERT INTO `tv_global_region` VALUES ('1247', '148', '怀来县', '3');
INSERT INTO `tv_global_region` VALUES ('1248', '148', '涿鹿县', '3');
INSERT INTO `tv_global_region` VALUES ('1249', '148', '赤城县', '3');
INSERT INTO `tv_global_region` VALUES ('1250', '148', '崇礼县', '3');
INSERT INTO `tv_global_region` VALUES ('1251', '149', '金水区', '3');
INSERT INTO `tv_global_region` VALUES ('1252', '149', '邙山区', '3');
INSERT INTO `tv_global_region` VALUES ('1253', '149', '二七区', '3');
INSERT INTO `tv_global_region` VALUES ('1254', '149', '管城区', '3');
INSERT INTO `tv_global_region` VALUES ('1255', '149', '中原区', '3');
INSERT INTO `tv_global_region` VALUES ('1256', '149', '上街区', '3');
INSERT INTO `tv_global_region` VALUES ('1257', '149', '惠济区', '3');
INSERT INTO `tv_global_region` VALUES ('1258', '149', '郑东新区', '3');
INSERT INTO `tv_global_region` VALUES ('1259', '149', '经济技术开发区', '3');
INSERT INTO `tv_global_region` VALUES ('1260', '149', '高新开发区', '3');
INSERT INTO `tv_global_region` VALUES ('1261', '149', '出口加工区', '3');
INSERT INTO `tv_global_region` VALUES ('1262', '149', '巩义市', '3');
INSERT INTO `tv_global_region` VALUES ('1263', '149', '荥阳市', '3');
INSERT INTO `tv_global_region` VALUES ('1264', '149', '新密市', '3');
INSERT INTO `tv_global_region` VALUES ('1265', '149', '新郑市', '3');
INSERT INTO `tv_global_region` VALUES ('1266', '149', '登封市', '3');
INSERT INTO `tv_global_region` VALUES ('1267', '149', '中牟县', '3');
INSERT INTO `tv_global_region` VALUES ('1268', '150', '西工区', '3');
INSERT INTO `tv_global_region` VALUES ('1269', '150', '老城区', '3');
INSERT INTO `tv_global_region` VALUES ('1270', '150', '涧西区', '3');
INSERT INTO `tv_global_region` VALUES ('1271', '150', '瀍河回族区', '3');
INSERT INTO `tv_global_region` VALUES ('1272', '150', '洛龙区', '3');
INSERT INTO `tv_global_region` VALUES ('1273', '150', '吉利区', '3');
INSERT INTO `tv_global_region` VALUES ('1274', '150', '偃师市', '3');
INSERT INTO `tv_global_region` VALUES ('1275', '150', '孟津县', '3');
INSERT INTO `tv_global_region` VALUES ('1276', '150', '新安县', '3');
INSERT INTO `tv_global_region` VALUES ('1277', '150', '栾川县', '3');
INSERT INTO `tv_global_region` VALUES ('1278', '150', '嵩县', '3');
INSERT INTO `tv_global_region` VALUES ('1279', '150', '汝阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1280', '150', '宜阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1281', '150', '洛宁县', '3');
INSERT INTO `tv_global_region` VALUES ('1282', '150', '伊川县', '3');
INSERT INTO `tv_global_region` VALUES ('1283', '151', '鼓楼区', '3');
INSERT INTO `tv_global_region` VALUES ('1284', '151', '龙亭区', '3');
INSERT INTO `tv_global_region` VALUES ('1285', '151', '顺河回族区', '3');
INSERT INTO `tv_global_region` VALUES ('1286', '151', '金明区', '3');
INSERT INTO `tv_global_region` VALUES ('1287', '151', '禹王台区', '3');
INSERT INTO `tv_global_region` VALUES ('1288', '151', '杞县', '3');
INSERT INTO `tv_global_region` VALUES ('1289', '151', '通许县', '3');
INSERT INTO `tv_global_region` VALUES ('1290', '151', '尉氏县', '3');
INSERT INTO `tv_global_region` VALUES ('1291', '151', '开封县', '3');
INSERT INTO `tv_global_region` VALUES ('1292', '151', '兰考县', '3');
INSERT INTO `tv_global_region` VALUES ('1293', '152', '北关区', '3');
INSERT INTO `tv_global_region` VALUES ('1294', '152', '文峰区', '3');
INSERT INTO `tv_global_region` VALUES ('1295', '152', '殷都区', '3');
INSERT INTO `tv_global_region` VALUES ('1296', '152', '龙安区', '3');
INSERT INTO `tv_global_region` VALUES ('1297', '152', '林州市', '3');
INSERT INTO `tv_global_region` VALUES ('1298', '152', '安阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1299', '152', '汤阴县', '3');
INSERT INTO `tv_global_region` VALUES ('1300', '152', '滑县', '3');
INSERT INTO `tv_global_region` VALUES ('1301', '152', '内黄县', '3');
INSERT INTO `tv_global_region` VALUES ('1302', '153', '淇滨区', '3');
INSERT INTO `tv_global_region` VALUES ('1303', '153', '山城区', '3');
INSERT INTO `tv_global_region` VALUES ('1304', '153', '鹤山区', '3');
INSERT INTO `tv_global_region` VALUES ('1305', '153', '浚县', '3');
INSERT INTO `tv_global_region` VALUES ('1306', '153', '淇县', '3');
INSERT INTO `tv_global_region` VALUES ('1307', '154', '济源市', '3');
INSERT INTO `tv_global_region` VALUES ('1308', '155', '解放区', '3');
INSERT INTO `tv_global_region` VALUES ('1309', '155', '中站区', '3');
INSERT INTO `tv_global_region` VALUES ('1310', '155', '马村区', '3');
INSERT INTO `tv_global_region` VALUES ('1311', '155', '山阳区', '3');
INSERT INTO `tv_global_region` VALUES ('1312', '155', '沁阳市', '3');
INSERT INTO `tv_global_region` VALUES ('1313', '155', '孟州市', '3');
INSERT INTO `tv_global_region` VALUES ('1314', '155', '修武县', '3');
INSERT INTO `tv_global_region` VALUES ('1315', '155', '博爱县', '3');
INSERT INTO `tv_global_region` VALUES ('1316', '155', '武陟县', '3');
INSERT INTO `tv_global_region` VALUES ('1317', '155', '温县', '3');
INSERT INTO `tv_global_region` VALUES ('1318', '156', '卧龙区', '3');
INSERT INTO `tv_global_region` VALUES ('1319', '156', '宛城区', '3');
INSERT INTO `tv_global_region` VALUES ('1320', '156', '邓州市', '3');
INSERT INTO `tv_global_region` VALUES ('1321', '156', '南召县', '3');
INSERT INTO `tv_global_region` VALUES ('1322', '156', '方城县', '3');
INSERT INTO `tv_global_region` VALUES ('1323', '156', '西峡县', '3');
INSERT INTO `tv_global_region` VALUES ('1324', '156', '镇平县', '3');
INSERT INTO `tv_global_region` VALUES ('1325', '156', '内乡县', '3');
INSERT INTO `tv_global_region` VALUES ('1326', '156', '淅川县', '3');
INSERT INTO `tv_global_region` VALUES ('1327', '156', '社旗县', '3');
INSERT INTO `tv_global_region` VALUES ('1328', '156', '唐河县', '3');
INSERT INTO `tv_global_region` VALUES ('1329', '156', '新野县', '3');
INSERT INTO `tv_global_region` VALUES ('1330', '156', '桐柏县', '3');
INSERT INTO `tv_global_region` VALUES ('1331', '157', '新华区', '3');
INSERT INTO `tv_global_region` VALUES ('1332', '157', '卫东区', '3');
INSERT INTO `tv_global_region` VALUES ('1333', '157', '湛河区', '3');
INSERT INTO `tv_global_region` VALUES ('1334', '157', '石龙区', '3');
INSERT INTO `tv_global_region` VALUES ('1335', '157', '舞钢市', '3');
INSERT INTO `tv_global_region` VALUES ('1336', '157', '汝州市', '3');
INSERT INTO `tv_global_region` VALUES ('1337', '157', '宝丰县', '3');
INSERT INTO `tv_global_region` VALUES ('1338', '157', '叶县', '3');
INSERT INTO `tv_global_region` VALUES ('1339', '157', '鲁山县', '3');
INSERT INTO `tv_global_region` VALUES ('1340', '157', '郏县', '3');
INSERT INTO `tv_global_region` VALUES ('1341', '158', '湖滨区', '3');
INSERT INTO `tv_global_region` VALUES ('1342', '158', '义马市', '3');
INSERT INTO `tv_global_region` VALUES ('1343', '158', '灵宝市', '3');
INSERT INTO `tv_global_region` VALUES ('1344', '158', '渑池县', '3');
INSERT INTO `tv_global_region` VALUES ('1345', '158', '陕县', '3');
INSERT INTO `tv_global_region` VALUES ('1346', '158', '卢氏县', '3');
INSERT INTO `tv_global_region` VALUES ('1347', '159', '梁园区', '3');
INSERT INTO `tv_global_region` VALUES ('1348', '159', '睢阳区', '3');
INSERT INTO `tv_global_region` VALUES ('1349', '159', '永城市', '3');
INSERT INTO `tv_global_region` VALUES ('1350', '159', '民权县', '3');
INSERT INTO `tv_global_region` VALUES ('1351', '159', '睢县', '3');
INSERT INTO `tv_global_region` VALUES ('1352', '159', '宁陵县', '3');
INSERT INTO `tv_global_region` VALUES ('1353', '159', '虞城县', '3');
INSERT INTO `tv_global_region` VALUES ('1354', '159', '柘城县', '3');
INSERT INTO `tv_global_region` VALUES ('1355', '159', '夏邑县', '3');
INSERT INTO `tv_global_region` VALUES ('1356', '160', '卫滨区', '3');
INSERT INTO `tv_global_region` VALUES ('1357', '160', '红旗区', '3');
INSERT INTO `tv_global_region` VALUES ('1358', '160', '凤泉区', '3');
INSERT INTO `tv_global_region` VALUES ('1359', '160', '牧野区', '3');
INSERT INTO `tv_global_region` VALUES ('1360', '160', '卫辉市', '3');
INSERT INTO `tv_global_region` VALUES ('1361', '160', '辉县市', '3');
INSERT INTO `tv_global_region` VALUES ('1362', '160', '新乡县', '3');
INSERT INTO `tv_global_region` VALUES ('1363', '160', '获嘉县', '3');
INSERT INTO `tv_global_region` VALUES ('1364', '160', '原阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1365', '160', '延津县', '3');
INSERT INTO `tv_global_region` VALUES ('1366', '160', '封丘县', '3');
INSERT INTO `tv_global_region` VALUES ('1367', '160', '长垣县', '3');
INSERT INTO `tv_global_region` VALUES ('1368', '161', '浉河区', '3');
INSERT INTO `tv_global_region` VALUES ('1369', '161', '平桥区', '3');
INSERT INTO `tv_global_region` VALUES ('1370', '161', '罗山县', '3');
INSERT INTO `tv_global_region` VALUES ('1371', '161', '光山县', '3');
INSERT INTO `tv_global_region` VALUES ('1372', '161', '新县', '3');
INSERT INTO `tv_global_region` VALUES ('1373', '161', '商城县', '3');
INSERT INTO `tv_global_region` VALUES ('1374', '161', '固始县', '3');
INSERT INTO `tv_global_region` VALUES ('1375', '161', '潢川县', '3');
INSERT INTO `tv_global_region` VALUES ('1376', '161', '淮滨县', '3');
INSERT INTO `tv_global_region` VALUES ('1377', '161', '息县', '3');
INSERT INTO `tv_global_region` VALUES ('1378', '162', '魏都区', '3');
INSERT INTO `tv_global_region` VALUES ('1379', '162', '禹州市', '3');
INSERT INTO `tv_global_region` VALUES ('1380', '162', '长葛市', '3');
INSERT INTO `tv_global_region` VALUES ('1381', '162', '许昌县', '3');
INSERT INTO `tv_global_region` VALUES ('1382', '162', '鄢陵县', '3');
INSERT INTO `tv_global_region` VALUES ('1383', '162', '襄城县', '3');
INSERT INTO `tv_global_region` VALUES ('1384', '163', '川汇区', '3');
INSERT INTO `tv_global_region` VALUES ('1385', '163', '项城市', '3');
INSERT INTO `tv_global_region` VALUES ('1386', '163', '扶沟县', '3');
INSERT INTO `tv_global_region` VALUES ('1387', '163', '西华县', '3');
INSERT INTO `tv_global_region` VALUES ('1388', '163', '商水县', '3');
INSERT INTO `tv_global_region` VALUES ('1389', '163', '沈丘县', '3');
INSERT INTO `tv_global_region` VALUES ('1390', '163', '郸城县', '3');
INSERT INTO `tv_global_region` VALUES ('1391', '163', '淮阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1392', '163', '太康县', '3');
INSERT INTO `tv_global_region` VALUES ('1393', '163', '鹿邑县', '3');
INSERT INTO `tv_global_region` VALUES ('1394', '164', '驿城区', '3');
INSERT INTO `tv_global_region` VALUES ('1395', '164', '西平县', '3');
INSERT INTO `tv_global_region` VALUES ('1396', '164', '上蔡县', '3');
INSERT INTO `tv_global_region` VALUES ('1397', '164', '平舆县', '3');
INSERT INTO `tv_global_region` VALUES ('1398', '164', '正阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1399', '164', '确山县', '3');
INSERT INTO `tv_global_region` VALUES ('1400', '164', '泌阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1401', '164', '汝南县', '3');
INSERT INTO `tv_global_region` VALUES ('1402', '164', '遂平县', '3');
INSERT INTO `tv_global_region` VALUES ('1403', '164', '新蔡县', '3');
INSERT INTO `tv_global_region` VALUES ('1404', '165', '郾城区', '3');
INSERT INTO `tv_global_region` VALUES ('1405', '165', '源汇区', '3');
INSERT INTO `tv_global_region` VALUES ('1406', '165', '召陵区', '3');
INSERT INTO `tv_global_region` VALUES ('1407', '165', '舞阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1408', '165', '临颍县', '3');
INSERT INTO `tv_global_region` VALUES ('1409', '166', '华龙区', '3');
INSERT INTO `tv_global_region` VALUES ('1410', '166', '清丰县', '3');
INSERT INTO `tv_global_region` VALUES ('1411', '166', '南乐县', '3');
INSERT INTO `tv_global_region` VALUES ('1412', '166', '范县', '3');
INSERT INTO `tv_global_region` VALUES ('1413', '166', '台前县', '3');
INSERT INTO `tv_global_region` VALUES ('1414', '166', '濮阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1415', '167', '道里区', '3');
INSERT INTO `tv_global_region` VALUES ('1416', '167', '南岗区', '3');
INSERT INTO `tv_global_region` VALUES ('1417', '167', '动力区', '3');
INSERT INTO `tv_global_region` VALUES ('1418', '167', '平房区', '3');
INSERT INTO `tv_global_region` VALUES ('1419', '167', '香坊区', '3');
INSERT INTO `tv_global_region` VALUES ('1420', '167', '太平区', '3');
INSERT INTO `tv_global_region` VALUES ('1421', '167', '道外区', '3');
INSERT INTO `tv_global_region` VALUES ('1422', '167', '阿城区', '3');
INSERT INTO `tv_global_region` VALUES ('1423', '167', '呼兰区', '3');
INSERT INTO `tv_global_region` VALUES ('1424', '167', '松北区', '3');
INSERT INTO `tv_global_region` VALUES ('1425', '167', '尚志市', '3');
INSERT INTO `tv_global_region` VALUES ('1426', '167', '双城市', '3');
INSERT INTO `tv_global_region` VALUES ('1427', '167', '五常市', '3');
INSERT INTO `tv_global_region` VALUES ('1428', '167', '方正县', '3');
INSERT INTO `tv_global_region` VALUES ('1429', '167', '宾县', '3');
INSERT INTO `tv_global_region` VALUES ('1430', '167', '依兰县', '3');
INSERT INTO `tv_global_region` VALUES ('1431', '167', '巴彦县', '3');
INSERT INTO `tv_global_region` VALUES ('1432', '167', '通河县', '3');
INSERT INTO `tv_global_region` VALUES ('1433', '167', '木兰县', '3');
INSERT INTO `tv_global_region` VALUES ('1434', '167', '延寿县', '3');
INSERT INTO `tv_global_region` VALUES ('1435', '168', '萨尔图区', '3');
INSERT INTO `tv_global_region` VALUES ('1436', '168', '红岗区', '3');
INSERT INTO `tv_global_region` VALUES ('1437', '168', '龙凤区', '3');
INSERT INTO `tv_global_region` VALUES ('1438', '168', '让胡路区', '3');
INSERT INTO `tv_global_region` VALUES ('1439', '168', '大同区', '3');
INSERT INTO `tv_global_region` VALUES ('1440', '168', '肇州县', '3');
INSERT INTO `tv_global_region` VALUES ('1441', '168', '肇源县', '3');
INSERT INTO `tv_global_region` VALUES ('1442', '168', '林甸县', '3');
INSERT INTO `tv_global_region` VALUES ('1443', '168', '杜尔伯特', '3');
INSERT INTO `tv_global_region` VALUES ('1444', '169', '呼玛县', '3');
INSERT INTO `tv_global_region` VALUES ('1445', '169', '漠河县', '3');
INSERT INTO `tv_global_region` VALUES ('1446', '169', '塔河县', '3');
INSERT INTO `tv_global_region` VALUES ('1447', '170', '兴山区', '3');
INSERT INTO `tv_global_region` VALUES ('1448', '170', '工农区', '3');
INSERT INTO `tv_global_region` VALUES ('1449', '170', '南山区', '3');
INSERT INTO `tv_global_region` VALUES ('1450', '170', '兴安区', '3');
INSERT INTO `tv_global_region` VALUES ('1451', '170', '向阳区', '3');
INSERT INTO `tv_global_region` VALUES ('1452', '170', '东山区', '3');
INSERT INTO `tv_global_region` VALUES ('1453', '170', '萝北县', '3');
INSERT INTO `tv_global_region` VALUES ('1454', '170', '绥滨县', '3');
INSERT INTO `tv_global_region` VALUES ('1455', '171', '爱辉区', '3');
INSERT INTO `tv_global_region` VALUES ('1456', '171', '五大连池市', '3');
INSERT INTO `tv_global_region` VALUES ('1457', '171', '北安市', '3');
INSERT INTO `tv_global_region` VALUES ('1458', '171', '嫩江县', '3');
INSERT INTO `tv_global_region` VALUES ('1459', '171', '逊克县', '3');
INSERT INTO `tv_global_region` VALUES ('1460', '171', '孙吴县', '3');
INSERT INTO `tv_global_region` VALUES ('1461', '172', '鸡冠区', '3');
INSERT INTO `tv_global_region` VALUES ('1462', '172', '恒山区', '3');
INSERT INTO `tv_global_region` VALUES ('1463', '172', '城子河区', '3');
INSERT INTO `tv_global_region` VALUES ('1464', '172', '滴道区', '3');
INSERT INTO `tv_global_region` VALUES ('1465', '172', '梨树区', '3');
INSERT INTO `tv_global_region` VALUES ('1466', '172', '虎林市', '3');
INSERT INTO `tv_global_region` VALUES ('1467', '172', '密山市', '3');
INSERT INTO `tv_global_region` VALUES ('1468', '172', '鸡东县', '3');
INSERT INTO `tv_global_region` VALUES ('1469', '173', '前进区', '3');
INSERT INTO `tv_global_region` VALUES ('1470', '173', '郊区', '3');
INSERT INTO `tv_global_region` VALUES ('1471', '173', '向阳区', '3');
INSERT INTO `tv_global_region` VALUES ('1472', '173', '东风区', '3');
INSERT INTO `tv_global_region` VALUES ('1473', '173', '同江市', '3');
INSERT INTO `tv_global_region` VALUES ('1474', '173', '富锦市', '3');
INSERT INTO `tv_global_region` VALUES ('1475', '173', '桦南县', '3');
INSERT INTO `tv_global_region` VALUES ('1476', '173', '桦川县', '3');
INSERT INTO `tv_global_region` VALUES ('1477', '173', '汤原县', '3');
INSERT INTO `tv_global_region` VALUES ('1478', '173', '抚远县', '3');
INSERT INTO `tv_global_region` VALUES ('1479', '174', '爱民区', '3');
INSERT INTO `tv_global_region` VALUES ('1480', '174', '东安区', '3');
INSERT INTO `tv_global_region` VALUES ('1481', '174', '阳明区', '3');
INSERT INTO `tv_global_region` VALUES ('1482', '174', '西安区', '3');
INSERT INTO `tv_global_region` VALUES ('1483', '174', '绥芬河市', '3');
INSERT INTO `tv_global_region` VALUES ('1484', '174', '海林市', '3');
INSERT INTO `tv_global_region` VALUES ('1485', '174', '宁安市', '3');
INSERT INTO `tv_global_region` VALUES ('1486', '174', '穆棱市', '3');
INSERT INTO `tv_global_region` VALUES ('1487', '174', '东宁县', '3');
INSERT INTO `tv_global_region` VALUES ('1488', '174', '林口县', '3');
INSERT INTO `tv_global_region` VALUES ('1489', '175', '桃山区', '3');
INSERT INTO `tv_global_region` VALUES ('1490', '175', '新兴区', '3');
INSERT INTO `tv_global_region` VALUES ('1491', '175', '茄子河区', '3');
INSERT INTO `tv_global_region` VALUES ('1492', '175', '勃利县', '3');
INSERT INTO `tv_global_region` VALUES ('1493', '176', '龙沙区', '3');
INSERT INTO `tv_global_region` VALUES ('1494', '176', '昂昂溪区', '3');
INSERT INTO `tv_global_region` VALUES ('1495', '176', '铁峰区', '3');
INSERT INTO `tv_global_region` VALUES ('1496', '176', '建华区', '3');
INSERT INTO `tv_global_region` VALUES ('1497', '176', '富拉尔基区', '3');
INSERT INTO `tv_global_region` VALUES ('1498', '176', '碾子山区', '3');
INSERT INTO `tv_global_region` VALUES ('1499', '176', '梅里斯达斡尔区', '3');
INSERT INTO `tv_global_region` VALUES ('1500', '176', '讷河市', '3');
INSERT INTO `tv_global_region` VALUES ('1501', '176', '龙江县', '3');
INSERT INTO `tv_global_region` VALUES ('1502', '176', '依安县', '3');
INSERT INTO `tv_global_region` VALUES ('1503', '176', '泰来县', '3');
INSERT INTO `tv_global_region` VALUES ('1504', '176', '甘南县', '3');
INSERT INTO `tv_global_region` VALUES ('1505', '176', '富裕县', '3');
INSERT INTO `tv_global_region` VALUES ('1506', '176', '克山县', '3');
INSERT INTO `tv_global_region` VALUES ('1507', '176', '克东县', '3');
INSERT INTO `tv_global_region` VALUES ('1508', '176', '拜泉县', '3');
INSERT INTO `tv_global_region` VALUES ('1509', '177', '尖山区', '3');
INSERT INTO `tv_global_region` VALUES ('1510', '177', '岭东区', '3');
INSERT INTO `tv_global_region` VALUES ('1511', '177', '四方台区', '3');
INSERT INTO `tv_global_region` VALUES ('1512', '177', '宝山区', '3');
INSERT INTO `tv_global_region` VALUES ('1513', '177', '集贤县', '3');
INSERT INTO `tv_global_region` VALUES ('1514', '177', '友谊县', '3');
INSERT INTO `tv_global_region` VALUES ('1515', '177', '宝清县', '3');
INSERT INTO `tv_global_region` VALUES ('1516', '177', '饶河县', '3');
INSERT INTO `tv_global_region` VALUES ('1517', '178', '北林区', '3');
INSERT INTO `tv_global_region` VALUES ('1518', '178', '安达市', '3');
INSERT INTO `tv_global_region` VALUES ('1519', '178', '肇东市', '3');
INSERT INTO `tv_global_region` VALUES ('1520', '178', '海伦市', '3');
INSERT INTO `tv_global_region` VALUES ('1521', '178', '望奎县', '3');
INSERT INTO `tv_global_region` VALUES ('1522', '178', '兰西县', '3');
INSERT INTO `tv_global_region` VALUES ('1523', '178', '青冈县', '3');
INSERT INTO `tv_global_region` VALUES ('1524', '178', '庆安县', '3');
INSERT INTO `tv_global_region` VALUES ('1525', '178', '明水县', '3');
INSERT INTO `tv_global_region` VALUES ('1526', '178', '绥棱县', '3');
INSERT INTO `tv_global_region` VALUES ('1527', '179', '伊春区', '3');
INSERT INTO `tv_global_region` VALUES ('1528', '179', '带岭区', '3');
INSERT INTO `tv_global_region` VALUES ('1529', '179', '南岔区', '3');
INSERT INTO `tv_global_region` VALUES ('1530', '179', '金山屯区', '3');
INSERT INTO `tv_global_region` VALUES ('1531', '179', '西林区', '3');
INSERT INTO `tv_global_region` VALUES ('1532', '179', '美溪区', '3');
INSERT INTO `tv_global_region` VALUES ('1533', '179', '乌马河区', '3');
INSERT INTO `tv_global_region` VALUES ('1534', '179', '翠峦区', '3');
INSERT INTO `tv_global_region` VALUES ('1535', '179', '友好区', '3');
INSERT INTO `tv_global_region` VALUES ('1536', '179', '上甘岭区', '3');
INSERT INTO `tv_global_region` VALUES ('1537', '179', '五营区', '3');
INSERT INTO `tv_global_region` VALUES ('1538', '179', '红星区', '3');
INSERT INTO `tv_global_region` VALUES ('1539', '179', '新青区', '3');
INSERT INTO `tv_global_region` VALUES ('1540', '179', '汤旺河区', '3');
INSERT INTO `tv_global_region` VALUES ('1541', '179', '乌伊岭区', '3');
INSERT INTO `tv_global_region` VALUES ('1542', '179', '铁力市', '3');
INSERT INTO `tv_global_region` VALUES ('1543', '179', '嘉荫县', '3');
INSERT INTO `tv_global_region` VALUES ('1544', '180', '江岸区', '3');
INSERT INTO `tv_global_region` VALUES ('1545', '180', '武昌区', '3');
INSERT INTO `tv_global_region` VALUES ('1546', '180', '江汉区', '3');
INSERT INTO `tv_global_region` VALUES ('1547', '180', '硚口区', '3');
INSERT INTO `tv_global_region` VALUES ('1548', '180', '汉阳区', '3');
INSERT INTO `tv_global_region` VALUES ('1549', '180', '青山区', '3');
INSERT INTO `tv_global_region` VALUES ('1550', '180', '洪山区', '3');
INSERT INTO `tv_global_region` VALUES ('1551', '180', '东西湖区', '3');
INSERT INTO `tv_global_region` VALUES ('1552', '180', '汉南区', '3');
INSERT INTO `tv_global_region` VALUES ('1553', '180', '蔡甸区', '3');
INSERT INTO `tv_global_region` VALUES ('1554', '180', '江夏区', '3');
INSERT INTO `tv_global_region` VALUES ('1555', '180', '黄陂区', '3');
INSERT INTO `tv_global_region` VALUES ('1556', '180', '新洲区', '3');
INSERT INTO `tv_global_region` VALUES ('1557', '180', '经济开发区', '3');
INSERT INTO `tv_global_region` VALUES ('1558', '181', '仙桃市', '3');
INSERT INTO `tv_global_region` VALUES ('1559', '182', '鄂城区', '3');
INSERT INTO `tv_global_region` VALUES ('1560', '182', '华容区', '3');
INSERT INTO `tv_global_region` VALUES ('1561', '182', '梁子湖区', '3');
INSERT INTO `tv_global_region` VALUES ('1562', '183', '黄州区', '3');
INSERT INTO `tv_global_region` VALUES ('1563', '183', '麻城市', '3');
INSERT INTO `tv_global_region` VALUES ('1564', '183', '武穴市', '3');
INSERT INTO `tv_global_region` VALUES ('1565', '183', '团风县', '3');
INSERT INTO `tv_global_region` VALUES ('1566', '183', '红安县', '3');
INSERT INTO `tv_global_region` VALUES ('1567', '183', '罗田县', '3');
INSERT INTO `tv_global_region` VALUES ('1568', '183', '英山县', '3');
INSERT INTO `tv_global_region` VALUES ('1569', '183', '浠水县', '3');
INSERT INTO `tv_global_region` VALUES ('1570', '183', '蕲春县', '3');
INSERT INTO `tv_global_region` VALUES ('1571', '183', '黄梅县', '3');
INSERT INTO `tv_global_region` VALUES ('1572', '184', '黄石港区', '3');
INSERT INTO `tv_global_region` VALUES ('1573', '184', '西塞山区', '3');
INSERT INTO `tv_global_region` VALUES ('1574', '184', '下陆区', '3');
INSERT INTO `tv_global_region` VALUES ('1575', '184', '铁山区', '3');
INSERT INTO `tv_global_region` VALUES ('1576', '184', '大冶市', '3');
INSERT INTO `tv_global_region` VALUES ('1577', '184', '阳新县', '3');
INSERT INTO `tv_global_region` VALUES ('1578', '185', '东宝区', '3');
INSERT INTO `tv_global_region` VALUES ('1579', '185', '掇刀区', '3');
INSERT INTO `tv_global_region` VALUES ('1580', '185', '钟祥市', '3');
INSERT INTO `tv_global_region` VALUES ('1581', '185', '京山县', '3');
INSERT INTO `tv_global_region` VALUES ('1582', '185', '沙洋县', '3');
INSERT INTO `tv_global_region` VALUES ('1583', '186', '沙市区', '3');
INSERT INTO `tv_global_region` VALUES ('1584', '186', '荆州区', '3');
INSERT INTO `tv_global_region` VALUES ('1585', '186', '石首市', '3');
INSERT INTO `tv_global_region` VALUES ('1586', '186', '洪湖市', '3');
INSERT INTO `tv_global_region` VALUES ('1587', '186', '松滋市', '3');
INSERT INTO `tv_global_region` VALUES ('1588', '186', '公安县', '3');
INSERT INTO `tv_global_region` VALUES ('1589', '186', '监利县', '3');
INSERT INTO `tv_global_region` VALUES ('1590', '186', '江陵县', '3');
INSERT INTO `tv_global_region` VALUES ('1591', '187', '潜江市', '3');
INSERT INTO `tv_global_region` VALUES ('1592', '188', '神农架林区', '3');
INSERT INTO `tv_global_region` VALUES ('1593', '189', '张湾区', '3');
INSERT INTO `tv_global_region` VALUES ('1594', '189', '茅箭区', '3');
INSERT INTO `tv_global_region` VALUES ('1595', '189', '丹江口市', '3');
INSERT INTO `tv_global_region` VALUES ('1596', '189', '郧县', '3');
INSERT INTO `tv_global_region` VALUES ('1597', '189', '郧西县', '3');
INSERT INTO `tv_global_region` VALUES ('1598', '189', '竹山县', '3');
INSERT INTO `tv_global_region` VALUES ('1599', '189', '竹溪县', '3');
INSERT INTO `tv_global_region` VALUES ('1600', '189', '房县', '3');
INSERT INTO `tv_global_region` VALUES ('1601', '190', '曾都区', '3');
INSERT INTO `tv_global_region` VALUES ('1602', '190', '广水市', '3');
INSERT INTO `tv_global_region` VALUES ('1603', '191', '天门市', '3');
INSERT INTO `tv_global_region` VALUES ('1604', '192', '咸安区', '3');
INSERT INTO `tv_global_region` VALUES ('1605', '192', '赤壁市', '3');
INSERT INTO `tv_global_region` VALUES ('1606', '192', '嘉鱼县', '3');
INSERT INTO `tv_global_region` VALUES ('1607', '192', '通城县', '3');
INSERT INTO `tv_global_region` VALUES ('1608', '192', '崇阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1609', '192', '通山县', '3');
INSERT INTO `tv_global_region` VALUES ('1610', '193', '襄城区', '3');
INSERT INTO `tv_global_region` VALUES ('1611', '193', '樊城区', '3');
INSERT INTO `tv_global_region` VALUES ('1612', '193', '襄阳区', '3');
INSERT INTO `tv_global_region` VALUES ('1613', '193', '老河口市', '3');
INSERT INTO `tv_global_region` VALUES ('1614', '193', '枣阳市', '3');
INSERT INTO `tv_global_region` VALUES ('1615', '193', '宜城市', '3');
INSERT INTO `tv_global_region` VALUES ('1616', '193', '南漳县', '3');
INSERT INTO `tv_global_region` VALUES ('1617', '193', '谷城县', '3');
INSERT INTO `tv_global_region` VALUES ('1618', '193', '保康县', '3');
INSERT INTO `tv_global_region` VALUES ('1619', '194', '孝南区', '3');
INSERT INTO `tv_global_region` VALUES ('1620', '194', '应城市', '3');
INSERT INTO `tv_global_region` VALUES ('1621', '194', '安陆市', '3');
INSERT INTO `tv_global_region` VALUES ('1622', '194', '汉川市', '3');
INSERT INTO `tv_global_region` VALUES ('1623', '194', '孝昌县', '3');
INSERT INTO `tv_global_region` VALUES ('1624', '194', '大悟县', '3');
INSERT INTO `tv_global_region` VALUES ('1625', '194', '云梦县', '3');
INSERT INTO `tv_global_region` VALUES ('1626', '195', '长阳', '3');
INSERT INTO `tv_global_region` VALUES ('1627', '195', '五峰', '3');
INSERT INTO `tv_global_region` VALUES ('1628', '195', '西陵区', '3');
INSERT INTO `tv_global_region` VALUES ('1629', '195', '伍家岗区', '3');
INSERT INTO `tv_global_region` VALUES ('1630', '195', '点军区', '3');
INSERT INTO `tv_global_region` VALUES ('1631', '195', '猇亭区', '3');
INSERT INTO `tv_global_region` VALUES ('1632', '195', '夷陵区', '3');
INSERT INTO `tv_global_region` VALUES ('1633', '195', '宜都市', '3');
INSERT INTO `tv_global_region` VALUES ('1634', '195', '当阳市', '3');
INSERT INTO `tv_global_region` VALUES ('1635', '195', '枝江市', '3');
INSERT INTO `tv_global_region` VALUES ('1636', '195', '远安县', '3');
INSERT INTO `tv_global_region` VALUES ('1637', '195', '兴山县', '3');
INSERT INTO `tv_global_region` VALUES ('1638', '195', '秭归县', '3');
INSERT INTO `tv_global_region` VALUES ('1639', '196', '恩施市', '3');
INSERT INTO `tv_global_region` VALUES ('1640', '196', '利川市', '3');
INSERT INTO `tv_global_region` VALUES ('1641', '196', '建始县', '3');
INSERT INTO `tv_global_region` VALUES ('1642', '196', '巴东县', '3');
INSERT INTO `tv_global_region` VALUES ('1643', '196', '宣恩县', '3');
INSERT INTO `tv_global_region` VALUES ('1644', '196', '咸丰县', '3');
INSERT INTO `tv_global_region` VALUES ('1645', '196', '来凤县', '3');
INSERT INTO `tv_global_region` VALUES ('1646', '196', '鹤峰县', '3');
INSERT INTO `tv_global_region` VALUES ('1647', '197', '岳麓区', '3');
INSERT INTO `tv_global_region` VALUES ('1648', '197', '芙蓉区', '3');
INSERT INTO `tv_global_region` VALUES ('1649', '197', '天心区', '3');
INSERT INTO `tv_global_region` VALUES ('1650', '197', '开福区', '3');
INSERT INTO `tv_global_region` VALUES ('1651', '197', '雨花区', '3');
INSERT INTO `tv_global_region` VALUES ('1652', '197', '开发区', '3');
INSERT INTO `tv_global_region` VALUES ('1653', '197', '浏阳市', '3');
INSERT INTO `tv_global_region` VALUES ('1654', '197', '长沙县', '3');
INSERT INTO `tv_global_region` VALUES ('1655', '197', '望城县', '3');
INSERT INTO `tv_global_region` VALUES ('1656', '197', '宁乡县', '3');
INSERT INTO `tv_global_region` VALUES ('1657', '198', '永定区', '3');
INSERT INTO `tv_global_region` VALUES ('1658', '198', '武陵源区', '3');
INSERT INTO `tv_global_region` VALUES ('1659', '198', '慈利县', '3');
INSERT INTO `tv_global_region` VALUES ('1660', '198', '桑植县', '3');
INSERT INTO `tv_global_region` VALUES ('1661', '199', '武陵区', '3');
INSERT INTO `tv_global_region` VALUES ('1662', '199', '鼎城区', '3');
INSERT INTO `tv_global_region` VALUES ('1663', '199', '津市市', '3');
INSERT INTO `tv_global_region` VALUES ('1664', '199', '安乡县', '3');
INSERT INTO `tv_global_region` VALUES ('1665', '199', '汉寿县', '3');
INSERT INTO `tv_global_region` VALUES ('1666', '199', '澧县', '3');
INSERT INTO `tv_global_region` VALUES ('1667', '199', '临澧县', '3');
INSERT INTO `tv_global_region` VALUES ('1668', '199', '桃源县', '3');
INSERT INTO `tv_global_region` VALUES ('1669', '199', '石门县', '3');
INSERT INTO `tv_global_region` VALUES ('1670', '200', '北湖区', '3');
INSERT INTO `tv_global_region` VALUES ('1671', '200', '苏仙区', '3');
INSERT INTO `tv_global_region` VALUES ('1672', '200', '资兴市', '3');
INSERT INTO `tv_global_region` VALUES ('1673', '200', '桂阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1674', '200', '宜章县', '3');
INSERT INTO `tv_global_region` VALUES ('1675', '200', '永兴县', '3');
INSERT INTO `tv_global_region` VALUES ('1676', '200', '嘉禾县', '3');
INSERT INTO `tv_global_region` VALUES ('1677', '200', '临武县', '3');
INSERT INTO `tv_global_region` VALUES ('1678', '200', '汝城县', '3');
INSERT INTO `tv_global_region` VALUES ('1679', '200', '桂东县', '3');
INSERT INTO `tv_global_region` VALUES ('1680', '200', '安仁县', '3');
INSERT INTO `tv_global_region` VALUES ('1681', '201', '雁峰区', '3');
INSERT INTO `tv_global_region` VALUES ('1682', '201', '珠晖区', '3');
INSERT INTO `tv_global_region` VALUES ('1683', '201', '石鼓区', '3');
INSERT INTO `tv_global_region` VALUES ('1684', '201', '蒸湘区', '3');
INSERT INTO `tv_global_region` VALUES ('1685', '201', '南岳区', '3');
INSERT INTO `tv_global_region` VALUES ('1686', '201', '耒阳市', '3');
INSERT INTO `tv_global_region` VALUES ('1687', '201', '常宁市', '3');
INSERT INTO `tv_global_region` VALUES ('1688', '201', '衡阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1689', '201', '衡南县', '3');
INSERT INTO `tv_global_region` VALUES ('1690', '201', '衡山县', '3');
INSERT INTO `tv_global_region` VALUES ('1691', '201', '衡东县', '3');
INSERT INTO `tv_global_region` VALUES ('1692', '201', '祁东县', '3');
INSERT INTO `tv_global_region` VALUES ('1693', '202', '鹤城区', '3');
INSERT INTO `tv_global_region` VALUES ('1694', '202', '靖州', '3');
INSERT INTO `tv_global_region` VALUES ('1695', '202', '麻阳', '3');
INSERT INTO `tv_global_region` VALUES ('1696', '202', '通道', '3');
INSERT INTO `tv_global_region` VALUES ('1697', '202', '新晃', '3');
INSERT INTO `tv_global_region` VALUES ('1698', '202', '芷江', '3');
INSERT INTO `tv_global_region` VALUES ('1699', '202', '沅陵县', '3');
INSERT INTO `tv_global_region` VALUES ('1700', '202', '辰溪县', '3');
INSERT INTO `tv_global_region` VALUES ('1701', '202', '溆浦县', '3');
INSERT INTO `tv_global_region` VALUES ('1702', '202', '中方县', '3');
INSERT INTO `tv_global_region` VALUES ('1703', '202', '会同县', '3');
INSERT INTO `tv_global_region` VALUES ('1704', '202', '洪江市', '3');
INSERT INTO `tv_global_region` VALUES ('1705', '203', '娄星区', '3');
INSERT INTO `tv_global_region` VALUES ('1706', '203', '冷水江市', '3');
INSERT INTO `tv_global_region` VALUES ('1707', '203', '涟源市', '3');
INSERT INTO `tv_global_region` VALUES ('1708', '203', '双峰县', '3');
INSERT INTO `tv_global_region` VALUES ('1709', '203', '新化县', '3');
INSERT INTO `tv_global_region` VALUES ('1710', '204', '城步', '3');
INSERT INTO `tv_global_region` VALUES ('1711', '204', '双清区', '3');
INSERT INTO `tv_global_region` VALUES ('1712', '204', '大祥区', '3');
INSERT INTO `tv_global_region` VALUES ('1713', '204', '北塔区', '3');
INSERT INTO `tv_global_region` VALUES ('1714', '204', '武冈市', '3');
INSERT INTO `tv_global_region` VALUES ('1715', '204', '邵东县', '3');
INSERT INTO `tv_global_region` VALUES ('1716', '204', '新邵县', '3');
INSERT INTO `tv_global_region` VALUES ('1717', '204', '邵阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1718', '204', '隆回县', '3');
INSERT INTO `tv_global_region` VALUES ('1719', '204', '洞口县', '3');
INSERT INTO `tv_global_region` VALUES ('1720', '204', '绥宁县', '3');
INSERT INTO `tv_global_region` VALUES ('1721', '204', '新宁县', '3');
INSERT INTO `tv_global_region` VALUES ('1722', '205', '岳塘区', '3');
INSERT INTO `tv_global_region` VALUES ('1723', '205', '雨湖区', '3');
INSERT INTO `tv_global_region` VALUES ('1724', '205', '湘乡市', '3');
INSERT INTO `tv_global_region` VALUES ('1725', '205', '韶山市', '3');
INSERT INTO `tv_global_region` VALUES ('1726', '205', '湘潭县', '3');
INSERT INTO `tv_global_region` VALUES ('1727', '206', '吉首市', '3');
INSERT INTO `tv_global_region` VALUES ('1728', '206', '泸溪县', '3');
INSERT INTO `tv_global_region` VALUES ('1729', '206', '凤凰县', '3');
INSERT INTO `tv_global_region` VALUES ('1730', '206', '花垣县', '3');
INSERT INTO `tv_global_region` VALUES ('1731', '206', '保靖县', '3');
INSERT INTO `tv_global_region` VALUES ('1732', '206', '古丈县', '3');
INSERT INTO `tv_global_region` VALUES ('1733', '206', '永顺县', '3');
INSERT INTO `tv_global_region` VALUES ('1734', '206', '龙山县', '3');
INSERT INTO `tv_global_region` VALUES ('1735', '207', '赫山区', '3');
INSERT INTO `tv_global_region` VALUES ('1736', '207', '资阳区', '3');
INSERT INTO `tv_global_region` VALUES ('1737', '207', '沅江市', '3');
INSERT INTO `tv_global_region` VALUES ('1738', '207', '南县', '3');
INSERT INTO `tv_global_region` VALUES ('1739', '207', '桃江县', '3');
INSERT INTO `tv_global_region` VALUES ('1740', '207', '安化县', '3');
INSERT INTO `tv_global_region` VALUES ('1741', '208', '江华', '3');
INSERT INTO `tv_global_region` VALUES ('1742', '208', '冷水滩区', '3');
INSERT INTO `tv_global_region` VALUES ('1743', '208', '零陵区', '3');
INSERT INTO `tv_global_region` VALUES ('1744', '208', '祁阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1745', '208', '东安县', '3');
INSERT INTO `tv_global_region` VALUES ('1746', '208', '双牌县', '3');
INSERT INTO `tv_global_region` VALUES ('1747', '208', '道县', '3');
INSERT INTO `tv_global_region` VALUES ('1748', '208', '江永县', '3');
INSERT INTO `tv_global_region` VALUES ('1749', '208', '宁远县', '3');
INSERT INTO `tv_global_region` VALUES ('1750', '208', '蓝山县', '3');
INSERT INTO `tv_global_region` VALUES ('1751', '208', '新田县', '3');
INSERT INTO `tv_global_region` VALUES ('1752', '209', '岳阳楼区', '3');
INSERT INTO `tv_global_region` VALUES ('1753', '209', '君山区', '3');
INSERT INTO `tv_global_region` VALUES ('1754', '209', '云溪区', '3');
INSERT INTO `tv_global_region` VALUES ('1755', '209', '汨罗市', '3');
INSERT INTO `tv_global_region` VALUES ('1756', '209', '临湘市', '3');
INSERT INTO `tv_global_region` VALUES ('1757', '209', '岳阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1758', '209', '华容县', '3');
INSERT INTO `tv_global_region` VALUES ('1759', '209', '湘阴县', '3');
INSERT INTO `tv_global_region` VALUES ('1760', '209', '平江县', '3');
INSERT INTO `tv_global_region` VALUES ('1761', '210', '天元区', '3');
INSERT INTO `tv_global_region` VALUES ('1762', '210', '荷塘区', '3');
INSERT INTO `tv_global_region` VALUES ('1763', '210', '芦淞区', '3');
INSERT INTO `tv_global_region` VALUES ('1764', '210', '石峰区', '3');
INSERT INTO `tv_global_region` VALUES ('1765', '210', '醴陵市', '3');
INSERT INTO `tv_global_region` VALUES ('1766', '210', '株洲县', '3');
INSERT INTO `tv_global_region` VALUES ('1767', '210', '攸县', '3');
INSERT INTO `tv_global_region` VALUES ('1768', '210', '茶陵县', '3');
INSERT INTO `tv_global_region` VALUES ('1769', '210', '炎陵县', '3');
INSERT INTO `tv_global_region` VALUES ('1770', '211', '朝阳区', '3');
INSERT INTO `tv_global_region` VALUES ('1771', '211', '宽城区', '3');
INSERT INTO `tv_global_region` VALUES ('1772', '211', '二道区', '3');
INSERT INTO `tv_global_region` VALUES ('1773', '211', '南关区', '3');
INSERT INTO `tv_global_region` VALUES ('1774', '211', '绿园区', '3');
INSERT INTO `tv_global_region` VALUES ('1775', '211', '双阳区', '3');
INSERT INTO `tv_global_region` VALUES ('1776', '211', '净月潭开发区', '3');
INSERT INTO `tv_global_region` VALUES ('1777', '211', '高新技术开发区', '3');
INSERT INTO `tv_global_region` VALUES ('1778', '211', '经济技术开发区', '3');
INSERT INTO `tv_global_region` VALUES ('1779', '211', '汽车产业开发区', '3');
INSERT INTO `tv_global_region` VALUES ('1780', '211', '德惠市', '3');
INSERT INTO `tv_global_region` VALUES ('1781', '211', '九台市', '3');
INSERT INTO `tv_global_region` VALUES ('1782', '211', '榆树市', '3');
INSERT INTO `tv_global_region` VALUES ('1783', '211', '农安县', '3');
INSERT INTO `tv_global_region` VALUES ('1784', '212', '船营区', '3');
INSERT INTO `tv_global_region` VALUES ('1785', '212', '昌邑区', '3');
INSERT INTO `tv_global_region` VALUES ('1786', '212', '龙潭区', '3');
INSERT INTO `tv_global_region` VALUES ('1787', '212', '丰满区', '3');
INSERT INTO `tv_global_region` VALUES ('1788', '212', '蛟河市', '3');
INSERT INTO `tv_global_region` VALUES ('1789', '212', '桦甸市', '3');
INSERT INTO `tv_global_region` VALUES ('1790', '212', '舒兰市', '3');
INSERT INTO `tv_global_region` VALUES ('1791', '212', '磐石市', '3');
INSERT INTO `tv_global_region` VALUES ('1792', '212', '永吉县', '3');
INSERT INTO `tv_global_region` VALUES ('1793', '213', '洮北区', '3');
INSERT INTO `tv_global_region` VALUES ('1794', '213', '洮南市', '3');
INSERT INTO `tv_global_region` VALUES ('1795', '213', '大安市', '3');
INSERT INTO `tv_global_region` VALUES ('1796', '213', '镇赉县', '3');
INSERT INTO `tv_global_region` VALUES ('1797', '213', '通榆县', '3');
INSERT INTO `tv_global_region` VALUES ('1798', '214', '江源区', '3');
INSERT INTO `tv_global_region` VALUES ('1799', '214', '八道江区', '3');
INSERT INTO `tv_global_region` VALUES ('1800', '214', '长白', '3');
INSERT INTO `tv_global_region` VALUES ('1801', '214', '临江市', '3');
INSERT INTO `tv_global_region` VALUES ('1802', '214', '抚松县', '3');
INSERT INTO `tv_global_region` VALUES ('1803', '214', '靖宇县', '3');
INSERT INTO `tv_global_region` VALUES ('1804', '215', '龙山区', '3');
INSERT INTO `tv_global_region` VALUES ('1805', '215', '西安区', '3');
INSERT INTO `tv_global_region` VALUES ('1806', '215', '东丰县', '3');
INSERT INTO `tv_global_region` VALUES ('1807', '215', '东辽县', '3');
INSERT INTO `tv_global_region` VALUES ('1808', '216', '铁西区', '3');
INSERT INTO `tv_global_region` VALUES ('1809', '216', '铁东区', '3');
INSERT INTO `tv_global_region` VALUES ('1810', '216', '伊通', '3');
INSERT INTO `tv_global_region` VALUES ('1811', '216', '公主岭市', '3');
INSERT INTO `tv_global_region` VALUES ('1812', '216', '双辽市', '3');
INSERT INTO `tv_global_region` VALUES ('1813', '216', '梨树县', '3');
INSERT INTO `tv_global_region` VALUES ('1814', '217', '前郭尔罗斯', '3');
INSERT INTO `tv_global_region` VALUES ('1815', '217', '宁江区', '3');
INSERT INTO `tv_global_region` VALUES ('1816', '217', '长岭县', '3');
INSERT INTO `tv_global_region` VALUES ('1817', '217', '乾安县', '3');
INSERT INTO `tv_global_region` VALUES ('1818', '217', '扶余县', '3');
INSERT INTO `tv_global_region` VALUES ('1819', '218', '东昌区', '3');
INSERT INTO `tv_global_region` VALUES ('1820', '218', '二道江区', '3');
INSERT INTO `tv_global_region` VALUES ('1821', '218', '梅河口市', '3');
INSERT INTO `tv_global_region` VALUES ('1822', '218', '集安市', '3');
INSERT INTO `tv_global_region` VALUES ('1823', '218', '通化县', '3');
INSERT INTO `tv_global_region` VALUES ('1824', '218', '辉南县', '3');
INSERT INTO `tv_global_region` VALUES ('1825', '218', '柳河县', '3');
INSERT INTO `tv_global_region` VALUES ('1826', '219', '延吉市', '3');
INSERT INTO `tv_global_region` VALUES ('1827', '219', '图们市', '3');
INSERT INTO `tv_global_region` VALUES ('1828', '219', '敦化市', '3');
INSERT INTO `tv_global_region` VALUES ('1829', '219', '珲春市', '3');
INSERT INTO `tv_global_region` VALUES ('1830', '219', '龙井市', '3');
INSERT INTO `tv_global_region` VALUES ('1831', '219', '和龙市', '3');
INSERT INTO `tv_global_region` VALUES ('1832', '219', '安图县', '3');
INSERT INTO `tv_global_region` VALUES ('1833', '219', '汪清县', '3');
INSERT INTO `tv_global_region` VALUES ('1834', '220', '玄武区', '3');
INSERT INTO `tv_global_region` VALUES ('1835', '220', '鼓楼区', '3');
INSERT INTO `tv_global_region` VALUES ('1836', '220', '白下区', '3');
INSERT INTO `tv_global_region` VALUES ('1837', '220', '建邺区', '3');
INSERT INTO `tv_global_region` VALUES ('1838', '220', '秦淮区', '3');
INSERT INTO `tv_global_region` VALUES ('1839', '220', '雨花台区', '3');
INSERT INTO `tv_global_region` VALUES ('1840', '220', '下关区', '3');
INSERT INTO `tv_global_region` VALUES ('1841', '220', '栖霞区', '3');
INSERT INTO `tv_global_region` VALUES ('1842', '220', '浦口区', '3');
INSERT INTO `tv_global_region` VALUES ('1843', '220', '江宁区', '3');
INSERT INTO `tv_global_region` VALUES ('1844', '220', '六合区', '3');
INSERT INTO `tv_global_region` VALUES ('1845', '220', '溧水县', '3');
INSERT INTO `tv_global_region` VALUES ('1846', '220', '高淳县', '3');
INSERT INTO `tv_global_region` VALUES ('1847', '221', '沧浪区', '3');
INSERT INTO `tv_global_region` VALUES ('1848', '221', '金阊区', '3');
INSERT INTO `tv_global_region` VALUES ('1849', '221', '平江区', '3');
INSERT INTO `tv_global_region` VALUES ('1850', '221', '虎丘区', '3');
INSERT INTO `tv_global_region` VALUES ('1851', '221', '吴中区', '3');
INSERT INTO `tv_global_region` VALUES ('1852', '221', '相城区', '3');
INSERT INTO `tv_global_region` VALUES ('1853', '221', '园区', '3');
INSERT INTO `tv_global_region` VALUES ('1854', '221', '新区', '3');
INSERT INTO `tv_global_region` VALUES ('1855', '221', '常熟市', '3');
INSERT INTO `tv_global_region` VALUES ('1856', '221', '张家港市', '3');
INSERT INTO `tv_global_region` VALUES ('1857', '221', '玉山镇', '3');
INSERT INTO `tv_global_region` VALUES ('1858', '221', '巴城镇', '3');
INSERT INTO `tv_global_region` VALUES ('1859', '221', '周市镇', '3');
INSERT INTO `tv_global_region` VALUES ('1860', '221', '陆家镇', '3');
INSERT INTO `tv_global_region` VALUES ('1861', '221', '花桥镇', '3');
INSERT INTO `tv_global_region` VALUES ('1862', '221', '淀山湖镇', '3');
INSERT INTO `tv_global_region` VALUES ('1863', '221', '张浦镇', '3');
INSERT INTO `tv_global_region` VALUES ('1864', '221', '周庄镇', '3');
INSERT INTO `tv_global_region` VALUES ('1865', '221', '千灯镇', '3');
INSERT INTO `tv_global_region` VALUES ('1866', '221', '锦溪镇', '3');
INSERT INTO `tv_global_region` VALUES ('1867', '221', '开发区', '3');
INSERT INTO `tv_global_region` VALUES ('1868', '221', '吴江市', '3');
INSERT INTO `tv_global_region` VALUES ('1869', '221', '太仓市', '3');
INSERT INTO `tv_global_region` VALUES ('1870', '222', '崇安区', '3');
INSERT INTO `tv_global_region` VALUES ('1871', '222', '北塘区', '3');
INSERT INTO `tv_global_region` VALUES ('1872', '222', '南长区', '3');
INSERT INTO `tv_global_region` VALUES ('1873', '222', '锡山区', '3');
INSERT INTO `tv_global_region` VALUES ('1874', '222', '惠山区', '3');
INSERT INTO `tv_global_region` VALUES ('1875', '222', '滨湖区', '3');
INSERT INTO `tv_global_region` VALUES ('1876', '222', '新区', '3');
INSERT INTO `tv_global_region` VALUES ('1877', '222', '江阴市', '3');
INSERT INTO `tv_global_region` VALUES ('1878', '222', '宜兴市', '3');
INSERT INTO `tv_global_region` VALUES ('1879', '223', '天宁区', '3');
INSERT INTO `tv_global_region` VALUES ('1880', '223', '钟楼区', '3');
INSERT INTO `tv_global_region` VALUES ('1881', '223', '戚墅堰区', '3');
INSERT INTO `tv_global_region` VALUES ('1882', '223', '郊区', '3');
INSERT INTO `tv_global_region` VALUES ('1883', '223', '新北区', '3');
INSERT INTO `tv_global_region` VALUES ('1884', '223', '武进区', '3');
INSERT INTO `tv_global_region` VALUES ('1885', '223', '溧阳市', '3');
INSERT INTO `tv_global_region` VALUES ('1886', '223', '金坛市', '3');
INSERT INTO `tv_global_region` VALUES ('1887', '224', '清河区', '3');
INSERT INTO `tv_global_region` VALUES ('1888', '224', '清浦区', '3');
INSERT INTO `tv_global_region` VALUES ('1889', '224', '楚州区', '3');
INSERT INTO `tv_global_region` VALUES ('1890', '224', '淮阴区', '3');
INSERT INTO `tv_global_region` VALUES ('1891', '224', '涟水县', '3');
INSERT INTO `tv_global_region` VALUES ('1892', '224', '洪泽县', '3');
INSERT INTO `tv_global_region` VALUES ('1893', '224', '盱眙县', '3');
INSERT INTO `tv_global_region` VALUES ('1894', '224', '金湖县', '3');
INSERT INTO `tv_global_region` VALUES ('1895', '225', '新浦区', '3');
INSERT INTO `tv_global_region` VALUES ('1896', '225', '连云区', '3');
INSERT INTO `tv_global_region` VALUES ('1897', '225', '海州区', '3');
INSERT INTO `tv_global_region` VALUES ('1898', '225', '赣榆县', '3');
INSERT INTO `tv_global_region` VALUES ('1899', '225', '东海县', '3');
INSERT INTO `tv_global_region` VALUES ('1900', '225', '灌云县', '3');
INSERT INTO `tv_global_region` VALUES ('1901', '225', '灌南县', '3');
INSERT INTO `tv_global_region` VALUES ('1902', '226', '崇川区', '3');
INSERT INTO `tv_global_region` VALUES ('1903', '226', '港闸区', '3');
INSERT INTO `tv_global_region` VALUES ('1904', '226', '经济开发区', '3');
INSERT INTO `tv_global_region` VALUES ('1905', '226', '启东市', '3');
INSERT INTO `tv_global_region` VALUES ('1906', '226', '如皋市', '3');
INSERT INTO `tv_global_region` VALUES ('1907', '226', '通州市', '3');
INSERT INTO `tv_global_region` VALUES ('1908', '226', '海门市', '3');
INSERT INTO `tv_global_region` VALUES ('1909', '226', '海安县', '3');
INSERT INTO `tv_global_region` VALUES ('1910', '226', '如东县', '3');
INSERT INTO `tv_global_region` VALUES ('1911', '227', '宿城区', '3');
INSERT INTO `tv_global_region` VALUES ('1912', '227', '宿豫区', '3');
INSERT INTO `tv_global_region` VALUES ('1913', '227', '宿豫县', '3');
INSERT INTO `tv_global_region` VALUES ('1914', '227', '沭阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1915', '227', '泗阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1916', '227', '泗洪县', '3');
INSERT INTO `tv_global_region` VALUES ('1917', '228', '海陵区', '3');
INSERT INTO `tv_global_region` VALUES ('1918', '228', '高港区', '3');
INSERT INTO `tv_global_region` VALUES ('1919', '228', '兴化市', '3');
INSERT INTO `tv_global_region` VALUES ('1920', '228', '靖江市', '3');
INSERT INTO `tv_global_region` VALUES ('1921', '228', '泰兴市', '3');
INSERT INTO `tv_global_region` VALUES ('1922', '228', '姜堰市', '3');
INSERT INTO `tv_global_region` VALUES ('1923', '229', '云龙区', '3');
INSERT INTO `tv_global_region` VALUES ('1924', '229', '鼓楼区', '3');
INSERT INTO `tv_global_region` VALUES ('1925', '229', '九里区', '3');
INSERT INTO `tv_global_region` VALUES ('1926', '229', '贾汪区', '3');
INSERT INTO `tv_global_region` VALUES ('1927', '229', '泉山区', '3');
INSERT INTO `tv_global_region` VALUES ('1928', '229', '新沂市', '3');
INSERT INTO `tv_global_region` VALUES ('1929', '229', '邳州市', '3');
INSERT INTO `tv_global_region` VALUES ('1930', '229', '丰县', '3');
INSERT INTO `tv_global_region` VALUES ('1931', '229', '沛县', '3');
INSERT INTO `tv_global_region` VALUES ('1932', '229', '铜山县', '3');
INSERT INTO `tv_global_region` VALUES ('1933', '229', '睢宁县', '3');
INSERT INTO `tv_global_region` VALUES ('1934', '230', '城区', '3');
INSERT INTO `tv_global_region` VALUES ('1935', '230', '亭湖区', '3');
INSERT INTO `tv_global_region` VALUES ('1936', '230', '盐都区', '3');
INSERT INTO `tv_global_region` VALUES ('1937', '230', '盐都县', '3');
INSERT INTO `tv_global_region` VALUES ('1938', '230', '东台市', '3');
INSERT INTO `tv_global_region` VALUES ('1939', '230', '大丰市', '3');
INSERT INTO `tv_global_region` VALUES ('1940', '230', '响水县', '3');
INSERT INTO `tv_global_region` VALUES ('1941', '230', '滨海县', '3');
INSERT INTO `tv_global_region` VALUES ('1942', '230', '阜宁县', '3');
INSERT INTO `tv_global_region` VALUES ('1943', '230', '射阳县', '3');
INSERT INTO `tv_global_region` VALUES ('1944', '230', '建湖县', '3');
INSERT INTO `tv_global_region` VALUES ('1945', '231', '广陵区', '3');
INSERT INTO `tv_global_region` VALUES ('1946', '231', '维扬区', '3');
INSERT INTO `tv_global_region` VALUES ('1947', '231', '邗江区', '3');
INSERT INTO `tv_global_region` VALUES ('1948', '231', '仪征市', '3');
INSERT INTO `tv_global_region` VALUES ('1949', '231', '高邮市', '3');
INSERT INTO `tv_global_region` VALUES ('1950', '231', '江都市', '3');
INSERT INTO `tv_global_region` VALUES ('1951', '231', '宝应县', '3');
INSERT INTO `tv_global_region` VALUES ('1952', '232', '京口区', '3');
INSERT INTO `tv_global_region` VALUES ('1953', '232', '润州区', '3');
INSERT INTO `tv_global_region` VALUES ('1954', '232', '丹徒区', '3');
INSERT INTO `tv_global_region` VALUES ('1955', '232', '丹阳市', '3');
INSERT INTO `tv_global_region` VALUES ('1956', '232', '扬中市', '3');
INSERT INTO `tv_global_region` VALUES ('1957', '232', '句容市', '3');
INSERT INTO `tv_global_region` VALUES ('1958', '233', '东湖区', '3');
INSERT INTO `tv_global_region` VALUES ('1959', '233', '西湖区', '3');
INSERT INTO `tv_global_region` VALUES ('1960', '233', '青云谱区', '3');
INSERT INTO `tv_global_region` VALUES ('1961', '233', '湾里区', '3');
INSERT INTO `tv_global_region` VALUES ('1962', '233', '青山湖区', '3');
INSERT INTO `tv_global_region` VALUES ('1963', '233', '红谷滩新区', '3');
INSERT INTO `tv_global_region` VALUES ('1964', '233', '昌北区', '3');
INSERT INTO `tv_global_region` VALUES ('1965', '233', '高新区', '3');
INSERT INTO `tv_global_region` VALUES ('1966', '233', '南昌县', '3');
INSERT INTO `tv_global_region` VALUES ('1967', '233', '新建县', '3');
INSERT INTO `tv_global_region` VALUES ('1968', '233', '安义县', '3');
INSERT INTO `tv_global_region` VALUES ('1969', '233', '进贤县', '3');
INSERT INTO `tv_global_region` VALUES ('1970', '234', '临川区', '3');
INSERT INTO `tv_global_region` VALUES ('1971', '234', '南城县', '3');
INSERT INTO `tv_global_region` VALUES ('1972', '234', '黎川县', '3');
INSERT INTO `tv_global_region` VALUES ('1973', '234', '南丰县', '3');
INSERT INTO `tv_global_region` VALUES ('1974', '234', '崇仁县', '3');
INSERT INTO `tv_global_region` VALUES ('1975', '234', '乐安县', '3');
INSERT INTO `tv_global_region` VALUES ('1976', '234', '宜黄县', '3');
INSERT INTO `tv_global_region` VALUES ('1977', '234', '金溪县', '3');
INSERT INTO `tv_global_region` VALUES ('1978', '234', '资溪县', '3');
INSERT INTO `tv_global_region` VALUES ('1979', '234', '东乡县', '3');
INSERT INTO `tv_global_region` VALUES ('1980', '234', '广昌县', '3');
INSERT INTO `tv_global_region` VALUES ('1981', '235', '章贡区', '3');
INSERT INTO `tv_global_region` VALUES ('1982', '235', '于都县', '3');
INSERT INTO `tv_global_region` VALUES ('1983', '235', '瑞金市', '3');
INSERT INTO `tv_global_region` VALUES ('1984', '235', '南康市', '3');
INSERT INTO `tv_global_region` VALUES ('1985', '235', '赣县', '3');
INSERT INTO `tv_global_region` VALUES ('1986', '235', '信丰县', '3');
INSERT INTO `tv_global_region` VALUES ('1987', '235', '大余县', '3');
INSERT INTO `tv_global_region` VALUES ('1988', '235', '上犹县', '3');
INSERT INTO `tv_global_region` VALUES ('1989', '235', '崇义县', '3');
INSERT INTO `tv_global_region` VALUES ('1990', '235', '安远县', '3');
INSERT INTO `tv_global_region` VALUES ('1991', '235', '龙南县', '3');
INSERT INTO `tv_global_region` VALUES ('1992', '235', '定南县', '3');
INSERT INTO `tv_global_region` VALUES ('1993', '235', '全南县', '3');
INSERT INTO `tv_global_region` VALUES ('1994', '235', '宁都县', '3');
INSERT INTO `tv_global_region` VALUES ('1995', '235', '兴国县', '3');
INSERT INTO `tv_global_region` VALUES ('1996', '235', '会昌县', '3');
INSERT INTO `tv_global_region` VALUES ('1997', '235', '寻乌县', '3');
INSERT INTO `tv_global_region` VALUES ('1998', '235', '石城县', '3');
INSERT INTO `tv_global_region` VALUES ('1999', '236', '安福县', '3');
INSERT INTO `tv_global_region` VALUES ('2000', '236', '吉州区', '3');
INSERT INTO `tv_global_region` VALUES ('2001', '236', '青原区', '3');
INSERT INTO `tv_global_region` VALUES ('2002', '236', '井冈山市', '3');
INSERT INTO `tv_global_region` VALUES ('2003', '236', '吉安县', '3');
INSERT INTO `tv_global_region` VALUES ('2004', '236', '吉水县', '3');
INSERT INTO `tv_global_region` VALUES ('2005', '236', '峡江县', '3');
INSERT INTO `tv_global_region` VALUES ('2006', '236', '新干县', '3');
INSERT INTO `tv_global_region` VALUES ('2007', '236', '永丰县', '3');
INSERT INTO `tv_global_region` VALUES ('2008', '236', '泰和县', '3');
INSERT INTO `tv_global_region` VALUES ('2009', '236', '遂川县', '3');
INSERT INTO `tv_global_region` VALUES ('2010', '236', '万安县', '3');
INSERT INTO `tv_global_region` VALUES ('2011', '236', '永新县', '3');
INSERT INTO `tv_global_region` VALUES ('2012', '237', '珠山区', '3');
INSERT INTO `tv_global_region` VALUES ('2013', '237', '昌江区', '3');
INSERT INTO `tv_global_region` VALUES ('2014', '237', '乐平市', '3');
INSERT INTO `tv_global_region` VALUES ('2015', '237', '浮梁县', '3');
INSERT INTO `tv_global_region` VALUES ('2016', '238', '浔阳区', '3');
INSERT INTO `tv_global_region` VALUES ('2017', '238', '庐山区', '3');
INSERT INTO `tv_global_region` VALUES ('2018', '238', '瑞昌市', '3');
INSERT INTO `tv_global_region` VALUES ('2019', '238', '九江县', '3');
INSERT INTO `tv_global_region` VALUES ('2020', '238', '武宁县', '3');
INSERT INTO `tv_global_region` VALUES ('2021', '238', '修水县', '3');
INSERT INTO `tv_global_region` VALUES ('2022', '238', '永修县', '3');
INSERT INTO `tv_global_region` VALUES ('2023', '238', '德安县', '3');
INSERT INTO `tv_global_region` VALUES ('2024', '238', '星子县', '3');
INSERT INTO `tv_global_region` VALUES ('2025', '238', '都昌县', '3');
INSERT INTO `tv_global_region` VALUES ('2026', '238', '湖口县', '3');
INSERT INTO `tv_global_region` VALUES ('2027', '238', '彭泽县', '3');
INSERT INTO `tv_global_region` VALUES ('2028', '239', '安源区', '3');
INSERT INTO `tv_global_region` VALUES ('2029', '239', '湘东区', '3');
INSERT INTO `tv_global_region` VALUES ('2030', '239', '莲花县', '3');
INSERT INTO `tv_global_region` VALUES ('2031', '239', '芦溪县', '3');
INSERT INTO `tv_global_region` VALUES ('2032', '239', '上栗县', '3');
INSERT INTO `tv_global_region` VALUES ('2033', '240', '信州区', '3');
INSERT INTO `tv_global_region` VALUES ('2034', '240', '德兴市', '3');
INSERT INTO `tv_global_region` VALUES ('2035', '240', '上饶县', '3');
INSERT INTO `tv_global_region` VALUES ('2036', '240', '广丰县', '3');
INSERT INTO `tv_global_region` VALUES ('2037', '240', '玉山县', '3');
INSERT INTO `tv_global_region` VALUES ('2038', '240', '铅山县', '3');
INSERT INTO `tv_global_region` VALUES ('2039', '240', '横峰县', '3');
INSERT INTO `tv_global_region` VALUES ('2040', '240', '弋阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2041', '240', '余干县', '3');
INSERT INTO `tv_global_region` VALUES ('2042', '240', '波阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2043', '240', '万年县', '3');
INSERT INTO `tv_global_region` VALUES ('2044', '240', '婺源县', '3');
INSERT INTO `tv_global_region` VALUES ('2045', '241', '渝水区', '3');
INSERT INTO `tv_global_region` VALUES ('2046', '241', '分宜县', '3');
INSERT INTO `tv_global_region` VALUES ('2047', '242', '袁州区', '3');
INSERT INTO `tv_global_region` VALUES ('2048', '242', '丰城市', '3');
INSERT INTO `tv_global_region` VALUES ('2049', '242', '樟树市', '3');
INSERT INTO `tv_global_region` VALUES ('2050', '242', '高安市', '3');
INSERT INTO `tv_global_region` VALUES ('2051', '242', '奉新县', '3');
INSERT INTO `tv_global_region` VALUES ('2052', '242', '万载县', '3');
INSERT INTO `tv_global_region` VALUES ('2053', '242', '上高县', '3');
INSERT INTO `tv_global_region` VALUES ('2054', '242', '宜丰县', '3');
INSERT INTO `tv_global_region` VALUES ('2055', '242', '靖安县', '3');
INSERT INTO `tv_global_region` VALUES ('2056', '242', '铜鼓县', '3');
INSERT INTO `tv_global_region` VALUES ('2057', '243', '月湖区', '3');
INSERT INTO `tv_global_region` VALUES ('2058', '243', '贵溪市', '3');
INSERT INTO `tv_global_region` VALUES ('2059', '243', '余江县', '3');
INSERT INTO `tv_global_region` VALUES ('2060', '244', '沈河区', '3');
INSERT INTO `tv_global_region` VALUES ('2061', '244', '皇姑区', '3');
INSERT INTO `tv_global_region` VALUES ('2062', '244', '和平区', '3');
INSERT INTO `tv_global_region` VALUES ('2063', '244', '大东区', '3');
INSERT INTO `tv_global_region` VALUES ('2064', '244', '铁西区', '3');
INSERT INTO `tv_global_region` VALUES ('2065', '244', '苏家屯区', '3');
INSERT INTO `tv_global_region` VALUES ('2066', '244', '东陵区', '3');
INSERT INTO `tv_global_region` VALUES ('2067', '244', '沈北新区', '3');
INSERT INTO `tv_global_region` VALUES ('2068', '244', '于洪区', '3');
INSERT INTO `tv_global_region` VALUES ('2069', '244', '浑南新区', '3');
INSERT INTO `tv_global_region` VALUES ('2070', '244', '新民市', '3');
INSERT INTO `tv_global_region` VALUES ('2071', '244', '辽中县', '3');
INSERT INTO `tv_global_region` VALUES ('2072', '244', '康平县', '3');
INSERT INTO `tv_global_region` VALUES ('2073', '244', '法库县', '3');
INSERT INTO `tv_global_region` VALUES ('2074', '245', '西岗区', '3');
INSERT INTO `tv_global_region` VALUES ('2075', '245', '中山区', '3');
INSERT INTO `tv_global_region` VALUES ('2076', '245', '沙河口区', '3');
INSERT INTO `tv_global_region` VALUES ('2077', '245', '甘井子区', '3');
INSERT INTO `tv_global_region` VALUES ('2078', '245', '旅顺口区', '3');
INSERT INTO `tv_global_region` VALUES ('2079', '245', '金州区', '3');
INSERT INTO `tv_global_region` VALUES ('2080', '245', '开发区', '3');
INSERT INTO `tv_global_region` VALUES ('2081', '245', '瓦房店市', '3');
INSERT INTO `tv_global_region` VALUES ('2082', '245', '普兰店市', '3');
INSERT INTO `tv_global_region` VALUES ('2083', '245', '庄河市', '3');
INSERT INTO `tv_global_region` VALUES ('2084', '245', '长海县', '3');
INSERT INTO `tv_global_region` VALUES ('2085', '246', '铁东区', '3');
INSERT INTO `tv_global_region` VALUES ('2086', '246', '铁西区', '3');
INSERT INTO `tv_global_region` VALUES ('2087', '246', '立山区', '3');
INSERT INTO `tv_global_region` VALUES ('2088', '246', '千山区', '3');
INSERT INTO `tv_global_region` VALUES ('2089', '246', '岫岩', '3');
INSERT INTO `tv_global_region` VALUES ('2090', '246', '海城市', '3');
INSERT INTO `tv_global_region` VALUES ('2091', '246', '台安县', '3');
INSERT INTO `tv_global_region` VALUES ('2092', '247', '本溪', '3');
INSERT INTO `tv_global_region` VALUES ('2093', '247', '平山区', '3');
INSERT INTO `tv_global_region` VALUES ('2094', '247', '明山区', '3');
INSERT INTO `tv_global_region` VALUES ('2095', '247', '溪湖区', '3');
INSERT INTO `tv_global_region` VALUES ('2096', '247', '南芬区', '3');
INSERT INTO `tv_global_region` VALUES ('2097', '247', '桓仁', '3');
INSERT INTO `tv_global_region` VALUES ('2098', '248', '双塔区', '3');
INSERT INTO `tv_global_region` VALUES ('2099', '248', '龙城区', '3');
INSERT INTO `tv_global_region` VALUES ('2100', '248', '喀喇沁左翼蒙古族自治县', '3');
INSERT INTO `tv_global_region` VALUES ('2101', '248', '北票市', '3');
INSERT INTO `tv_global_region` VALUES ('2102', '248', '凌源市', '3');
INSERT INTO `tv_global_region` VALUES ('2103', '248', '朝阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2104', '248', '建平县', '3');
INSERT INTO `tv_global_region` VALUES ('2105', '249', '振兴区', '3');
INSERT INTO `tv_global_region` VALUES ('2106', '249', '元宝区', '3');
INSERT INTO `tv_global_region` VALUES ('2107', '249', '振安区', '3');
INSERT INTO `tv_global_region` VALUES ('2108', '249', '宽甸', '3');
INSERT INTO `tv_global_region` VALUES ('2109', '249', '东港市', '3');
INSERT INTO `tv_global_region` VALUES ('2110', '249', '凤城市', '3');
INSERT INTO `tv_global_region` VALUES ('2111', '250', '顺城区', '3');
INSERT INTO `tv_global_region` VALUES ('2112', '250', '新抚区', '3');
INSERT INTO `tv_global_region` VALUES ('2113', '250', '东洲区', '3');
INSERT INTO `tv_global_region` VALUES ('2114', '250', '望花区', '3');
INSERT INTO `tv_global_region` VALUES ('2115', '250', '清原', '3');
INSERT INTO `tv_global_region` VALUES ('2116', '250', '新宾', '3');
INSERT INTO `tv_global_region` VALUES ('2117', '250', '抚顺县', '3');
INSERT INTO `tv_global_region` VALUES ('2118', '251', '阜新', '3');
INSERT INTO `tv_global_region` VALUES ('2119', '251', '海州区', '3');
INSERT INTO `tv_global_region` VALUES ('2120', '251', '新邱区', '3');
INSERT INTO `tv_global_region` VALUES ('2121', '251', '太平区', '3');
INSERT INTO `tv_global_region` VALUES ('2122', '251', '清河门区', '3');
INSERT INTO `tv_global_region` VALUES ('2123', '251', '细河区', '3');
INSERT INTO `tv_global_region` VALUES ('2124', '251', '彰武县', '3');
INSERT INTO `tv_global_region` VALUES ('2125', '252', '龙港区', '3');
INSERT INTO `tv_global_region` VALUES ('2126', '252', '南票区', '3');
INSERT INTO `tv_global_region` VALUES ('2127', '252', '连山区', '3');
INSERT INTO `tv_global_region` VALUES ('2128', '252', '兴城市', '3');
INSERT INTO `tv_global_region` VALUES ('2129', '252', '绥中县', '3');
INSERT INTO `tv_global_region` VALUES ('2130', '252', '建昌县', '3');
INSERT INTO `tv_global_region` VALUES ('2131', '253', '太和区', '3');
INSERT INTO `tv_global_region` VALUES ('2132', '253', '古塔区', '3');
INSERT INTO `tv_global_region` VALUES ('2133', '253', '凌河区', '3');
INSERT INTO `tv_global_region` VALUES ('2134', '253', '凌海市', '3');
INSERT INTO `tv_global_region` VALUES ('2135', '253', '北镇市', '3');
INSERT INTO `tv_global_region` VALUES ('2136', '253', '黑山县', '3');
INSERT INTO `tv_global_region` VALUES ('2137', '253', '义县', '3');
INSERT INTO `tv_global_region` VALUES ('2138', '254', '白塔区', '3');
INSERT INTO `tv_global_region` VALUES ('2139', '254', '文圣区', '3');
INSERT INTO `tv_global_region` VALUES ('2140', '254', '宏伟区', '3');
INSERT INTO `tv_global_region` VALUES ('2141', '254', '太子河区', '3');
INSERT INTO `tv_global_region` VALUES ('2142', '254', '弓长岭区', '3');
INSERT INTO `tv_global_region` VALUES ('2143', '254', '灯塔市', '3');
INSERT INTO `tv_global_region` VALUES ('2144', '254', '辽阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2145', '255', '双台子区', '3');
INSERT INTO `tv_global_region` VALUES ('2146', '255', '兴隆台区', '3');
INSERT INTO `tv_global_region` VALUES ('2147', '255', '大洼县', '3');
INSERT INTO `tv_global_region` VALUES ('2148', '255', '盘山县', '3');
INSERT INTO `tv_global_region` VALUES ('2149', '256', '银州区', '3');
INSERT INTO `tv_global_region` VALUES ('2150', '256', '清河区', '3');
INSERT INTO `tv_global_region` VALUES ('2151', '256', '调兵山市', '3');
INSERT INTO `tv_global_region` VALUES ('2152', '256', '开原市', '3');
INSERT INTO `tv_global_region` VALUES ('2153', '256', '铁岭县', '3');
INSERT INTO `tv_global_region` VALUES ('2154', '256', '西丰县', '3');
INSERT INTO `tv_global_region` VALUES ('2155', '256', '昌图县', '3');
INSERT INTO `tv_global_region` VALUES ('2156', '257', '站前区', '3');
INSERT INTO `tv_global_region` VALUES ('2157', '257', '西市区', '3');
INSERT INTO `tv_global_region` VALUES ('2158', '257', '鲅鱼圈区', '3');
INSERT INTO `tv_global_region` VALUES ('2159', '257', '老边区', '3');
INSERT INTO `tv_global_region` VALUES ('2160', '257', '盖州市', '3');
INSERT INTO `tv_global_region` VALUES ('2161', '257', '大石桥市', '3');
INSERT INTO `tv_global_region` VALUES ('2162', '258', '回民区', '3');
INSERT INTO `tv_global_region` VALUES ('2163', '258', '玉泉区', '3');
INSERT INTO `tv_global_region` VALUES ('2164', '258', '新城区', '3');
INSERT INTO `tv_global_region` VALUES ('2165', '258', '赛罕区', '3');
INSERT INTO `tv_global_region` VALUES ('2166', '258', '清水河县', '3');
INSERT INTO `tv_global_region` VALUES ('2167', '258', '土默特左旗', '3');
INSERT INTO `tv_global_region` VALUES ('2168', '258', '托克托县', '3');
INSERT INTO `tv_global_region` VALUES ('2169', '258', '和林格尔县', '3');
INSERT INTO `tv_global_region` VALUES ('2170', '258', '武川县', '3');
INSERT INTO `tv_global_region` VALUES ('2171', '259', '阿拉善左旗', '3');
INSERT INTO `tv_global_region` VALUES ('2172', '259', '阿拉善右旗', '3');
INSERT INTO `tv_global_region` VALUES ('2173', '259', '额济纳旗', '3');
INSERT INTO `tv_global_region` VALUES ('2174', '260', '临河区', '3');
INSERT INTO `tv_global_region` VALUES ('2175', '260', '五原县', '3');
INSERT INTO `tv_global_region` VALUES ('2176', '260', '磴口县', '3');
INSERT INTO `tv_global_region` VALUES ('2177', '260', '乌拉特前旗', '3');
INSERT INTO `tv_global_region` VALUES ('2178', '260', '乌拉特中旗', '3');
INSERT INTO `tv_global_region` VALUES ('2179', '260', '乌拉特后旗', '3');
INSERT INTO `tv_global_region` VALUES ('2180', '260', '杭锦后旗', '3');
INSERT INTO `tv_global_region` VALUES ('2181', '261', '昆都仑区', '3');
INSERT INTO `tv_global_region` VALUES ('2182', '261', '青山区', '3');
INSERT INTO `tv_global_region` VALUES ('2183', '261', '东河区', '3');
INSERT INTO `tv_global_region` VALUES ('2184', '261', '九原区', '3');
INSERT INTO `tv_global_region` VALUES ('2185', '261', '石拐区', '3');
INSERT INTO `tv_global_region` VALUES ('2186', '261', '白云矿区', '3');
INSERT INTO `tv_global_region` VALUES ('2187', '261', '土默特右旗', '3');
INSERT INTO `tv_global_region` VALUES ('2188', '261', '固阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2189', '261', '达尔罕茂明安联合旗', '3');
INSERT INTO `tv_global_region` VALUES ('2190', '262', '红山区', '3');
INSERT INTO `tv_global_region` VALUES ('2191', '262', '元宝山区', '3');
INSERT INTO `tv_global_region` VALUES ('2192', '262', '松山区', '3');
INSERT INTO `tv_global_region` VALUES ('2193', '262', '阿鲁科尔沁旗', '3');
INSERT INTO `tv_global_region` VALUES ('2194', '262', '巴林左旗', '3');
INSERT INTO `tv_global_region` VALUES ('2195', '262', '巴林右旗', '3');
INSERT INTO `tv_global_region` VALUES ('2196', '262', '林西县', '3');
INSERT INTO `tv_global_region` VALUES ('2197', '262', '克什克腾旗', '3');
INSERT INTO `tv_global_region` VALUES ('2198', '262', '翁牛特旗', '3');
INSERT INTO `tv_global_region` VALUES ('2199', '262', '喀喇沁旗', '3');
INSERT INTO `tv_global_region` VALUES ('2200', '262', '宁城县', '3');
INSERT INTO `tv_global_region` VALUES ('2201', '262', '敖汉旗', '3');
INSERT INTO `tv_global_region` VALUES ('2202', '263', '东胜区', '3');
INSERT INTO `tv_global_region` VALUES ('2203', '263', '达拉特旗', '3');
INSERT INTO `tv_global_region` VALUES ('2204', '263', '准格尔旗', '3');
INSERT INTO `tv_global_region` VALUES ('2205', '263', '鄂托克前旗', '3');
INSERT INTO `tv_global_region` VALUES ('2206', '263', '鄂托克旗', '3');
INSERT INTO `tv_global_region` VALUES ('2207', '263', '杭锦旗', '3');
INSERT INTO `tv_global_region` VALUES ('2208', '263', '乌审旗', '3');
INSERT INTO `tv_global_region` VALUES ('2209', '263', '伊金霍洛旗', '3');
INSERT INTO `tv_global_region` VALUES ('2210', '264', '海拉尔区', '3');
INSERT INTO `tv_global_region` VALUES ('2211', '264', '莫力达瓦', '3');
INSERT INTO `tv_global_region` VALUES ('2212', '264', '满洲里市', '3');
INSERT INTO `tv_global_region` VALUES ('2213', '264', '牙克石市', '3');
INSERT INTO `tv_global_region` VALUES ('2214', '264', '扎兰屯市', '3');
INSERT INTO `tv_global_region` VALUES ('2215', '264', '额尔古纳市', '3');
INSERT INTO `tv_global_region` VALUES ('2216', '264', '根河市', '3');
INSERT INTO `tv_global_region` VALUES ('2217', '264', '阿荣旗', '3');
INSERT INTO `tv_global_region` VALUES ('2218', '264', '鄂伦春自治旗', '3');
INSERT INTO `tv_global_region` VALUES ('2219', '264', '鄂温克族自治旗', '3');
INSERT INTO `tv_global_region` VALUES ('2220', '264', '陈巴尔虎旗', '3');
INSERT INTO `tv_global_region` VALUES ('2221', '264', '新巴尔虎左旗', '3');
INSERT INTO `tv_global_region` VALUES ('2222', '264', '新巴尔虎右旗', '3');
INSERT INTO `tv_global_region` VALUES ('2223', '265', '科尔沁区', '3');
INSERT INTO `tv_global_region` VALUES ('2224', '265', '霍林郭勒市', '3');
INSERT INTO `tv_global_region` VALUES ('2225', '265', '科尔沁左翼中旗', '3');
INSERT INTO `tv_global_region` VALUES ('2226', '265', '科尔沁左翼后旗', '3');
INSERT INTO `tv_global_region` VALUES ('2227', '265', '开鲁县', '3');
INSERT INTO `tv_global_region` VALUES ('2228', '265', '库伦旗', '3');
INSERT INTO `tv_global_region` VALUES ('2229', '265', '奈曼旗', '3');
INSERT INTO `tv_global_region` VALUES ('2230', '265', '扎鲁特旗', '3');
INSERT INTO `tv_global_region` VALUES ('2231', '266', '海勃湾区', '3');
INSERT INTO `tv_global_region` VALUES ('2232', '266', '乌达区', '3');
INSERT INTO `tv_global_region` VALUES ('2233', '266', '海南区', '3');
INSERT INTO `tv_global_region` VALUES ('2234', '267', '化德县', '3');
INSERT INTO `tv_global_region` VALUES ('2235', '267', '集宁区', '3');
INSERT INTO `tv_global_region` VALUES ('2236', '267', '丰镇市', '3');
INSERT INTO `tv_global_region` VALUES ('2237', '267', '卓资县', '3');
INSERT INTO `tv_global_region` VALUES ('2238', '267', '商都县', '3');
INSERT INTO `tv_global_region` VALUES ('2239', '267', '兴和县', '3');
INSERT INTO `tv_global_region` VALUES ('2240', '267', '凉城县', '3');
INSERT INTO `tv_global_region` VALUES ('2241', '267', '察哈尔右翼前旗', '3');
INSERT INTO `tv_global_region` VALUES ('2242', '267', '察哈尔右翼中旗', '3');
INSERT INTO `tv_global_region` VALUES ('2243', '267', '察哈尔右翼后旗', '3');
INSERT INTO `tv_global_region` VALUES ('2244', '267', '四子王旗', '3');
INSERT INTO `tv_global_region` VALUES ('2245', '268', '二连浩特市', '3');
INSERT INTO `tv_global_region` VALUES ('2246', '268', '锡林浩特市', '3');
INSERT INTO `tv_global_region` VALUES ('2247', '268', '阿巴嘎旗', '3');
INSERT INTO `tv_global_region` VALUES ('2248', '268', '苏尼特左旗', '3');
INSERT INTO `tv_global_region` VALUES ('2249', '268', '苏尼特右旗', '3');
INSERT INTO `tv_global_region` VALUES ('2250', '268', '东乌珠穆沁旗', '3');
INSERT INTO `tv_global_region` VALUES ('2251', '268', '西乌珠穆沁旗', '3');
INSERT INTO `tv_global_region` VALUES ('2252', '268', '太仆寺旗', '3');
INSERT INTO `tv_global_region` VALUES ('2253', '268', '镶黄旗', '3');
INSERT INTO `tv_global_region` VALUES ('2254', '268', '正镶白旗', '3');
INSERT INTO `tv_global_region` VALUES ('2255', '268', '正蓝旗', '3');
INSERT INTO `tv_global_region` VALUES ('2256', '268', '多伦县', '3');
INSERT INTO `tv_global_region` VALUES ('2257', '269', '乌兰浩特市', '3');
INSERT INTO `tv_global_region` VALUES ('2258', '269', '阿尔山市', '3');
INSERT INTO `tv_global_region` VALUES ('2259', '269', '科尔沁右翼前旗', '3');
INSERT INTO `tv_global_region` VALUES ('2260', '269', '科尔沁右翼中旗', '3');
INSERT INTO `tv_global_region` VALUES ('2261', '269', '扎赉特旗', '3');
INSERT INTO `tv_global_region` VALUES ('2262', '269', '突泉县', '3');
INSERT INTO `tv_global_region` VALUES ('2263', '270', '西夏区', '3');
INSERT INTO `tv_global_region` VALUES ('2264', '270', '金凤区', '3');
INSERT INTO `tv_global_region` VALUES ('2265', '270', '兴庆区', '3');
INSERT INTO `tv_global_region` VALUES ('2266', '270', '灵武市', '3');
INSERT INTO `tv_global_region` VALUES ('2267', '270', '永宁县', '3');
INSERT INTO `tv_global_region` VALUES ('2268', '270', '贺兰县', '3');
INSERT INTO `tv_global_region` VALUES ('2269', '271', '原州区', '3');
INSERT INTO `tv_global_region` VALUES ('2270', '271', '海原县', '3');
INSERT INTO `tv_global_region` VALUES ('2271', '271', '西吉县', '3');
INSERT INTO `tv_global_region` VALUES ('2272', '271', '隆德县', '3');
INSERT INTO `tv_global_region` VALUES ('2273', '271', '泾源县', '3');
INSERT INTO `tv_global_region` VALUES ('2274', '271', '彭阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2275', '272', '惠农县', '3');
INSERT INTO `tv_global_region` VALUES ('2276', '272', '大武口区', '3');
INSERT INTO `tv_global_region` VALUES ('2277', '272', '惠农区', '3');
INSERT INTO `tv_global_region` VALUES ('2278', '272', '陶乐县', '3');
INSERT INTO `tv_global_region` VALUES ('2279', '272', '平罗县', '3');
INSERT INTO `tv_global_region` VALUES ('2280', '273', '利通区', '3');
INSERT INTO `tv_global_region` VALUES ('2281', '273', '中卫县', '3');
INSERT INTO `tv_global_region` VALUES ('2282', '273', '青铜峡市', '3');
INSERT INTO `tv_global_region` VALUES ('2283', '273', '中宁县', '3');
INSERT INTO `tv_global_region` VALUES ('2284', '273', '盐池县', '3');
INSERT INTO `tv_global_region` VALUES ('2285', '273', '同心县', '3');
INSERT INTO `tv_global_region` VALUES ('2286', '274', '沙坡头区', '3');
INSERT INTO `tv_global_region` VALUES ('2287', '274', '海原县', '3');
INSERT INTO `tv_global_region` VALUES ('2288', '274', '中宁县', '3');
INSERT INTO `tv_global_region` VALUES ('2289', '275', '城中区', '3');
INSERT INTO `tv_global_region` VALUES ('2290', '275', '城东区', '3');
INSERT INTO `tv_global_region` VALUES ('2291', '275', '城西区', '3');
INSERT INTO `tv_global_region` VALUES ('2292', '275', '城北区', '3');
INSERT INTO `tv_global_region` VALUES ('2293', '275', '湟中县', '3');
INSERT INTO `tv_global_region` VALUES ('2294', '275', '湟源县', '3');
INSERT INTO `tv_global_region` VALUES ('2295', '275', '大通', '3');
INSERT INTO `tv_global_region` VALUES ('2296', '276', '玛沁县', '3');
INSERT INTO `tv_global_region` VALUES ('2297', '276', '班玛县', '3');
INSERT INTO `tv_global_region` VALUES ('2298', '276', '甘德县', '3');
INSERT INTO `tv_global_region` VALUES ('2299', '276', '达日县', '3');
INSERT INTO `tv_global_region` VALUES ('2300', '276', '久治县', '3');
INSERT INTO `tv_global_region` VALUES ('2301', '276', '玛多县', '3');
INSERT INTO `tv_global_region` VALUES ('2302', '277', '海晏县', '3');
INSERT INTO `tv_global_region` VALUES ('2303', '277', '祁连县', '3');
INSERT INTO `tv_global_region` VALUES ('2304', '277', '刚察县', '3');
INSERT INTO `tv_global_region` VALUES ('2305', '277', '门源', '3');
INSERT INTO `tv_global_region` VALUES ('2306', '278', '平安县', '3');
INSERT INTO `tv_global_region` VALUES ('2307', '278', '乐都县', '3');
INSERT INTO `tv_global_region` VALUES ('2308', '278', '民和', '3');
INSERT INTO `tv_global_region` VALUES ('2309', '278', '互助', '3');
INSERT INTO `tv_global_region` VALUES ('2310', '278', '化隆', '3');
INSERT INTO `tv_global_region` VALUES ('2311', '278', '循化', '3');
INSERT INTO `tv_global_region` VALUES ('2312', '279', '共和县', '3');
INSERT INTO `tv_global_region` VALUES ('2313', '279', '同德县', '3');
INSERT INTO `tv_global_region` VALUES ('2314', '279', '贵德县', '3');
INSERT INTO `tv_global_region` VALUES ('2315', '279', '兴海县', '3');
INSERT INTO `tv_global_region` VALUES ('2316', '279', '贵南县', '3');
INSERT INTO `tv_global_region` VALUES ('2317', '280', '德令哈市', '3');
INSERT INTO `tv_global_region` VALUES ('2318', '280', '格尔木市', '3');
INSERT INTO `tv_global_region` VALUES ('2319', '280', '乌兰县', '3');
INSERT INTO `tv_global_region` VALUES ('2320', '280', '都兰县', '3');
INSERT INTO `tv_global_region` VALUES ('2321', '280', '天峻县', '3');
INSERT INTO `tv_global_region` VALUES ('2322', '281', '同仁县', '3');
INSERT INTO `tv_global_region` VALUES ('2323', '281', '尖扎县', '3');
INSERT INTO `tv_global_region` VALUES ('2324', '281', '泽库县', '3');
INSERT INTO `tv_global_region` VALUES ('2325', '281', '河南蒙古族自治县', '3');
INSERT INTO `tv_global_region` VALUES ('2326', '282', '玉树县', '3');
INSERT INTO `tv_global_region` VALUES ('2327', '282', '杂多县', '3');
INSERT INTO `tv_global_region` VALUES ('2328', '282', '称多县', '3');
INSERT INTO `tv_global_region` VALUES ('2329', '282', '治多县', '3');
INSERT INTO `tv_global_region` VALUES ('2330', '282', '囊谦县', '3');
INSERT INTO `tv_global_region` VALUES ('2331', '282', '曲麻莱县', '3');
INSERT INTO `tv_global_region` VALUES ('2332', '283', '市中区', '3');
INSERT INTO `tv_global_region` VALUES ('2333', '283', '历下区', '3');
INSERT INTO `tv_global_region` VALUES ('2334', '283', '天桥区', '3');
INSERT INTO `tv_global_region` VALUES ('2335', '283', '槐荫区', '3');
INSERT INTO `tv_global_region` VALUES ('2336', '283', '历城区', '3');
INSERT INTO `tv_global_region` VALUES ('2337', '283', '长清区', '3');
INSERT INTO `tv_global_region` VALUES ('2338', '283', '章丘市', '3');
INSERT INTO `tv_global_region` VALUES ('2339', '283', '平阴县', '3');
INSERT INTO `tv_global_region` VALUES ('2340', '283', '济阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2341', '283', '商河县', '3');
INSERT INTO `tv_global_region` VALUES ('2342', '284', '市南区', '3');
INSERT INTO `tv_global_region` VALUES ('2343', '284', '市北区', '3');
INSERT INTO `tv_global_region` VALUES ('2344', '284', '城阳区', '3');
INSERT INTO `tv_global_region` VALUES ('2345', '284', '四方区', '3');
INSERT INTO `tv_global_region` VALUES ('2346', '284', '李沧区', '3');
INSERT INTO `tv_global_region` VALUES ('2347', '284', '黄岛区', '3');
INSERT INTO `tv_global_region` VALUES ('2348', '284', '崂山区', '3');
INSERT INTO `tv_global_region` VALUES ('2349', '284', '胶州市', '3');
INSERT INTO `tv_global_region` VALUES ('2350', '284', '即墨市', '3');
INSERT INTO `tv_global_region` VALUES ('2351', '284', '平度市', '3');
INSERT INTO `tv_global_region` VALUES ('2352', '284', '胶南市', '3');
INSERT INTO `tv_global_region` VALUES ('2353', '284', '莱西市', '3');
INSERT INTO `tv_global_region` VALUES ('2354', '285', '滨城区', '3');
INSERT INTO `tv_global_region` VALUES ('2355', '285', '惠民县', '3');
INSERT INTO `tv_global_region` VALUES ('2356', '285', '阳信县', '3');
INSERT INTO `tv_global_region` VALUES ('2357', '285', '无棣县', '3');
INSERT INTO `tv_global_region` VALUES ('2358', '285', '沾化县', '3');
INSERT INTO `tv_global_region` VALUES ('2359', '285', '博兴县', '3');
INSERT INTO `tv_global_region` VALUES ('2360', '285', '邹平县', '3');
INSERT INTO `tv_global_region` VALUES ('2361', '286', '德城区', '3');
INSERT INTO `tv_global_region` VALUES ('2362', '286', '陵县', '3');
INSERT INTO `tv_global_region` VALUES ('2363', '286', '乐陵市', '3');
INSERT INTO `tv_global_region` VALUES ('2364', '286', '禹城市', '3');
INSERT INTO `tv_global_region` VALUES ('2365', '286', '宁津县', '3');
INSERT INTO `tv_global_region` VALUES ('2366', '286', '庆云县', '3');
INSERT INTO `tv_global_region` VALUES ('2367', '286', '临邑县', '3');
INSERT INTO `tv_global_region` VALUES ('2368', '286', '齐河县', '3');
INSERT INTO `tv_global_region` VALUES ('2369', '286', '平原县', '3');
INSERT INTO `tv_global_region` VALUES ('2370', '286', '夏津县', '3');
INSERT INTO `tv_global_region` VALUES ('2371', '286', '武城县', '3');
INSERT INTO `tv_global_region` VALUES ('2372', '287', '东营区', '3');
INSERT INTO `tv_global_region` VALUES ('2373', '287', '河口区', '3');
INSERT INTO `tv_global_region` VALUES ('2374', '287', '垦利县', '3');
INSERT INTO `tv_global_region` VALUES ('2375', '287', '利津县', '3');
INSERT INTO `tv_global_region` VALUES ('2376', '287', '广饶县', '3');
INSERT INTO `tv_global_region` VALUES ('2377', '288', '牡丹区', '3');
INSERT INTO `tv_global_region` VALUES ('2378', '288', '曹县', '3');
INSERT INTO `tv_global_region` VALUES ('2379', '288', '单县', '3');
INSERT INTO `tv_global_region` VALUES ('2380', '288', '成武县', '3');
INSERT INTO `tv_global_region` VALUES ('2381', '288', '巨野县', '3');
INSERT INTO `tv_global_region` VALUES ('2382', '288', '郓城县', '3');
INSERT INTO `tv_global_region` VALUES ('2383', '288', '鄄城县', '3');
INSERT INTO `tv_global_region` VALUES ('2384', '288', '定陶县', '3');
INSERT INTO `tv_global_region` VALUES ('2385', '288', '东明县', '3');
INSERT INTO `tv_global_region` VALUES ('2386', '289', '市中区', '3');
INSERT INTO `tv_global_region` VALUES ('2387', '289', '任城区', '3');
INSERT INTO `tv_global_region` VALUES ('2388', '289', '曲阜市', '3');
INSERT INTO `tv_global_region` VALUES ('2389', '289', '兖州市', '3');
INSERT INTO `tv_global_region` VALUES ('2390', '289', '邹城市', '3');
INSERT INTO `tv_global_region` VALUES ('2391', '289', '微山县', '3');
INSERT INTO `tv_global_region` VALUES ('2392', '289', '鱼台县', '3');
INSERT INTO `tv_global_region` VALUES ('2393', '289', '金乡县', '3');
INSERT INTO `tv_global_region` VALUES ('2394', '289', '嘉祥县', '3');
INSERT INTO `tv_global_region` VALUES ('2395', '289', '汶上县', '3');
INSERT INTO `tv_global_region` VALUES ('2396', '289', '泗水县', '3');
INSERT INTO `tv_global_region` VALUES ('2397', '289', '梁山县', '3');
INSERT INTO `tv_global_region` VALUES ('2398', '290', '莱城区', '3');
INSERT INTO `tv_global_region` VALUES ('2399', '290', '钢城区', '3');
INSERT INTO `tv_global_region` VALUES ('2400', '291', '东昌府区', '3');
INSERT INTO `tv_global_region` VALUES ('2401', '291', '临清市', '3');
INSERT INTO `tv_global_region` VALUES ('2402', '291', '阳谷县', '3');
INSERT INTO `tv_global_region` VALUES ('2403', '291', '莘县', '3');
INSERT INTO `tv_global_region` VALUES ('2404', '291', '茌平县', '3');
INSERT INTO `tv_global_region` VALUES ('2405', '291', '东阿县', '3');
INSERT INTO `tv_global_region` VALUES ('2406', '291', '冠县', '3');
INSERT INTO `tv_global_region` VALUES ('2407', '291', '高唐县', '3');
INSERT INTO `tv_global_region` VALUES ('2408', '292', '兰山区', '3');
INSERT INTO `tv_global_region` VALUES ('2409', '292', '罗庄区', '3');
INSERT INTO `tv_global_region` VALUES ('2410', '292', '河东区', '3');
INSERT INTO `tv_global_region` VALUES ('2411', '292', '沂南县', '3');
INSERT INTO `tv_global_region` VALUES ('2412', '292', '郯城县', '3');
INSERT INTO `tv_global_region` VALUES ('2413', '292', '沂水县', '3');
INSERT INTO `tv_global_region` VALUES ('2414', '292', '苍山县', '3');
INSERT INTO `tv_global_region` VALUES ('2415', '292', '费县', '3');
INSERT INTO `tv_global_region` VALUES ('2416', '292', '平邑县', '3');
INSERT INTO `tv_global_region` VALUES ('2417', '292', '莒南县', '3');
INSERT INTO `tv_global_region` VALUES ('2418', '292', '蒙阴县', '3');
INSERT INTO `tv_global_region` VALUES ('2419', '292', '临沭县', '3');
INSERT INTO `tv_global_region` VALUES ('2420', '293', '东港区', '3');
INSERT INTO `tv_global_region` VALUES ('2421', '293', '岚山区', '3');
INSERT INTO `tv_global_region` VALUES ('2422', '293', '五莲县', '3');
INSERT INTO `tv_global_region` VALUES ('2423', '293', '莒县', '3');
INSERT INTO `tv_global_region` VALUES ('2424', '294', '泰山区', '3');
INSERT INTO `tv_global_region` VALUES ('2425', '294', '岱岳区', '3');
INSERT INTO `tv_global_region` VALUES ('2426', '294', '新泰市', '3');
INSERT INTO `tv_global_region` VALUES ('2427', '294', '肥城市', '3');
INSERT INTO `tv_global_region` VALUES ('2428', '294', '宁阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2429', '294', '东平县', '3');
INSERT INTO `tv_global_region` VALUES ('2430', '295', '荣成市', '3');
INSERT INTO `tv_global_region` VALUES ('2431', '295', '乳山市', '3');
INSERT INTO `tv_global_region` VALUES ('2432', '295', '环翠区', '3');
INSERT INTO `tv_global_region` VALUES ('2433', '295', '文登市', '3');
INSERT INTO `tv_global_region` VALUES ('2434', '296', '潍城区', '3');
INSERT INTO `tv_global_region` VALUES ('2435', '296', '寒亭区', '3');
INSERT INTO `tv_global_region` VALUES ('2436', '296', '坊子区', '3');
INSERT INTO `tv_global_region` VALUES ('2437', '296', '奎文区', '3');
INSERT INTO `tv_global_region` VALUES ('2438', '296', '青州市', '3');
INSERT INTO `tv_global_region` VALUES ('2439', '296', '诸城市', '3');
INSERT INTO `tv_global_region` VALUES ('2440', '296', '寿光市', '3');
INSERT INTO `tv_global_region` VALUES ('2441', '296', '安丘市', '3');
INSERT INTO `tv_global_region` VALUES ('2442', '296', '高密市', '3');
INSERT INTO `tv_global_region` VALUES ('2443', '296', '昌邑市', '3');
INSERT INTO `tv_global_region` VALUES ('2444', '296', '临朐县', '3');
INSERT INTO `tv_global_region` VALUES ('2445', '296', '昌乐县', '3');
INSERT INTO `tv_global_region` VALUES ('2446', '297', '芝罘区', '3');
INSERT INTO `tv_global_region` VALUES ('2447', '297', '福山区', '3');
INSERT INTO `tv_global_region` VALUES ('2448', '297', '牟平区', '3');
INSERT INTO `tv_global_region` VALUES ('2449', '297', '莱山区', '3');
INSERT INTO `tv_global_region` VALUES ('2450', '297', '开发区', '3');
INSERT INTO `tv_global_region` VALUES ('2451', '297', '龙口市', '3');
INSERT INTO `tv_global_region` VALUES ('2452', '297', '莱阳市', '3');
INSERT INTO `tv_global_region` VALUES ('2453', '297', '莱州市', '3');
INSERT INTO `tv_global_region` VALUES ('2454', '297', '蓬莱市', '3');
INSERT INTO `tv_global_region` VALUES ('2455', '297', '招远市', '3');
INSERT INTO `tv_global_region` VALUES ('2456', '297', '栖霞市', '3');
INSERT INTO `tv_global_region` VALUES ('2457', '297', '海阳市', '3');
INSERT INTO `tv_global_region` VALUES ('2458', '297', '长岛县', '3');
INSERT INTO `tv_global_region` VALUES ('2459', '298', '市中区', '3');
INSERT INTO `tv_global_region` VALUES ('2460', '298', '山亭区', '3');
INSERT INTO `tv_global_region` VALUES ('2461', '298', '峄城区', '3');
INSERT INTO `tv_global_region` VALUES ('2462', '298', '台儿庄区', '3');
INSERT INTO `tv_global_region` VALUES ('2463', '298', '薛城区', '3');
INSERT INTO `tv_global_region` VALUES ('2464', '298', '滕州市', '3');
INSERT INTO `tv_global_region` VALUES ('2465', '299', '张店区', '3');
INSERT INTO `tv_global_region` VALUES ('2466', '299', '临淄区', '3');
INSERT INTO `tv_global_region` VALUES ('2467', '299', '淄川区', '3');
INSERT INTO `tv_global_region` VALUES ('2468', '299', '博山区', '3');
INSERT INTO `tv_global_region` VALUES ('2469', '299', '周村区', '3');
INSERT INTO `tv_global_region` VALUES ('2470', '299', '桓台县', '3');
INSERT INTO `tv_global_region` VALUES ('2471', '299', '高青县', '3');
INSERT INTO `tv_global_region` VALUES ('2472', '299', '沂源县', '3');
INSERT INTO `tv_global_region` VALUES ('2473', '300', '杏花岭区', '3');
INSERT INTO `tv_global_region` VALUES ('2474', '300', '小店区', '3');
INSERT INTO `tv_global_region` VALUES ('2475', '300', '迎泽区', '3');
INSERT INTO `tv_global_region` VALUES ('2476', '300', '尖草坪区', '3');
INSERT INTO `tv_global_region` VALUES ('2477', '300', '万柏林区', '3');
INSERT INTO `tv_global_region` VALUES ('2478', '300', '晋源区', '3');
INSERT INTO `tv_global_region` VALUES ('2479', '300', '高新开发区', '3');
INSERT INTO `tv_global_region` VALUES ('2480', '300', '民营经济开发区', '3');
INSERT INTO `tv_global_region` VALUES ('2481', '300', '经济技术开发区', '3');
INSERT INTO `tv_global_region` VALUES ('2482', '300', '清徐县', '3');
INSERT INTO `tv_global_region` VALUES ('2483', '300', '阳曲县', '3');
INSERT INTO `tv_global_region` VALUES ('2484', '300', '娄烦县', '3');
INSERT INTO `tv_global_region` VALUES ('2485', '300', '古交市', '3');
INSERT INTO `tv_global_region` VALUES ('2486', '301', '城区', '3');
INSERT INTO `tv_global_region` VALUES ('2487', '301', '郊区', '3');
INSERT INTO `tv_global_region` VALUES ('2488', '301', '沁县', '3');
INSERT INTO `tv_global_region` VALUES ('2489', '301', '潞城市', '3');
INSERT INTO `tv_global_region` VALUES ('2490', '301', '长治县', '3');
INSERT INTO `tv_global_region` VALUES ('2491', '301', '襄垣县', '3');
INSERT INTO `tv_global_region` VALUES ('2492', '301', '屯留县', '3');
INSERT INTO `tv_global_region` VALUES ('2493', '301', '平顺县', '3');
INSERT INTO `tv_global_region` VALUES ('2494', '301', '黎城县', '3');
INSERT INTO `tv_global_region` VALUES ('2495', '301', '壶关县', '3');
INSERT INTO `tv_global_region` VALUES ('2496', '301', '长子县', '3');
INSERT INTO `tv_global_region` VALUES ('2497', '301', '武乡县', '3');
INSERT INTO `tv_global_region` VALUES ('2498', '301', '沁源县', '3');
INSERT INTO `tv_global_region` VALUES ('2499', '302', '城区', '3');
INSERT INTO `tv_global_region` VALUES ('2500', '302', '矿区', '3');
INSERT INTO `tv_global_region` VALUES ('2501', '302', '南郊区', '3');
INSERT INTO `tv_global_region` VALUES ('2502', '302', '新荣区', '3');
INSERT INTO `tv_global_region` VALUES ('2503', '302', '阳高县', '3');
INSERT INTO `tv_global_region` VALUES ('2504', '302', '天镇县', '3');
INSERT INTO `tv_global_region` VALUES ('2505', '302', '广灵县', '3');
INSERT INTO `tv_global_region` VALUES ('2506', '302', '灵丘县', '3');
INSERT INTO `tv_global_region` VALUES ('2507', '302', '浑源县', '3');
INSERT INTO `tv_global_region` VALUES ('2508', '302', '左云县', '3');
INSERT INTO `tv_global_region` VALUES ('2509', '302', '大同县', '3');
INSERT INTO `tv_global_region` VALUES ('2510', '303', '城区', '3');
INSERT INTO `tv_global_region` VALUES ('2511', '303', '高平市', '3');
INSERT INTO `tv_global_region` VALUES ('2512', '303', '沁水县', '3');
INSERT INTO `tv_global_region` VALUES ('2513', '303', '阳城县', '3');
INSERT INTO `tv_global_region` VALUES ('2514', '303', '陵川县', '3');
INSERT INTO `tv_global_region` VALUES ('2515', '303', '泽州县', '3');
INSERT INTO `tv_global_region` VALUES ('2516', '304', '榆次区', '3');
INSERT INTO `tv_global_region` VALUES ('2517', '304', '介休市', '3');
INSERT INTO `tv_global_region` VALUES ('2518', '304', '榆社县', '3');
INSERT INTO `tv_global_region` VALUES ('2519', '304', '左权县', '3');
INSERT INTO `tv_global_region` VALUES ('2520', '304', '和顺县', '3');
INSERT INTO `tv_global_region` VALUES ('2521', '304', '昔阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2522', '304', '寿阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2523', '304', '太谷县', '3');
INSERT INTO `tv_global_region` VALUES ('2524', '304', '祁县', '3');
INSERT INTO `tv_global_region` VALUES ('2525', '304', '平遥县', '3');
INSERT INTO `tv_global_region` VALUES ('2526', '304', '灵石县', '3');
INSERT INTO `tv_global_region` VALUES ('2527', '305', '尧都区', '3');
INSERT INTO `tv_global_region` VALUES ('2528', '305', '侯马市', '3');
INSERT INTO `tv_global_region` VALUES ('2529', '305', '霍州市', '3');
INSERT INTO `tv_global_region` VALUES ('2530', '305', '曲沃县', '3');
INSERT INTO `tv_global_region` VALUES ('2531', '305', '翼城县', '3');
INSERT INTO `tv_global_region` VALUES ('2532', '305', '襄汾县', '3');
INSERT INTO `tv_global_region` VALUES ('2533', '305', '洪洞县', '3');
INSERT INTO `tv_global_region` VALUES ('2534', '305', '吉县', '3');
INSERT INTO `tv_global_region` VALUES ('2535', '305', '安泽县', '3');
INSERT INTO `tv_global_region` VALUES ('2536', '305', '浮山县', '3');
INSERT INTO `tv_global_region` VALUES ('2537', '305', '古县', '3');
INSERT INTO `tv_global_region` VALUES ('2538', '305', '乡宁县', '3');
INSERT INTO `tv_global_region` VALUES ('2539', '305', '大宁县', '3');
INSERT INTO `tv_global_region` VALUES ('2540', '305', '隰县', '3');
INSERT INTO `tv_global_region` VALUES ('2541', '305', '永和县', '3');
INSERT INTO `tv_global_region` VALUES ('2542', '305', '蒲县', '3');
INSERT INTO `tv_global_region` VALUES ('2543', '305', '汾西县', '3');
INSERT INTO `tv_global_region` VALUES ('2544', '306', '离石市', '3');
INSERT INTO `tv_global_region` VALUES ('2545', '306', '离石区', '3');
INSERT INTO `tv_global_region` VALUES ('2546', '306', '孝义市', '3');
INSERT INTO `tv_global_region` VALUES ('2547', '306', '汾阳市', '3');
INSERT INTO `tv_global_region` VALUES ('2548', '306', '文水县', '3');
INSERT INTO `tv_global_region` VALUES ('2549', '306', '交城县', '3');
INSERT INTO `tv_global_region` VALUES ('2550', '306', '兴县', '3');
INSERT INTO `tv_global_region` VALUES ('2551', '306', '临县', '3');
INSERT INTO `tv_global_region` VALUES ('2552', '306', '柳林县', '3');
INSERT INTO `tv_global_region` VALUES ('2553', '306', '石楼县', '3');
INSERT INTO `tv_global_region` VALUES ('2554', '306', '岚县', '3');
INSERT INTO `tv_global_region` VALUES ('2555', '306', '方山县', '3');
INSERT INTO `tv_global_region` VALUES ('2556', '306', '中阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2557', '306', '交口县', '3');
INSERT INTO `tv_global_region` VALUES ('2558', '307', '朔城区', '3');
INSERT INTO `tv_global_region` VALUES ('2559', '307', '平鲁区', '3');
INSERT INTO `tv_global_region` VALUES ('2560', '307', '山阴县', '3');
INSERT INTO `tv_global_region` VALUES ('2561', '307', '应县', '3');
INSERT INTO `tv_global_region` VALUES ('2562', '307', '右玉县', '3');
INSERT INTO `tv_global_region` VALUES ('2563', '307', '怀仁县', '3');
INSERT INTO `tv_global_region` VALUES ('2564', '308', '忻府区', '3');
INSERT INTO `tv_global_region` VALUES ('2565', '308', '原平市', '3');
INSERT INTO `tv_global_region` VALUES ('2566', '308', '定襄县', '3');
INSERT INTO `tv_global_region` VALUES ('2567', '308', '五台县', '3');
INSERT INTO `tv_global_region` VALUES ('2568', '308', '代县', '3');
INSERT INTO `tv_global_region` VALUES ('2569', '308', '繁峙县', '3');
INSERT INTO `tv_global_region` VALUES ('2570', '308', '宁武县', '3');
INSERT INTO `tv_global_region` VALUES ('2571', '308', '静乐县', '3');
INSERT INTO `tv_global_region` VALUES ('2572', '308', '神池县', '3');
INSERT INTO `tv_global_region` VALUES ('2573', '308', '五寨县', '3');
INSERT INTO `tv_global_region` VALUES ('2574', '308', '岢岚县', '3');
INSERT INTO `tv_global_region` VALUES ('2575', '308', '河曲县', '3');
INSERT INTO `tv_global_region` VALUES ('2576', '308', '保德县', '3');
INSERT INTO `tv_global_region` VALUES ('2577', '308', '偏关县', '3');
INSERT INTO `tv_global_region` VALUES ('2578', '309', '城区', '3');
INSERT INTO `tv_global_region` VALUES ('2579', '309', '矿区', '3');
INSERT INTO `tv_global_region` VALUES ('2580', '309', '郊区', '3');
INSERT INTO `tv_global_region` VALUES ('2581', '309', '平定县', '3');
INSERT INTO `tv_global_region` VALUES ('2582', '309', '盂县', '3');
INSERT INTO `tv_global_region` VALUES ('2583', '310', '盐湖区', '3');
INSERT INTO `tv_global_region` VALUES ('2584', '310', '永济市', '3');
INSERT INTO `tv_global_region` VALUES ('2585', '310', '河津市', '3');
INSERT INTO `tv_global_region` VALUES ('2586', '310', '临猗县', '3');
INSERT INTO `tv_global_region` VALUES ('2587', '310', '万荣县', '3');
INSERT INTO `tv_global_region` VALUES ('2588', '310', '闻喜县', '3');
INSERT INTO `tv_global_region` VALUES ('2589', '310', '稷山县', '3');
INSERT INTO `tv_global_region` VALUES ('2590', '310', '新绛县', '3');
INSERT INTO `tv_global_region` VALUES ('2591', '310', '绛县', '3');
INSERT INTO `tv_global_region` VALUES ('2592', '310', '垣曲县', '3');
INSERT INTO `tv_global_region` VALUES ('2593', '310', '夏县', '3');
INSERT INTO `tv_global_region` VALUES ('2594', '310', '平陆县', '3');
INSERT INTO `tv_global_region` VALUES ('2595', '310', '芮城县', '3');
INSERT INTO `tv_global_region` VALUES ('2596', '311', '莲湖区', '3');
INSERT INTO `tv_global_region` VALUES ('2597', '311', '新城区', '3');
INSERT INTO `tv_global_region` VALUES ('2598', '311', '碑林区', '3');
INSERT INTO `tv_global_region` VALUES ('2599', '311', '雁塔区', '3');
INSERT INTO `tv_global_region` VALUES ('2600', '311', '灞桥区', '3');
INSERT INTO `tv_global_region` VALUES ('2601', '311', '未央区', '3');
INSERT INTO `tv_global_region` VALUES ('2602', '311', '阎良区', '3');
INSERT INTO `tv_global_region` VALUES ('2603', '311', '临潼区', '3');
INSERT INTO `tv_global_region` VALUES ('2604', '311', '长安区', '3');
INSERT INTO `tv_global_region` VALUES ('2605', '311', '蓝田县', '3');
INSERT INTO `tv_global_region` VALUES ('2606', '311', '周至县', '3');
INSERT INTO `tv_global_region` VALUES ('2607', '311', '户县', '3');
INSERT INTO `tv_global_region` VALUES ('2608', '311', '高陵县', '3');
INSERT INTO `tv_global_region` VALUES ('2609', '312', '汉滨区', '3');
INSERT INTO `tv_global_region` VALUES ('2610', '312', '汉阴县', '3');
INSERT INTO `tv_global_region` VALUES ('2611', '312', '石泉县', '3');
INSERT INTO `tv_global_region` VALUES ('2612', '312', '宁陕县', '3');
INSERT INTO `tv_global_region` VALUES ('2613', '312', '紫阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2614', '312', '岚皋县', '3');
INSERT INTO `tv_global_region` VALUES ('2615', '312', '平利县', '3');
INSERT INTO `tv_global_region` VALUES ('2616', '312', '镇坪县', '3');
INSERT INTO `tv_global_region` VALUES ('2617', '312', '旬阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2618', '312', '白河县', '3');
INSERT INTO `tv_global_region` VALUES ('2619', '313', '陈仓区', '3');
INSERT INTO `tv_global_region` VALUES ('2620', '313', '渭滨区', '3');
INSERT INTO `tv_global_region` VALUES ('2621', '313', '金台区', '3');
INSERT INTO `tv_global_region` VALUES ('2622', '313', '凤翔县', '3');
INSERT INTO `tv_global_region` VALUES ('2623', '313', '岐山县', '3');
INSERT INTO `tv_global_region` VALUES ('2624', '313', '扶风县', '3');
INSERT INTO `tv_global_region` VALUES ('2625', '313', '眉县', '3');
INSERT INTO `tv_global_region` VALUES ('2626', '313', '陇县', '3');
INSERT INTO `tv_global_region` VALUES ('2627', '313', '千阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2628', '313', '麟游县', '3');
INSERT INTO `tv_global_region` VALUES ('2629', '313', '凤县', '3');
INSERT INTO `tv_global_region` VALUES ('2630', '313', '太白县', '3');
INSERT INTO `tv_global_region` VALUES ('2631', '314', '汉台区', '3');
INSERT INTO `tv_global_region` VALUES ('2632', '314', '南郑县', '3');
INSERT INTO `tv_global_region` VALUES ('2633', '314', '城固县', '3');
INSERT INTO `tv_global_region` VALUES ('2634', '314', '洋县', '3');
INSERT INTO `tv_global_region` VALUES ('2635', '314', '西乡县', '3');
INSERT INTO `tv_global_region` VALUES ('2636', '314', '勉县', '3');
INSERT INTO `tv_global_region` VALUES ('2637', '314', '宁强县', '3');
INSERT INTO `tv_global_region` VALUES ('2638', '314', '略阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2639', '314', '镇巴县', '3');
INSERT INTO `tv_global_region` VALUES ('2640', '314', '留坝县', '3');
INSERT INTO `tv_global_region` VALUES ('2641', '314', '佛坪县', '3');
INSERT INTO `tv_global_region` VALUES ('2642', '315', '商州区', '3');
INSERT INTO `tv_global_region` VALUES ('2643', '315', '洛南县', '3');
INSERT INTO `tv_global_region` VALUES ('2644', '315', '丹凤县', '3');
INSERT INTO `tv_global_region` VALUES ('2645', '315', '商南县', '3');
INSERT INTO `tv_global_region` VALUES ('2646', '315', '山阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2647', '315', '镇安县', '3');
INSERT INTO `tv_global_region` VALUES ('2648', '315', '柞水县', '3');
INSERT INTO `tv_global_region` VALUES ('2649', '316', '耀州区', '3');
INSERT INTO `tv_global_region` VALUES ('2650', '316', '王益区', '3');
INSERT INTO `tv_global_region` VALUES ('2651', '316', '印台区', '3');
INSERT INTO `tv_global_region` VALUES ('2652', '316', '宜君县', '3');
INSERT INTO `tv_global_region` VALUES ('2653', '317', '临渭区', '3');
INSERT INTO `tv_global_region` VALUES ('2654', '317', '韩城市', '3');
INSERT INTO `tv_global_region` VALUES ('2655', '317', '华阴市', '3');
INSERT INTO `tv_global_region` VALUES ('2656', '317', '华县', '3');
INSERT INTO `tv_global_region` VALUES ('2657', '317', '潼关县', '3');
INSERT INTO `tv_global_region` VALUES ('2658', '317', '大荔县', '3');
INSERT INTO `tv_global_region` VALUES ('2659', '317', '合阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2660', '317', '澄城县', '3');
INSERT INTO `tv_global_region` VALUES ('2661', '317', '蒲城县', '3');
INSERT INTO `tv_global_region` VALUES ('2662', '317', '白水县', '3');
INSERT INTO `tv_global_region` VALUES ('2663', '317', '富平县', '3');
INSERT INTO `tv_global_region` VALUES ('2664', '318', '秦都区', '3');
INSERT INTO `tv_global_region` VALUES ('2665', '318', '渭城区', '3');
INSERT INTO `tv_global_region` VALUES ('2666', '318', '杨陵区', '3');
INSERT INTO `tv_global_region` VALUES ('2667', '318', '兴平市', '3');
INSERT INTO `tv_global_region` VALUES ('2668', '318', '三原县', '3');
INSERT INTO `tv_global_region` VALUES ('2669', '318', '泾阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2670', '318', '乾县', '3');
INSERT INTO `tv_global_region` VALUES ('2671', '318', '礼泉县', '3');
INSERT INTO `tv_global_region` VALUES ('2672', '318', '永寿县', '3');
INSERT INTO `tv_global_region` VALUES ('2673', '318', '彬县', '3');
INSERT INTO `tv_global_region` VALUES ('2674', '318', '长武县', '3');
INSERT INTO `tv_global_region` VALUES ('2675', '318', '旬邑县', '3');
INSERT INTO `tv_global_region` VALUES ('2676', '318', '淳化县', '3');
INSERT INTO `tv_global_region` VALUES ('2677', '318', '武功县', '3');
INSERT INTO `tv_global_region` VALUES ('2678', '319', '吴起县', '3');
INSERT INTO `tv_global_region` VALUES ('2679', '319', '宝塔区', '3');
INSERT INTO `tv_global_region` VALUES ('2680', '319', '延长县', '3');
INSERT INTO `tv_global_region` VALUES ('2681', '319', '延川县', '3');
INSERT INTO `tv_global_region` VALUES ('2682', '319', '子长县', '3');
INSERT INTO `tv_global_region` VALUES ('2683', '319', '安塞县', '3');
INSERT INTO `tv_global_region` VALUES ('2684', '319', '志丹县', '3');
INSERT INTO `tv_global_region` VALUES ('2685', '319', '甘泉县', '3');
INSERT INTO `tv_global_region` VALUES ('2686', '319', '富县', '3');
INSERT INTO `tv_global_region` VALUES ('2687', '319', '洛川县', '3');
INSERT INTO `tv_global_region` VALUES ('2688', '319', '宜川县', '3');
INSERT INTO `tv_global_region` VALUES ('2689', '319', '黄龙县', '3');
INSERT INTO `tv_global_region` VALUES ('2690', '319', '黄陵县', '3');
INSERT INTO `tv_global_region` VALUES ('2691', '320', '榆阳区', '3');
INSERT INTO `tv_global_region` VALUES ('2692', '320', '神木县', '3');
INSERT INTO `tv_global_region` VALUES ('2693', '320', '府谷县', '3');
INSERT INTO `tv_global_region` VALUES ('2694', '320', '横山县', '3');
INSERT INTO `tv_global_region` VALUES ('2695', '320', '靖边县', '3');
INSERT INTO `tv_global_region` VALUES ('2696', '320', '定边县', '3');
INSERT INTO `tv_global_region` VALUES ('2697', '320', '绥德县', '3');
INSERT INTO `tv_global_region` VALUES ('2698', '320', '米脂县', '3');
INSERT INTO `tv_global_region` VALUES ('2699', '320', '佳县', '3');
INSERT INTO `tv_global_region` VALUES ('2700', '320', '吴堡县', '3');
INSERT INTO `tv_global_region` VALUES ('2701', '320', '清涧县', '3');
INSERT INTO `tv_global_region` VALUES ('2702', '320', '子洲县', '3');
INSERT INTO `tv_global_region` VALUES ('2703', '321', '长宁区', '3');
INSERT INTO `tv_global_region` VALUES ('2704', '321', '闸北区', '3');
INSERT INTO `tv_global_region` VALUES ('2705', '321', '闵行区', '3');
INSERT INTO `tv_global_region` VALUES ('2706', '321', '徐汇区', '3');
INSERT INTO `tv_global_region` VALUES ('2707', '321', '浦东新区', '3');
INSERT INTO `tv_global_region` VALUES ('2708', '321', '杨浦区', '3');
INSERT INTO `tv_global_region` VALUES ('2709', '321', '普陀区', '3');
INSERT INTO `tv_global_region` VALUES ('2710', '321', '静安区', '3');
INSERT INTO `tv_global_region` VALUES ('2711', '321', '卢湾区', '3');
INSERT INTO `tv_global_region` VALUES ('2712', '321', '虹口区', '3');
INSERT INTO `tv_global_region` VALUES ('2713', '321', '黄浦区', '3');
INSERT INTO `tv_global_region` VALUES ('2714', '321', '南汇区', '3');
INSERT INTO `tv_global_region` VALUES ('2715', '321', '松江区', '3');
INSERT INTO `tv_global_region` VALUES ('2716', '321', '嘉定区', '3');
INSERT INTO `tv_global_region` VALUES ('2717', '321', '宝山区', '3');
INSERT INTO `tv_global_region` VALUES ('2718', '321', '青浦区', '3');
INSERT INTO `tv_global_region` VALUES ('2719', '321', '金山区', '3');
INSERT INTO `tv_global_region` VALUES ('2720', '321', '奉贤区', '3');
INSERT INTO `tv_global_region` VALUES ('2721', '321', '崇明县', '3');
INSERT INTO `tv_global_region` VALUES ('2722', '322', '青羊区', '3');
INSERT INTO `tv_global_region` VALUES ('2723', '322', '锦江区', '3');
INSERT INTO `tv_global_region` VALUES ('2724', '322', '金牛区', '3');
INSERT INTO `tv_global_region` VALUES ('2725', '322', '武侯区', '3');
INSERT INTO `tv_global_region` VALUES ('2726', '322', '成华区', '3');
INSERT INTO `tv_global_region` VALUES ('2727', '322', '龙泉驿区', '3');
INSERT INTO `tv_global_region` VALUES ('2728', '322', '青白江区', '3');
INSERT INTO `tv_global_region` VALUES ('2729', '322', '新都区', '3');
INSERT INTO `tv_global_region` VALUES ('2730', '322', '温江区', '3');
INSERT INTO `tv_global_region` VALUES ('2731', '322', '高新区', '3');
INSERT INTO `tv_global_region` VALUES ('2732', '322', '高新西区', '3');
INSERT INTO `tv_global_region` VALUES ('2733', '322', '都江堰市', '3');
INSERT INTO `tv_global_region` VALUES ('2734', '322', '彭州市', '3');
INSERT INTO `tv_global_region` VALUES ('2735', '322', '邛崃市', '3');
INSERT INTO `tv_global_region` VALUES ('2736', '322', '崇州市', '3');
INSERT INTO `tv_global_region` VALUES ('2737', '322', '金堂县', '3');
INSERT INTO `tv_global_region` VALUES ('2738', '322', '双流县', '3');
INSERT INTO `tv_global_region` VALUES ('2739', '322', '郫县', '3');
INSERT INTO `tv_global_region` VALUES ('2740', '322', '大邑县', '3');
INSERT INTO `tv_global_region` VALUES ('2741', '322', '蒲江县', '3');
INSERT INTO `tv_global_region` VALUES ('2742', '322', '新津县', '3');
INSERT INTO `tv_global_region` VALUES ('2743', '322', '都江堰市', '3');
INSERT INTO `tv_global_region` VALUES ('2744', '322', '彭州市', '3');
INSERT INTO `tv_global_region` VALUES ('2745', '322', '邛崃市', '3');
INSERT INTO `tv_global_region` VALUES ('2746', '322', '崇州市', '3');
INSERT INTO `tv_global_region` VALUES ('2747', '322', '金堂县', '3');
INSERT INTO `tv_global_region` VALUES ('2748', '322', '双流县', '3');
INSERT INTO `tv_global_region` VALUES ('2749', '322', '郫县', '3');
INSERT INTO `tv_global_region` VALUES ('2750', '322', '大邑县', '3');
INSERT INTO `tv_global_region` VALUES ('2751', '322', '蒲江县', '3');
INSERT INTO `tv_global_region` VALUES ('2752', '322', '新津县', '3');
INSERT INTO `tv_global_region` VALUES ('2753', '323', '涪城区', '3');
INSERT INTO `tv_global_region` VALUES ('2754', '323', '游仙区', '3');
INSERT INTO `tv_global_region` VALUES ('2755', '323', '江油市', '3');
INSERT INTO `tv_global_region` VALUES ('2756', '323', '盐亭县', '3');
INSERT INTO `tv_global_region` VALUES ('2757', '323', '三台县', '3');
INSERT INTO `tv_global_region` VALUES ('2758', '323', '平武县', '3');
INSERT INTO `tv_global_region` VALUES ('2759', '323', '安县', '3');
INSERT INTO `tv_global_region` VALUES ('2760', '323', '梓潼县', '3');
INSERT INTO `tv_global_region` VALUES ('2761', '323', '北川县', '3');
INSERT INTO `tv_global_region` VALUES ('2762', '324', '马尔康县', '3');
INSERT INTO `tv_global_region` VALUES ('2763', '324', '汶川县', '3');
INSERT INTO `tv_global_region` VALUES ('2764', '324', '理县', '3');
INSERT INTO `tv_global_region` VALUES ('2765', '324', '茂县', '3');
INSERT INTO `tv_global_region` VALUES ('2766', '324', '松潘县', '3');
INSERT INTO `tv_global_region` VALUES ('2767', '324', '九寨沟县', '3');
INSERT INTO `tv_global_region` VALUES ('2768', '324', '金川县', '3');
INSERT INTO `tv_global_region` VALUES ('2769', '324', '小金县', '3');
INSERT INTO `tv_global_region` VALUES ('2770', '324', '黑水县', '3');
INSERT INTO `tv_global_region` VALUES ('2771', '324', '壤塘县', '3');
INSERT INTO `tv_global_region` VALUES ('2772', '324', '阿坝县', '3');
INSERT INTO `tv_global_region` VALUES ('2773', '324', '若尔盖县', '3');
INSERT INTO `tv_global_region` VALUES ('2774', '324', '红原县', '3');
INSERT INTO `tv_global_region` VALUES ('2775', '325', '巴州区', '3');
INSERT INTO `tv_global_region` VALUES ('2776', '325', '通江县', '3');
INSERT INTO `tv_global_region` VALUES ('2777', '325', '南江县', '3');
INSERT INTO `tv_global_region` VALUES ('2778', '325', '平昌县', '3');
INSERT INTO `tv_global_region` VALUES ('2779', '326', '通川区', '3');
INSERT INTO `tv_global_region` VALUES ('2780', '326', '万源市', '3');
INSERT INTO `tv_global_region` VALUES ('2781', '326', '达县', '3');
INSERT INTO `tv_global_region` VALUES ('2782', '326', '宣汉县', '3');
INSERT INTO `tv_global_region` VALUES ('2783', '326', '开江县', '3');
INSERT INTO `tv_global_region` VALUES ('2784', '326', '大竹县', '3');
INSERT INTO `tv_global_region` VALUES ('2785', '326', '渠县', '3');
INSERT INTO `tv_global_region` VALUES ('2786', '327', '旌阳区', '3');
INSERT INTO `tv_global_region` VALUES ('2787', '327', '广汉市', '3');
INSERT INTO `tv_global_region` VALUES ('2788', '327', '什邡市', '3');
INSERT INTO `tv_global_region` VALUES ('2789', '327', '绵竹市', '3');
INSERT INTO `tv_global_region` VALUES ('2790', '327', '罗江县', '3');
INSERT INTO `tv_global_region` VALUES ('2791', '327', '中江县', '3');
INSERT INTO `tv_global_region` VALUES ('2792', '328', '康定县', '3');
INSERT INTO `tv_global_region` VALUES ('2793', '328', '丹巴县', '3');
INSERT INTO `tv_global_region` VALUES ('2794', '328', '泸定县', '3');
INSERT INTO `tv_global_region` VALUES ('2795', '328', '炉霍县', '3');
INSERT INTO `tv_global_region` VALUES ('2796', '328', '九龙县', '3');
INSERT INTO `tv_global_region` VALUES ('2797', '328', '甘孜县', '3');
INSERT INTO `tv_global_region` VALUES ('2798', '328', '雅江县', '3');
INSERT INTO `tv_global_region` VALUES ('2799', '328', '新龙县', '3');
INSERT INTO `tv_global_region` VALUES ('2800', '328', '道孚县', '3');
INSERT INTO `tv_global_region` VALUES ('2801', '328', '白玉县', '3');
INSERT INTO `tv_global_region` VALUES ('2802', '328', '理塘县', '3');
INSERT INTO `tv_global_region` VALUES ('2803', '328', '德格县', '3');
INSERT INTO `tv_global_region` VALUES ('2804', '328', '乡城县', '3');
INSERT INTO `tv_global_region` VALUES ('2805', '328', '石渠县', '3');
INSERT INTO `tv_global_region` VALUES ('2806', '328', '稻城县', '3');
INSERT INTO `tv_global_region` VALUES ('2807', '328', '色达县', '3');
INSERT INTO `tv_global_region` VALUES ('2808', '328', '巴塘县', '3');
INSERT INTO `tv_global_region` VALUES ('2809', '328', '得荣县', '3');
INSERT INTO `tv_global_region` VALUES ('2810', '329', '广安区', '3');
INSERT INTO `tv_global_region` VALUES ('2811', '329', '华蓥市', '3');
INSERT INTO `tv_global_region` VALUES ('2812', '329', '岳池县', '3');
INSERT INTO `tv_global_region` VALUES ('2813', '329', '武胜县', '3');
INSERT INTO `tv_global_region` VALUES ('2814', '329', '邻水县', '3');
INSERT INTO `tv_global_region` VALUES ('2815', '330', '利州区', '3');
INSERT INTO `tv_global_region` VALUES ('2816', '330', '元坝区', '3');
INSERT INTO `tv_global_region` VALUES ('2817', '330', '朝天区', '3');
INSERT INTO `tv_global_region` VALUES ('2818', '330', '旺苍县', '3');
INSERT INTO `tv_global_region` VALUES ('2819', '330', '青川县', '3');
INSERT INTO `tv_global_region` VALUES ('2820', '330', '剑阁县', '3');
INSERT INTO `tv_global_region` VALUES ('2821', '330', '苍溪县', '3');
INSERT INTO `tv_global_region` VALUES ('2822', '331', '峨眉山市', '3');
INSERT INTO `tv_global_region` VALUES ('2823', '331', '乐山市', '3');
INSERT INTO `tv_global_region` VALUES ('2824', '331', '犍为县', '3');
INSERT INTO `tv_global_region` VALUES ('2825', '331', '井研县', '3');
INSERT INTO `tv_global_region` VALUES ('2826', '331', '夹江县', '3');
INSERT INTO `tv_global_region` VALUES ('2827', '331', '沐川县', '3');
INSERT INTO `tv_global_region` VALUES ('2828', '331', '峨边', '3');
INSERT INTO `tv_global_region` VALUES ('2829', '331', '马边', '3');
INSERT INTO `tv_global_region` VALUES ('2830', '332', '西昌市', '3');
INSERT INTO `tv_global_region` VALUES ('2831', '332', '盐源县', '3');
INSERT INTO `tv_global_region` VALUES ('2832', '332', '德昌县', '3');
INSERT INTO `tv_global_region` VALUES ('2833', '332', '会理县', '3');
INSERT INTO `tv_global_region` VALUES ('2834', '332', '会东县', '3');
INSERT INTO `tv_global_region` VALUES ('2835', '332', '宁南县', '3');
INSERT INTO `tv_global_region` VALUES ('2836', '332', '普格县', '3');
INSERT INTO `tv_global_region` VALUES ('2837', '332', '布拖县', '3');
INSERT INTO `tv_global_region` VALUES ('2838', '332', '金阳县', '3');
INSERT INTO `tv_global_region` VALUES ('2839', '332', '昭觉县', '3');
INSERT INTO `tv_global_region` VALUES ('2840', '332', '喜德县', '3');
INSERT INTO `tv_global_region` VALUES ('2841', '332', '冕宁县', '3');
INSERT INTO `tv_global_region` VALUES ('2842', '332', '越西县', '3');
INSERT INTO `tv_global_region` VALUES ('2843', '332', '甘洛县', '3');
INSERT INTO `tv_global_region` VALUES ('2844', '332', '美姑县', '3');
INSERT INTO `tv_global_region` VALUES ('2845', '332', '雷波县', '3');
INSERT INTO `tv_global_region` VALUES ('2846', '332', '木里', '3');
INSERT INTO `tv_global_region` VALUES ('2847', '333', '东坡区', '3');
INSERT INTO `tv_global_region` VALUES ('2848', '333', '仁寿县', '3');
INSERT INTO `tv_global_region` VALUES ('2849', '333', '彭山县', '3');
INSERT INTO `tv_global_region` VALUES ('2850', '333', '洪雅县', '3');
INSERT INTO `tv_global_region` VALUES ('2851', '333', '丹棱县', '3');
INSERT INTO `tv_global_region` VALUES ('2852', '333', '青神县', '3');
INSERT INTO `tv_global_region` VALUES ('2853', '334', '阆中市', '3');
INSERT INTO `tv_global_region` VALUES ('2854', '334', '南部县', '3');
INSERT INTO `tv_global_region` VALUES ('2855', '334', '营山县', '3');
INSERT INTO `tv_global_region` VALUES ('2856', '334', '蓬安县', '3');
INSERT INTO `tv_global_region` VALUES ('2857', '334', '仪陇县', '3');
INSERT INTO `tv_global_region` VALUES ('2858', '334', '顺庆区', '3');
INSERT INTO `tv_global_region` VALUES ('2859', '334', '高坪区', '3');
INSERT INTO `tv_global_region` VALUES ('2860', '334', '嘉陵区', '3');
INSERT INTO `tv_global_region` VALUES ('2861', '334', '西充县', '3');
INSERT INTO `tv_global_region` VALUES ('2862', '335', '市中区', '3');
INSERT INTO `tv_global_region` VALUES ('2863', '335', '东兴区', '3');
INSERT INTO `tv_global_region` VALUES ('2864', '335', '威远县', '3');
INSERT INTO `tv_global_region` VALUES ('2865', '335', '资中县', '3');
INSERT INTO `tv_global_region` VALUES ('2866', '335', '隆昌县', '3');
INSERT INTO `tv_global_region` VALUES ('2867', '336', '东  区', '3');
INSERT INTO `tv_global_region` VALUES ('2868', '336', '西  区', '3');
INSERT INTO `tv_global_region` VALUES ('2869', '336', '仁和区', '3');
INSERT INTO `tv_global_region` VALUES ('2870', '336', '米易县', '3');
INSERT INTO `tv_global_region` VALUES ('2871', '336', '盐边县', '3');
INSERT INTO `tv_global_region` VALUES ('2872', '337', '船山区', '3');
INSERT INTO `tv_global_region` VALUES ('2873', '337', '安居区', '3');
INSERT INTO `tv_global_region` VALUES ('2874', '337', '蓬溪县', '3');
INSERT INTO `tv_global_region` VALUES ('2875', '337', '射洪县', '3');
INSERT INTO `tv_global_region` VALUES ('2876', '337', '大英县', '3');
INSERT INTO `tv_global_region` VALUES ('2877', '338', '雨城区', '3');
INSERT INTO `tv_global_region` VALUES ('2878', '338', '名山县', '3');
INSERT INTO `tv_global_region` VALUES ('2879', '338', '荥经县', '3');
INSERT INTO `tv_global_region` VALUES ('2880', '338', '汉源县', '3');
INSERT INTO `tv_global_region` VALUES ('2881', '338', '石棉县', '3');
INSERT INTO `tv_global_region` VALUES ('2882', '338', '天全县', '3');
INSERT INTO `tv_global_region` VALUES ('2883', '338', '芦山县', '3');
INSERT INTO `tv_global_region` VALUES ('2884', '338', '宝兴县', '3');
INSERT INTO `tv_global_region` VALUES ('2885', '339', '翠屏区', '3');
INSERT INTO `tv_global_region` VALUES ('2886', '339', '宜宾县', '3');
INSERT INTO `tv_global_region` VALUES ('2887', '339', '南溪县', '3');
INSERT INTO `tv_global_region` VALUES ('2888', '339', '江安县', '3');
INSERT INTO `tv_global_region` VALUES ('2889', '339', '长宁县', '3');
INSERT INTO `tv_global_region` VALUES ('2890', '339', '高县', '3');
INSERT INTO `tv_global_region` VALUES ('2891', '339', '珙县', '3');
INSERT INTO `tv_global_region` VALUES ('2892', '339', '筠连县', '3');
INSERT INTO `tv_global_region` VALUES ('2893', '339', '兴文县', '3');
INSERT INTO `tv_global_region` VALUES ('2894', '339', '屏山县', '3');
INSERT INTO `tv_global_region` VALUES ('2895', '340', '雁江区', '3');
INSERT INTO `tv_global_region` VALUES ('2896', '340', '简阳市', '3');
INSERT INTO `tv_global_region` VALUES ('2897', '340', '安岳县', '3');
INSERT INTO `tv_global_region` VALUES ('2898', '340', '乐至县', '3');
INSERT INTO `tv_global_region` VALUES ('2899', '341', '大安区', '3');
INSERT INTO `tv_global_region` VALUES ('2900', '341', '自流井区', '3');
INSERT INTO `tv_global_region` VALUES ('2901', '341', '贡井区', '3');
INSERT INTO `tv_global_region` VALUES ('2902', '341', '沿滩区', '3');
INSERT INTO `tv_global_region` VALUES ('2903', '341', '荣县', '3');
INSERT INTO `tv_global_region` VALUES ('2904', '341', '富顺县', '3');
INSERT INTO `tv_global_region` VALUES ('2905', '342', '江阳区', '3');
INSERT INTO `tv_global_region` VALUES ('2906', '342', '纳溪区', '3');
INSERT INTO `tv_global_region` VALUES ('2907', '342', '龙马潭区', '3');
INSERT INTO `tv_global_region` VALUES ('2908', '342', '泸县', '3');
INSERT INTO `tv_global_region` VALUES ('2909', '342', '合江县', '3');
INSERT INTO `tv_global_region` VALUES ('2910', '342', '叙永县', '3');
INSERT INTO `tv_global_region` VALUES ('2911', '342', '古蔺县', '3');
INSERT INTO `tv_global_region` VALUES ('2912', '343', '和平区', '3');
INSERT INTO `tv_global_region` VALUES ('2913', '343', '河西区', '3');
INSERT INTO `tv_global_region` VALUES ('2914', '343', '南开区', '3');
INSERT INTO `tv_global_region` VALUES ('2915', '343', '河北区', '3');
INSERT INTO `tv_global_region` VALUES ('2916', '343', '河东区', '3');
INSERT INTO `tv_global_region` VALUES ('2917', '343', '红桥区', '3');
INSERT INTO `tv_global_region` VALUES ('2918', '343', '东丽区', '3');
INSERT INTO `tv_global_region` VALUES ('2919', '343', '津南区', '3');
INSERT INTO `tv_global_region` VALUES ('2920', '343', '西青区', '3');
INSERT INTO `tv_global_region` VALUES ('2921', '343', '北辰区', '3');
INSERT INTO `tv_global_region` VALUES ('2922', '343', '塘沽区', '3');
INSERT INTO `tv_global_region` VALUES ('2923', '343', '汉沽区', '3');
INSERT INTO `tv_global_region` VALUES ('2924', '343', '大港区', '3');
INSERT INTO `tv_global_region` VALUES ('2925', '343', '武清区', '3');
INSERT INTO `tv_global_region` VALUES ('2926', '343', '宝坻区', '3');
INSERT INTO `tv_global_region` VALUES ('2927', '343', '经济开发区', '3');
INSERT INTO `tv_global_region` VALUES ('2928', '343', '宁河县', '3');
INSERT INTO `tv_global_region` VALUES ('2929', '343', '静海县', '3');
INSERT INTO `tv_global_region` VALUES ('2930', '343', '蓟县', '3');
INSERT INTO `tv_global_region` VALUES ('2931', '344', '城关区', '3');
INSERT INTO `tv_global_region` VALUES ('2932', '344', '林周县', '3');
INSERT INTO `tv_global_region` VALUES ('2933', '344', '当雄县', '3');
INSERT INTO `tv_global_region` VALUES ('2934', '344', '尼木县', '3');
INSERT INTO `tv_global_region` VALUES ('2935', '344', '曲水县', '3');
INSERT INTO `tv_global_region` VALUES ('2936', '344', '堆龙德庆县', '3');
INSERT INTO `tv_global_region` VALUES ('2937', '344', '达孜县', '3');
INSERT INTO `tv_global_region` VALUES ('2938', '344', '墨竹工卡县', '3');
INSERT INTO `tv_global_region` VALUES ('2939', '345', '噶尔县', '3');
INSERT INTO `tv_global_region` VALUES ('2940', '345', '普兰县', '3');
INSERT INTO `tv_global_region` VALUES ('2941', '345', '札达县', '3');
INSERT INTO `tv_global_region` VALUES ('2942', '345', '日土县', '3');
INSERT INTO `tv_global_region` VALUES ('2943', '345', '革吉县', '3');
INSERT INTO `tv_global_region` VALUES ('2944', '345', '改则县', '3');
INSERT INTO `tv_global_region` VALUES ('2945', '345', '措勤县', '3');
INSERT INTO `tv_global_region` VALUES ('2946', '346', '昌都县', '3');
INSERT INTO `tv_global_region` VALUES ('2947', '346', '江达县', '3');
INSERT INTO `tv_global_region` VALUES ('2948', '346', '贡觉县', '3');
INSERT INTO `tv_global_region` VALUES ('2949', '346', '类乌齐县', '3');
INSERT INTO `tv_global_region` VALUES ('2950', '346', '丁青县', '3');
INSERT INTO `tv_global_region` VALUES ('2951', '346', '察雅县', '3');
INSERT INTO `tv_global_region` VALUES ('2952', '346', '八宿县', '3');
INSERT INTO `tv_global_region` VALUES ('2953', '346', '左贡县', '3');
INSERT INTO `tv_global_region` VALUES ('2954', '346', '芒康县', '3');
INSERT INTO `tv_global_region` VALUES ('2955', '346', '洛隆县', '3');
INSERT INTO `tv_global_region` VALUES ('2956', '346', '边坝县', '3');
INSERT INTO `tv_global_region` VALUES ('2957', '347', '林芝县', '3');
INSERT INTO `tv_global_region` VALUES ('2958', '347', '工布江达县', '3');
INSERT INTO `tv_global_region` VALUES ('2959', '347', '米林县', '3');
INSERT INTO `tv_global_region` VALUES ('2960', '347', '墨脱县', '3');
INSERT INTO `tv_global_region` VALUES ('2961', '347', '波密县', '3');
INSERT INTO `tv_global_region` VALUES ('2962', '347', '察隅县', '3');
INSERT INTO `tv_global_region` VALUES ('2963', '347', '朗县', '3');
INSERT INTO `tv_global_region` VALUES ('2964', '348', '那曲县', '3');
INSERT INTO `tv_global_region` VALUES ('2965', '348', '嘉黎县', '3');
INSERT INTO `tv_global_region` VALUES ('2966', '348', '比如县', '3');
INSERT INTO `tv_global_region` VALUES ('2967', '348', '聂荣县', '3');
INSERT INTO `tv_global_region` VALUES ('2968', '348', '安多县', '3');
INSERT INTO `tv_global_region` VALUES ('2969', '348', '申扎县', '3');
INSERT INTO `tv_global_region` VALUES ('2970', '348', '索县', '3');
INSERT INTO `tv_global_region` VALUES ('2971', '348', '班戈县', '3');
INSERT INTO `tv_global_region` VALUES ('2972', '348', '巴青县', '3');
INSERT INTO `tv_global_region` VALUES ('2973', '348', '尼玛县', '3');
INSERT INTO `tv_global_region` VALUES ('2974', '349', '日喀则市', '3');
INSERT INTO `tv_global_region` VALUES ('2975', '349', '南木林县', '3');
INSERT INTO `tv_global_region` VALUES ('2976', '349', '江孜县', '3');
INSERT INTO `tv_global_region` VALUES ('2977', '349', '定日县', '3');
INSERT INTO `tv_global_region` VALUES ('2978', '349', '萨迦县', '3');
INSERT INTO `tv_global_region` VALUES ('2979', '349', '拉孜县', '3');
INSERT INTO `tv_global_region` VALUES ('2980', '349', '昂仁县', '3');
INSERT INTO `tv_global_region` VALUES ('2981', '349', '谢通门县', '3');
INSERT INTO `tv_global_region` VALUES ('2982', '349', '白朗县', '3');
INSERT INTO `tv_global_region` VALUES ('2983', '349', '仁布县', '3');
INSERT INTO `tv_global_region` VALUES ('2984', '349', '康马县', '3');
INSERT INTO `tv_global_region` VALUES ('2985', '349', '定结县', '3');
INSERT INTO `tv_global_region` VALUES ('2986', '349', '仲巴县', '3');
INSERT INTO `tv_global_region` VALUES ('2987', '349', '亚东县', '3');
INSERT INTO `tv_global_region` VALUES ('2988', '349', '吉隆县', '3');
INSERT INTO `tv_global_region` VALUES ('2989', '349', '聂拉木县', '3');
INSERT INTO `tv_global_region` VALUES ('2990', '349', '萨嘎县', '3');
INSERT INTO `tv_global_region` VALUES ('2991', '349', '岗巴县', '3');
INSERT INTO `tv_global_region` VALUES ('2992', '350', '乃东县', '3');
INSERT INTO `tv_global_region` VALUES ('2993', '350', '扎囊县', '3');
INSERT INTO `tv_global_region` VALUES ('2994', '350', '贡嘎县', '3');
INSERT INTO `tv_global_region` VALUES ('2995', '350', '桑日县', '3');
INSERT INTO `tv_global_region` VALUES ('2996', '350', '琼结县', '3');
INSERT INTO `tv_global_region` VALUES ('2997', '350', '曲松县', '3');
INSERT INTO `tv_global_region` VALUES ('2998', '350', '措美县', '3');
INSERT INTO `tv_global_region` VALUES ('2999', '350', '洛扎县', '3');
INSERT INTO `tv_global_region` VALUES ('3000', '350', '加查县', '3');
INSERT INTO `tv_global_region` VALUES ('3001', '350', '隆子县', '3');
INSERT INTO `tv_global_region` VALUES ('3002', '350', '错那县', '3');
INSERT INTO `tv_global_region` VALUES ('3003', '350', '浪卡子县', '3');
INSERT INTO `tv_global_region` VALUES ('3004', '351', '天山区', '3');
INSERT INTO `tv_global_region` VALUES ('3005', '351', '沙依巴克区', '3');
INSERT INTO `tv_global_region` VALUES ('3006', '351', '新市区', '3');
INSERT INTO `tv_global_region` VALUES ('3007', '351', '水磨沟区', '3');
INSERT INTO `tv_global_region` VALUES ('3008', '351', '头屯河区', '3');
INSERT INTO `tv_global_region` VALUES ('3009', '351', '达坂城区', '3');
INSERT INTO `tv_global_region` VALUES ('3010', '351', '米东区', '3');
INSERT INTO `tv_global_region` VALUES ('3011', '351', '乌鲁木齐县', '3');
INSERT INTO `tv_global_region` VALUES ('3012', '352', '阿克苏市', '3');
INSERT INTO `tv_global_region` VALUES ('3013', '352', '温宿县', '3');
INSERT INTO `tv_global_region` VALUES ('3014', '352', '库车县', '3');
INSERT INTO `tv_global_region` VALUES ('3015', '352', '沙雅县', '3');
INSERT INTO `tv_global_region` VALUES ('3016', '352', '新和县', '3');
INSERT INTO `tv_global_region` VALUES ('3017', '352', '拜城县', '3');
INSERT INTO `tv_global_region` VALUES ('3018', '352', '乌什县', '3');
INSERT INTO `tv_global_region` VALUES ('3019', '352', '阿瓦提县', '3');
INSERT INTO `tv_global_region` VALUES ('3020', '352', '柯坪县', '3');
INSERT INTO `tv_global_region` VALUES ('3021', '353', '阿拉尔市', '3');
INSERT INTO `tv_global_region` VALUES ('3022', '354', '库尔勒市', '3');
INSERT INTO `tv_global_region` VALUES ('3023', '354', '轮台县', '3');
INSERT INTO `tv_global_region` VALUES ('3024', '354', '尉犁县', '3');
INSERT INTO `tv_global_region` VALUES ('3025', '354', '若羌县', '3');
INSERT INTO `tv_global_region` VALUES ('3026', '354', '且末县', '3');
INSERT INTO `tv_global_region` VALUES ('3027', '354', '焉耆', '3');
INSERT INTO `tv_global_region` VALUES ('3028', '354', '和静县', '3');
INSERT INTO `tv_global_region` VALUES ('3029', '354', '和硕县', '3');
INSERT INTO `tv_global_region` VALUES ('3030', '354', '博湖县', '3');
INSERT INTO `tv_global_region` VALUES ('3031', '355', '博乐市', '3');
INSERT INTO `tv_global_region` VALUES ('3032', '355', '精河县', '3');
INSERT INTO `tv_global_region` VALUES ('3033', '355', '温泉县', '3');
INSERT INTO `tv_global_region` VALUES ('3034', '356', '呼图壁县', '3');
INSERT INTO `tv_global_region` VALUES ('3035', '356', '米泉市', '3');
INSERT INTO `tv_global_region` VALUES ('3036', '356', '昌吉市', '3');
INSERT INTO `tv_global_region` VALUES ('3037', '356', '阜康市', '3');
INSERT INTO `tv_global_region` VALUES ('3038', '356', '玛纳斯县', '3');
INSERT INTO `tv_global_region` VALUES ('3039', '356', '奇台县', '3');
INSERT INTO `tv_global_region` VALUES ('3040', '356', '吉木萨尔县', '3');
INSERT INTO `tv_global_region` VALUES ('3041', '356', '木垒', '3');
INSERT INTO `tv_global_region` VALUES ('3042', '357', '哈密市', '3');
INSERT INTO `tv_global_region` VALUES ('3043', '357', '伊吾县', '3');
INSERT INTO `tv_global_region` VALUES ('3044', '357', '巴里坤', '3');
INSERT INTO `tv_global_region` VALUES ('3045', '358', '和田市', '3');
INSERT INTO `tv_global_region` VALUES ('3046', '358', '和田县', '3');
INSERT INTO `tv_global_region` VALUES ('3047', '358', '墨玉县', '3');
INSERT INTO `tv_global_region` VALUES ('3048', '358', '皮山县', '3');
INSERT INTO `tv_global_region` VALUES ('3049', '358', '洛浦县', '3');
INSERT INTO `tv_global_region` VALUES ('3050', '358', '策勒县', '3');
INSERT INTO `tv_global_region` VALUES ('3051', '358', '于田县', '3');
INSERT INTO `tv_global_region` VALUES ('3052', '358', '民丰县', '3');
INSERT INTO `tv_global_region` VALUES ('3053', '359', '喀什市', '3');
INSERT INTO `tv_global_region` VALUES ('3054', '359', '疏附县', '3');
INSERT INTO `tv_global_region` VALUES ('3055', '359', '疏勒县', '3');
INSERT INTO `tv_global_region` VALUES ('3056', '359', '英吉沙县', '3');
INSERT INTO `tv_global_region` VALUES ('3057', '359', '泽普县', '3');
INSERT INTO `tv_global_region` VALUES ('3058', '359', '莎车县', '3');
INSERT INTO `tv_global_region` VALUES ('3059', '359', '叶城县', '3');
INSERT INTO `tv_global_region` VALUES ('3060', '359', '麦盖提县', '3');
INSERT INTO `tv_global_region` VALUES ('3061', '359', '岳普湖县', '3');
INSERT INTO `tv_global_region` VALUES ('3062', '359', '伽师县', '3');
INSERT INTO `tv_global_region` VALUES ('3063', '359', '巴楚县', '3');
INSERT INTO `tv_global_region` VALUES ('3064', '359', '塔什库尔干', '3');
INSERT INTO `tv_global_region` VALUES ('3065', '360', '克拉玛依市', '3');
INSERT INTO `tv_global_region` VALUES ('3066', '361', '阿图什市', '3');
INSERT INTO `tv_global_region` VALUES ('3067', '361', '阿克陶县', '3');
INSERT INTO `tv_global_region` VALUES ('3068', '361', '阿合奇县', '3');
INSERT INTO `tv_global_region` VALUES ('3069', '361', '乌恰县', '3');
INSERT INTO `tv_global_region` VALUES ('3070', '362', '石河子市', '3');
INSERT INTO `tv_global_region` VALUES ('3071', '363', '图木舒克市', '3');
INSERT INTO `tv_global_region` VALUES ('3072', '364', '吐鲁番市', '3');
INSERT INTO `tv_global_region` VALUES ('3073', '364', '鄯善县', '3');
INSERT INTO `tv_global_region` VALUES ('3074', '364', '托克逊县', '3');
INSERT INTO `tv_global_region` VALUES ('3075', '365', '五家渠市', '3');
INSERT INTO `tv_global_region` VALUES ('3076', '366', '阿勒泰市', '3');
INSERT INTO `tv_global_region` VALUES ('3077', '366', '布克赛尔', '3');
INSERT INTO `tv_global_region` VALUES ('3078', '366', '伊宁市', '3');
INSERT INTO `tv_global_region` VALUES ('3079', '366', '布尔津县', '3');
INSERT INTO `tv_global_region` VALUES ('3080', '366', '奎屯市', '3');
INSERT INTO `tv_global_region` VALUES ('3081', '366', '乌苏市', '3');
INSERT INTO `tv_global_region` VALUES ('3082', '366', '额敏县', '3');
INSERT INTO `tv_global_region` VALUES ('3083', '366', '富蕴县', '3');
INSERT INTO `tv_global_region` VALUES ('3084', '366', '伊宁县', '3');
INSERT INTO `tv_global_region` VALUES ('3085', '366', '福海县', '3');
INSERT INTO `tv_global_region` VALUES ('3086', '366', '霍城县', '3');
INSERT INTO `tv_global_region` VALUES ('3087', '366', '沙湾县', '3');
INSERT INTO `tv_global_region` VALUES ('3088', '366', '巩留县', '3');
INSERT INTO `tv_global_region` VALUES ('3089', '366', '哈巴河县', '3');
INSERT INTO `tv_global_region` VALUES ('3090', '366', '托里县', '3');
INSERT INTO `tv_global_region` VALUES ('3091', '366', '青河县', '3');
INSERT INTO `tv_global_region` VALUES ('3092', '366', '新源县', '3');
INSERT INTO `tv_global_region` VALUES ('3093', '366', '裕民县', '3');
INSERT INTO `tv_global_region` VALUES ('3094', '366', '和布克赛尔', '3');
INSERT INTO `tv_global_region` VALUES ('3095', '366', '吉木乃县', '3');
INSERT INTO `tv_global_region` VALUES ('3096', '366', '昭苏县', '3');
INSERT INTO `tv_global_region` VALUES ('3097', '366', '特克斯县', '3');
INSERT INTO `tv_global_region` VALUES ('3098', '366', '尼勒克县', '3');
INSERT INTO `tv_global_region` VALUES ('3099', '366', '察布查尔', '3');
INSERT INTO `tv_global_region` VALUES ('3100', '367', '盘龙区', '3');
INSERT INTO `tv_global_region` VALUES ('3101', '367', '五华区', '3');
INSERT INTO `tv_global_region` VALUES ('3102', '367', '官渡区', '3');
INSERT INTO `tv_global_region` VALUES ('3103', '367', '西山区', '3');
INSERT INTO `tv_global_region` VALUES ('3104', '367', '东川区', '3');
INSERT INTO `tv_global_region` VALUES ('3105', '367', '安宁市', '3');
INSERT INTO `tv_global_region` VALUES ('3106', '367', '呈贡县', '3');
INSERT INTO `tv_global_region` VALUES ('3107', '367', '晋宁县', '3');
INSERT INTO `tv_global_region` VALUES ('3108', '367', '富民县', '3');
INSERT INTO `tv_global_region` VALUES ('3109', '367', '宜良县', '3');
INSERT INTO `tv_global_region` VALUES ('3110', '367', '嵩明县', '3');
INSERT INTO `tv_global_region` VALUES ('3111', '367', '石林县', '3');
INSERT INTO `tv_global_region` VALUES ('3112', '367', '禄劝', '3');
INSERT INTO `tv_global_region` VALUES ('3113', '367', '寻甸', '3');
INSERT INTO `tv_global_region` VALUES ('3114', '368', '兰坪', '3');
INSERT INTO `tv_global_region` VALUES ('3115', '368', '泸水县', '3');
INSERT INTO `tv_global_region` VALUES ('3116', '368', '福贡县', '3');
INSERT INTO `tv_global_region` VALUES ('3117', '368', '贡山', '3');
INSERT INTO `tv_global_region` VALUES ('3118', '369', '宁洱', '3');
INSERT INTO `tv_global_region` VALUES ('3119', '369', '思茅区', '3');
INSERT INTO `tv_global_region` VALUES ('3120', '369', '墨江', '3');
INSERT INTO `tv_global_region` VALUES ('3121', '369', '景东', '3');
INSERT INTO `tv_global_region` VALUES ('3122', '369', '景谷', '3');
INSERT INTO `tv_global_region` VALUES ('3123', '369', '镇沅', '3');
INSERT INTO `tv_global_region` VALUES ('3124', '369', '江城', '3');
INSERT INTO `tv_global_region` VALUES ('3125', '369', '孟连', '3');
INSERT INTO `tv_global_region` VALUES ('3126', '369', '澜沧', '3');
INSERT INTO `tv_global_region` VALUES ('3127', '369', '西盟', '3');
INSERT INTO `tv_global_region` VALUES ('3128', '370', '古城区', '3');
INSERT INTO `tv_global_region` VALUES ('3129', '370', '宁蒗', '3');
INSERT INTO `tv_global_region` VALUES ('3130', '370', '玉龙', '3');
INSERT INTO `tv_global_region` VALUES ('3131', '370', '永胜县', '3');
INSERT INTO `tv_global_region` VALUES ('3132', '370', '华坪县', '3');
INSERT INTO `tv_global_region` VALUES ('3133', '371', '隆阳区', '3');
INSERT INTO `tv_global_region` VALUES ('3134', '371', '施甸县', '3');
INSERT INTO `tv_global_region` VALUES ('3135', '371', '腾冲县', '3');
INSERT INTO `tv_global_region` VALUES ('3136', '371', '龙陵县', '3');
INSERT INTO `tv_global_region` VALUES ('3137', '371', '昌宁县', '3');
INSERT INTO `tv_global_region` VALUES ('3138', '372', '楚雄市', '3');
INSERT INTO `tv_global_region` VALUES ('3139', '372', '双柏县', '3');
INSERT INTO `tv_global_region` VALUES ('3140', '372', '牟定县', '3');
INSERT INTO `tv_global_region` VALUES ('3141', '372', '南华县', '3');
INSERT INTO `tv_global_region` VALUES ('3142', '372', '姚安县', '3');
INSERT INTO `tv_global_region` VALUES ('3143', '372', '大姚县', '3');
INSERT INTO `tv_global_region` VALUES ('3144', '372', '永仁县', '3');
INSERT INTO `tv_global_region` VALUES ('3145', '372', '元谋县', '3');
INSERT INTO `tv_global_region` VALUES ('3146', '372', '武定县', '3');
INSERT INTO `tv_global_region` VALUES ('3147', '372', '禄丰县', '3');
INSERT INTO `tv_global_region` VALUES ('3148', '373', '大理市', '3');
INSERT INTO `tv_global_region` VALUES ('3149', '373', '祥云县', '3');
INSERT INTO `tv_global_region` VALUES ('3150', '373', '宾川县', '3');
INSERT INTO `tv_global_region` VALUES ('3151', '373', '弥渡县', '3');
INSERT INTO `tv_global_region` VALUES ('3152', '373', '永平县', '3');
INSERT INTO `tv_global_region` VALUES ('3153', '373', '云龙县', '3');
INSERT INTO `tv_global_region` VALUES ('3154', '373', '洱源县', '3');
INSERT INTO `tv_global_region` VALUES ('3155', '373', '剑川县', '3');
INSERT INTO `tv_global_region` VALUES ('3156', '373', '鹤庆县', '3');
INSERT INTO `tv_global_region` VALUES ('3157', '373', '漾濞', '3');
INSERT INTO `tv_global_region` VALUES ('3158', '373', '南涧', '3');
INSERT INTO `tv_global_region` VALUES ('3159', '373', '巍山', '3');
INSERT INTO `tv_global_region` VALUES ('3160', '374', '潞西市', '3');
INSERT INTO `tv_global_region` VALUES ('3161', '374', '瑞丽市', '3');
INSERT INTO `tv_global_region` VALUES ('3162', '374', '梁河县', '3');
INSERT INTO `tv_global_region` VALUES ('3163', '374', '盈江县', '3');
INSERT INTO `tv_global_region` VALUES ('3164', '374', '陇川县', '3');
INSERT INTO `tv_global_region` VALUES ('3165', '375', '香格里拉县', '3');
INSERT INTO `tv_global_region` VALUES ('3166', '375', '德钦县', '3');
INSERT INTO `tv_global_region` VALUES ('3167', '375', '维西', '3');
INSERT INTO `tv_global_region` VALUES ('3168', '376', '泸西县', '3');
INSERT INTO `tv_global_region` VALUES ('3169', '376', '蒙自县', '3');
INSERT INTO `tv_global_region` VALUES ('3170', '376', '个旧市', '3');
INSERT INTO `tv_global_region` VALUES ('3171', '376', '开远市', '3');
INSERT INTO `tv_global_region` VALUES ('3172', '376', '绿春县', '3');
INSERT INTO `tv_global_region` VALUES ('3173', '376', '建水县', '3');
INSERT INTO `tv_global_region` VALUES ('3174', '376', '石屏县', '3');
INSERT INTO `tv_global_region` VALUES ('3175', '376', '弥勒县', '3');
INSERT INTO `tv_global_region` VALUES ('3176', '376', '元阳县', '3');
INSERT INTO `tv_global_region` VALUES ('3177', '376', '红河县', '3');
INSERT INTO `tv_global_region` VALUES ('3178', '376', '金平', '3');
INSERT INTO `tv_global_region` VALUES ('3179', '376', '河口', '3');
INSERT INTO `tv_global_region` VALUES ('3180', '376', '屏边', '3');
INSERT INTO `tv_global_region` VALUES ('3181', '377', '临翔区', '3');
INSERT INTO `tv_global_region` VALUES ('3182', '377', '凤庆县', '3');
INSERT INTO `tv_global_region` VALUES ('3183', '377', '云县', '3');
INSERT INTO `tv_global_region` VALUES ('3184', '377', '永德县', '3');
INSERT INTO `tv_global_region` VALUES ('3185', '377', '镇康县', '3');
INSERT INTO `tv_global_region` VALUES ('3186', '377', '双江', '3');
INSERT INTO `tv_global_region` VALUES ('3187', '377', '耿马', '3');
INSERT INTO `tv_global_region` VALUES ('3188', '377', '沧源', '3');
INSERT INTO `tv_global_region` VALUES ('3189', '378', '麒麟区', '3');
INSERT INTO `tv_global_region` VALUES ('3190', '378', '宣威市', '3');
INSERT INTO `tv_global_region` VALUES ('3191', '378', '马龙县', '3');
INSERT INTO `tv_global_region` VALUES ('3192', '378', '陆良县', '3');
INSERT INTO `tv_global_region` VALUES ('3193', '378', '师宗县', '3');
INSERT INTO `tv_global_region` VALUES ('3194', '378', '罗平县', '3');
INSERT INTO `tv_global_region` VALUES ('3195', '378', '富源县', '3');
INSERT INTO `tv_global_region` VALUES ('3196', '378', '会泽县', '3');
INSERT INTO `tv_global_region` VALUES ('3197', '378', '沾益县', '3');
INSERT INTO `tv_global_region` VALUES ('3198', '379', '文山县', '3');
INSERT INTO `tv_global_region` VALUES ('3199', '379', '砚山县', '3');
INSERT INTO `tv_global_region` VALUES ('3200', '379', '西畴县', '3');
INSERT INTO `tv_global_region` VALUES ('3201', '379', '麻栗坡县', '3');
INSERT INTO `tv_global_region` VALUES ('3202', '379', '马关县', '3');
INSERT INTO `tv_global_region` VALUES ('3203', '379', '丘北县', '3');
INSERT INTO `tv_global_region` VALUES ('3204', '379', '广南县', '3');
INSERT INTO `tv_global_region` VALUES ('3205', '379', '富宁县', '3');
INSERT INTO `tv_global_region` VALUES ('3206', '380', '景洪市', '3');
INSERT INTO `tv_global_region` VALUES ('3207', '380', '勐海县', '3');
INSERT INTO `tv_global_region` VALUES ('3208', '380', '勐腊县', '3');
INSERT INTO `tv_global_region` VALUES ('3209', '381', '红塔区', '3');
INSERT INTO `tv_global_region` VALUES ('3210', '381', '江川县', '3');
INSERT INTO `tv_global_region` VALUES ('3211', '381', '澄江县', '3');
INSERT INTO `tv_global_region` VALUES ('3212', '381', '通海县', '3');
INSERT INTO `tv_global_region` VALUES ('3213', '381', '华宁县', '3');
INSERT INTO `tv_global_region` VALUES ('3214', '381', '易门县', '3');
INSERT INTO `tv_global_region` VALUES ('3215', '381', '峨山', '3');
INSERT INTO `tv_global_region` VALUES ('3216', '381', '新平', '3');
INSERT INTO `tv_global_region` VALUES ('3217', '381', '元江', '3');
INSERT INTO `tv_global_region` VALUES ('3218', '382', '昭阳区', '3');
INSERT INTO `tv_global_region` VALUES ('3219', '382', '鲁甸县', '3');
INSERT INTO `tv_global_region` VALUES ('3220', '382', '巧家县', '3');
INSERT INTO `tv_global_region` VALUES ('3221', '382', '盐津县', '3');
INSERT INTO `tv_global_region` VALUES ('3222', '382', '大关县', '3');
INSERT INTO `tv_global_region` VALUES ('3223', '382', '永善县', '3');
INSERT INTO `tv_global_region` VALUES ('3224', '382', '绥江县', '3');
INSERT INTO `tv_global_region` VALUES ('3225', '382', '镇雄县', '3');
INSERT INTO `tv_global_region` VALUES ('3226', '382', '彝良县', '3');
INSERT INTO `tv_global_region` VALUES ('3227', '382', '威信县', '3');
INSERT INTO `tv_global_region` VALUES ('3228', '382', '水富县', '3');
INSERT INTO `tv_global_region` VALUES ('3229', '383', '西湖区', '3');
INSERT INTO `tv_global_region` VALUES ('3230', '383', '上城区', '3');
INSERT INTO `tv_global_region` VALUES ('3231', '383', '下城区', '3');
INSERT INTO `tv_global_region` VALUES ('3232', '383', '拱墅区', '3');
INSERT INTO `tv_global_region` VALUES ('3233', '383', '滨江区', '3');
INSERT INTO `tv_global_region` VALUES ('3234', '383', '江干区', '3');
INSERT INTO `tv_global_region` VALUES ('3235', '383', '萧山区', '3');
INSERT INTO `tv_global_region` VALUES ('3236', '383', '余杭区', '3');
INSERT INTO `tv_global_region` VALUES ('3237', '383', '市郊', '3');
INSERT INTO `tv_global_region` VALUES ('3238', '383', '建德市', '3');
INSERT INTO `tv_global_region` VALUES ('3239', '383', '富阳市', '3');
INSERT INTO `tv_global_region` VALUES ('3240', '383', '临安市', '3');
INSERT INTO `tv_global_region` VALUES ('3241', '383', '桐庐县', '3');
INSERT INTO `tv_global_region` VALUES ('3242', '383', '淳安县', '3');
INSERT INTO `tv_global_region` VALUES ('3243', '384', '吴兴区', '3');
INSERT INTO `tv_global_region` VALUES ('3244', '384', '南浔区', '3');
INSERT INTO `tv_global_region` VALUES ('3245', '384', '德清县', '3');
INSERT INTO `tv_global_region` VALUES ('3246', '384', '长兴县', '3');
INSERT INTO `tv_global_region` VALUES ('3247', '384', '安吉县', '3');
INSERT INTO `tv_global_region` VALUES ('3248', '385', '南湖区', '3');
INSERT INTO `tv_global_region` VALUES ('3249', '385', '秀洲区', '3');
INSERT INTO `tv_global_region` VALUES ('3250', '385', '海宁市', '3');
INSERT INTO `tv_global_region` VALUES ('3251', '385', '嘉善县', '3');
INSERT INTO `tv_global_region` VALUES ('3252', '385', '平湖市', '3');
INSERT INTO `tv_global_region` VALUES ('3253', '385', '桐乡市', '3');
INSERT INTO `tv_global_region` VALUES ('3254', '385', '海盐县', '3');
INSERT INTO `tv_global_region` VALUES ('3255', '386', '婺城区', '3');
INSERT INTO `tv_global_region` VALUES ('3256', '386', '金东区', '3');
INSERT INTO `tv_global_region` VALUES ('3257', '386', '兰溪市', '3');
INSERT INTO `tv_global_region` VALUES ('3258', '386', '市区', '3');
INSERT INTO `tv_global_region` VALUES ('3259', '386', '佛堂镇', '3');
INSERT INTO `tv_global_region` VALUES ('3260', '386', '上溪镇', '3');
INSERT INTO `tv_global_region` VALUES ('3261', '386', '义亭镇', '3');
INSERT INTO `tv_global_region` VALUES ('3262', '386', '大陈镇', '3');
INSERT INTO `tv_global_region` VALUES ('3263', '386', '苏溪镇', '3');
INSERT INTO `tv_global_region` VALUES ('3264', '386', '赤岸镇', '3');
INSERT INTO `tv_global_region` VALUES ('3265', '386', '东阳市', '3');
INSERT INTO `tv_global_region` VALUES ('3266', '386', '永康市', '3');
INSERT INTO `tv_global_region` VALUES ('3267', '386', '武义县', '3');
INSERT INTO `tv_global_region` VALUES ('3268', '386', '浦江县', '3');
INSERT INTO `tv_global_region` VALUES ('3269', '386', '磐安县', '3');
INSERT INTO `tv_global_region` VALUES ('3270', '387', '莲都区', '3');
INSERT INTO `tv_global_region` VALUES ('3271', '387', '龙泉市', '3');
INSERT INTO `tv_global_region` VALUES ('3272', '387', '青田县', '3');
INSERT INTO `tv_global_region` VALUES ('3273', '387', '缙云县', '3');
INSERT INTO `tv_global_region` VALUES ('3274', '387', '遂昌县', '3');
INSERT INTO `tv_global_region` VALUES ('3275', '387', '松阳县', '3');
INSERT INTO `tv_global_region` VALUES ('3276', '387', '云和县', '3');
INSERT INTO `tv_global_region` VALUES ('3277', '387', '庆元县', '3');
INSERT INTO `tv_global_region` VALUES ('3278', '387', '景宁', '3');
INSERT INTO `tv_global_region` VALUES ('3279', '388', '海曙区', '3');
INSERT INTO `tv_global_region` VALUES ('3280', '388', '江东区', '3');
INSERT INTO `tv_global_region` VALUES ('3281', '388', '江北区', '3');
INSERT INTO `tv_global_region` VALUES ('3282', '388', '镇海区', '3');
INSERT INTO `tv_global_region` VALUES ('3283', '388', '北仑区', '3');
INSERT INTO `tv_global_region` VALUES ('3284', '388', '鄞州区', '3');
INSERT INTO `tv_global_region` VALUES ('3285', '388', '余姚市', '3');
INSERT INTO `tv_global_region` VALUES ('3286', '388', '慈溪市', '3');
INSERT INTO `tv_global_region` VALUES ('3287', '388', '奉化市', '3');
INSERT INTO `tv_global_region` VALUES ('3288', '388', '象山县', '3');
INSERT INTO `tv_global_region` VALUES ('3289', '388', '宁海县', '3');
INSERT INTO `tv_global_region` VALUES ('3290', '389', '越城区', '3');
INSERT INTO `tv_global_region` VALUES ('3291', '389', '上虞市', '3');
INSERT INTO `tv_global_region` VALUES ('3292', '389', '嵊州市', '3');
INSERT INTO `tv_global_region` VALUES ('3293', '389', '绍兴县', '3');
INSERT INTO `tv_global_region` VALUES ('3294', '389', '新昌县', '3');
INSERT INTO `tv_global_region` VALUES ('3295', '389', '诸暨市', '3');
INSERT INTO `tv_global_region` VALUES ('3296', '390', '椒江区', '3');
INSERT INTO `tv_global_region` VALUES ('3297', '390', '黄岩区', '3');
INSERT INTO `tv_global_region` VALUES ('3298', '390', '路桥区', '3');
INSERT INTO `tv_global_region` VALUES ('3299', '390', '温岭市', '3');
INSERT INTO `tv_global_region` VALUES ('3300', '390', '临海市', '3');
INSERT INTO `tv_global_region` VALUES ('3301', '390', '玉环县', '3');
INSERT INTO `tv_global_region` VALUES ('3302', '390', '三门县', '3');
INSERT INTO `tv_global_region` VALUES ('3303', '390', '天台县', '3');
INSERT INTO `tv_global_region` VALUES ('3304', '390', '仙居县', '3');
INSERT INTO `tv_global_region` VALUES ('3305', '391', '鹿城区', '3');
INSERT INTO `tv_global_region` VALUES ('3306', '391', '龙湾区', '3');
INSERT INTO `tv_global_region` VALUES ('3307', '391', '瓯海区', '3');
INSERT INTO `tv_global_region` VALUES ('3308', '391', '瑞安市', '3');
INSERT INTO `tv_global_region` VALUES ('3309', '391', '乐清市', '3');
INSERT INTO `tv_global_region` VALUES ('3310', '391', '洞头县', '3');
INSERT INTO `tv_global_region` VALUES ('3311', '391', '永嘉县', '3');
INSERT INTO `tv_global_region` VALUES ('3312', '391', '平阳县', '3');
INSERT INTO `tv_global_region` VALUES ('3313', '391', '苍南县', '3');
INSERT INTO `tv_global_region` VALUES ('3314', '391', '文成县', '3');
INSERT INTO `tv_global_region` VALUES ('3315', '391', '泰顺县', '3');
INSERT INTO `tv_global_region` VALUES ('3316', '392', '定海区', '3');
INSERT INTO `tv_global_region` VALUES ('3317', '392', '普陀区', '3');
INSERT INTO `tv_global_region` VALUES ('3318', '392', '岱山县', '3');
INSERT INTO `tv_global_region` VALUES ('3319', '392', '嵊泗县', '3');
INSERT INTO `tv_global_region` VALUES ('3320', '393', '衢州市', '3');
INSERT INTO `tv_global_region` VALUES ('3321', '393', '江山市', '3');
INSERT INTO `tv_global_region` VALUES ('3322', '393', '常山县', '3');
INSERT INTO `tv_global_region` VALUES ('3323', '393', '开化县', '3');
INSERT INTO `tv_global_region` VALUES ('3324', '393', '龙游县', '3');
INSERT INTO `tv_global_region` VALUES ('3325', '394', '合川区', '3');
INSERT INTO `tv_global_region` VALUES ('3326', '394', '江津区', '3');
INSERT INTO `tv_global_region` VALUES ('3327', '394', '南川区', '3');
INSERT INTO `tv_global_region` VALUES ('3328', '394', '永川区', '3');
INSERT INTO `tv_global_region` VALUES ('3329', '394', '南岸区', '3');
INSERT INTO `tv_global_region` VALUES ('3330', '394', '渝北区', '3');
INSERT INTO `tv_global_region` VALUES ('3331', '394', '万盛区', '3');
INSERT INTO `tv_global_region` VALUES ('3332', '394', '大渡口区', '3');
INSERT INTO `tv_global_region` VALUES ('3333', '394', '万州区', '3');
INSERT INTO `tv_global_region` VALUES ('3334', '394', '北碚区', '3');
INSERT INTO `tv_global_region` VALUES ('3335', '394', '沙坪坝区', '3');
INSERT INTO `tv_global_region` VALUES ('3336', '394', '巴南区', '3');
INSERT INTO `tv_global_region` VALUES ('3337', '394', '涪陵区', '3');
INSERT INTO `tv_global_region` VALUES ('3338', '394', '江北区', '3');
INSERT INTO `tv_global_region` VALUES ('3339', '394', '九龙坡区', '3');
INSERT INTO `tv_global_region` VALUES ('3340', '394', '渝中区', '3');
INSERT INTO `tv_global_region` VALUES ('3341', '394', '黔江开发区', '3');
INSERT INTO `tv_global_region` VALUES ('3342', '394', '长寿区', '3');
INSERT INTO `tv_global_region` VALUES ('3343', '394', '双桥区', '3');
INSERT INTO `tv_global_region` VALUES ('3344', '394', '綦江县', '3');
INSERT INTO `tv_global_region` VALUES ('3345', '394', '潼南县', '3');
INSERT INTO `tv_global_region` VALUES ('3346', '394', '铜梁县', '3');
INSERT INTO `tv_global_region` VALUES ('3347', '394', '大足县', '3');
INSERT INTO `tv_global_region` VALUES ('3348', '394', '荣昌县', '3');
INSERT INTO `tv_global_region` VALUES ('3349', '394', '璧山县', '3');
INSERT INTO `tv_global_region` VALUES ('3350', '394', '垫江县', '3');
INSERT INTO `tv_global_region` VALUES ('3351', '394', '武隆县', '3');
INSERT INTO `tv_global_region` VALUES ('3352', '394', '丰都县', '3');
INSERT INTO `tv_global_region` VALUES ('3353', '394', '城口县', '3');
INSERT INTO `tv_global_region` VALUES ('3354', '394', '梁平县', '3');
INSERT INTO `tv_global_region` VALUES ('3355', '394', '开县', '3');
INSERT INTO `tv_global_region` VALUES ('3356', '394', '巫溪县', '3');
INSERT INTO `tv_global_region` VALUES ('3357', '394', '巫山县', '3');
INSERT INTO `tv_global_region` VALUES ('3358', '394', '奉节县', '3');
INSERT INTO `tv_global_region` VALUES ('3359', '394', '云阳县', '3');
INSERT INTO `tv_global_region` VALUES ('3360', '394', '忠县', '3');
INSERT INTO `tv_global_region` VALUES ('3361', '394', '石柱', '3');
INSERT INTO `tv_global_region` VALUES ('3362', '394', '彭水', '3');
INSERT INTO `tv_global_region` VALUES ('3363', '394', '酉阳', '3');
INSERT INTO `tv_global_region` VALUES ('3364', '394', '秀山', '3');
INSERT INTO `tv_global_region` VALUES ('3365', '395', '沙田区', '3');
INSERT INTO `tv_global_region` VALUES ('3366', '395', '东区', '3');
INSERT INTO `tv_global_region` VALUES ('3367', '395', '观塘区', '3');
INSERT INTO `tv_global_region` VALUES ('3368', '395', '黄大仙区', '3');
INSERT INTO `tv_global_region` VALUES ('3369', '395', '九龙城区', '3');
INSERT INTO `tv_global_region` VALUES ('3370', '395', '屯门区', '3');
INSERT INTO `tv_global_region` VALUES ('3371', '395', '葵青区', '3');
INSERT INTO `tv_global_region` VALUES ('3372', '395', '元朗区', '3');
INSERT INTO `tv_global_region` VALUES ('3373', '395', '深水埗区', '3');
INSERT INTO `tv_global_region` VALUES ('3374', '395', '西贡区', '3');
INSERT INTO `tv_global_region` VALUES ('3375', '395', '大埔区', '3');
INSERT INTO `tv_global_region` VALUES ('3376', '395', '湾仔区', '3');
INSERT INTO `tv_global_region` VALUES ('3377', '395', '油尖旺区', '3');
INSERT INTO `tv_global_region` VALUES ('3378', '395', '北区', '3');
INSERT INTO `tv_global_region` VALUES ('3379', '395', '南区', '3');
INSERT INTO `tv_global_region` VALUES ('3380', '395', '荃湾区', '3');
INSERT INTO `tv_global_region` VALUES ('3381', '395', '中西区', '3');
INSERT INTO `tv_global_region` VALUES ('3382', '395', '离岛区', '3');
INSERT INTO `tv_global_region` VALUES ('3383', '396', '澳门', '3');
INSERT INTO `tv_global_region` VALUES ('3384', '397', '台北', '3');
INSERT INTO `tv_global_region` VALUES ('3385', '397', '高雄', '3');
INSERT INTO `tv_global_region` VALUES ('3386', '397', '基隆', '3');
INSERT INTO `tv_global_region` VALUES ('3387', '397', '台中', '3');
INSERT INTO `tv_global_region` VALUES ('3388', '397', '台南', '3');
INSERT INTO `tv_global_region` VALUES ('3389', '397', '新竹', '3');
INSERT INTO `tv_global_region` VALUES ('3390', '397', '嘉义', '3');
INSERT INTO `tv_global_region` VALUES ('3391', '397', '宜兰县', '3');
INSERT INTO `tv_global_region` VALUES ('3392', '397', '桃园县', '3');
INSERT INTO `tv_global_region` VALUES ('3393', '397', '苗栗县', '3');
INSERT INTO `tv_global_region` VALUES ('3394', '397', '彰化县', '3');
INSERT INTO `tv_global_region` VALUES ('3395', '397', '南投县', '3');
INSERT INTO `tv_global_region` VALUES ('3396', '397', '云林县', '3');
INSERT INTO `tv_global_region` VALUES ('3397', '397', '屏东县', '3');
INSERT INTO `tv_global_region` VALUES ('3398', '397', '台东县', '3');
INSERT INTO `tv_global_region` VALUES ('3399', '397', '花莲县', '3');
INSERT INTO `tv_global_region` VALUES ('3400', '397', '澎湖县', '3');
INSERT INTO `tv_global_region` VALUES ('3401', '3', '合肥', '2');
INSERT INTO `tv_global_region` VALUES ('3402', '3401', '庐阳区', '3');
INSERT INTO `tv_global_region` VALUES ('3403', '3401', '瑶海区', '3');
INSERT INTO `tv_global_region` VALUES ('3404', '3401', '蜀山区', '3');
INSERT INTO `tv_global_region` VALUES ('3405', '3401', '包河区', '3');
INSERT INTO `tv_global_region` VALUES ('3406', '3401', '长丰县', '3');
INSERT INTO `tv_global_region` VALUES ('3407', '3401', '肥东县', '3');
INSERT INTO `tv_global_region` VALUES ('3408', '3401', '肥西县', '3');

-- -----------------------------
-- Table structure for `tv_hel`
-- -----------------------------
DROP TABLE IF EXISTS `tv_hel`;
CREATE TABLE `tv_hel` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL COMMENT '商家用户id',
  `logo_img_url` varchar(100) DEFAULT NULL COMMENT '封面图片',
  `hel_img_url` tinytext COMMENT '房屋图片（限制4张）',
  `hel_number` varchar(3) NOT NULL DEFAULT '0' COMMENT '房间数量',
  `hel_name` varchar(100) NOT NULL COMMENT '房屋名',
  `name` varchar(25) NOT NULL COMMENT '业主名',
  `hel_tel` varchar(20) NOT NULL COMMENT '业主电话',
  `max_man` varchar(5) NOT NULL COMMENT '居住人数',
  `day_price` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '每天价',
  `vip_price` tinytext COMMENT 'Vip价格',
  `favorable_price` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '优惠价',
  `deposit` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '押金',
  `provinces` varchar(11) DEFAULT NULL COMMENT '省份',
  `citys` varchar(11) DEFAULT NULL COMMENT '城市',
  `countys` varchar(11) DEFAULT NULL COMMENT '县城',
  `address` varchar(255) NOT NULL COMMENT '房屋所在地址',
  `nearby_traffic` tinytext COMMENT '附近交通',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `introduce` text COMMENT '房屋介绍',
  `kindly_reminder` text COMMENT '温馨提示',
  `bed_type` varchar(10) NOT NULL COMMENT '床型 1',
  `type` varchar(10) NOT NULL COMMENT '房间类型 2',
  `facilities` tinytext NOT NULL COMMENT '房间设施 3',
  `bedroom` varchar(2) NOT NULL DEFAULT '0' COMMENT '卧室（数量）',
  `toilet` varchar(2) NOT NULL DEFAULT '0' COMMENT '卫生间',
  `bed` varchar(2) NOT NULL DEFAULT '0' COMMENT '床位',
  `tel_status` int(1) NOT NULL DEFAULT '1' COMMENT '房间状态（有房，无房）',
  `check_in` varchar(5) DEFAULT NULL COMMENT '入住时间',
  `check_out` varchar(5) DEFAULT NULL COMMENT '退房时间',
  `insert_time` varchar(10) NOT NULL COMMENT '生成时间',
  `update_time` varchar(10) DEFAULT NULL COMMENT '更新时间',
  `sort` varchar(5) NOT NULL DEFAULT '0' COMMENT '排序',
  `look_number` int(11) DEFAULT NULL COMMENT '已看人数',
  `praise_number` varchar(10) NOT NULL DEFAULT '0' COMMENT '已赞人数',
  `star` varchar(1) DEFAULT '1' COMMENT '房源星级',
  `pro_type` int(1) NOT NULL DEFAULT '1' COMMENT '产品类型',
  `status` varchar(2) NOT NULL DEFAULT '3' COMMENT '状态（0：下架；1：启用；2：删除;3：待通过；4：不通过）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='房源表';

-- -----------------------------
-- Records of `tv_hel`
-- -----------------------------
INSERT INTO `tv_hel` VALUES ('3', '1', '195', '258,259,260,261,', '0', '京基喜来登度假酒店', '贺鹏飞', '18588613273', '2', '150.00', '20|0,', '75.00', '100.00', '', '36', '399', '盐田区 盐葵路大梅沙段9号 ', '距会展中心地铁站146米 ,很好坐车的拉', '五星级大酒店', '北京寿州大饭店位于北京市西客站北广场向东约1公里，中土大厦旁，距离天安门广场约15分钟路程，交通便利、地理位置十分优越。北京寿州大饭店是按照高品质涉外酒店标准建造而成的，是集餐饮、客房、SPA养生为一体的综合性饭店，会议中心可以设计不同类型的会议形式，倡导放心、健康、绿色的SPA养生会所，是旅途和商务活动中，放松身心的理想之地。', '', '实体床', '双人房', '空调,电视,电脑,电话,洗衣机', '1', '1', '1', '1', '08:00', '12:00', '0', '1440401457', '0', '', '1', '3', '1', '1');
INSERT INTO `tv_hel` VALUES ('4', '1', '200', '201,202,203,204,205,', '0', '星河丽思卡尔顿酒店', '许嘉明', '18507565649', '1-5', '100.00', '20|0,', '99.00', '100.00', '2', '52', '501', '福田区 福华三路116号(~i/“)', '大把公交车都到,交通方便.比如302,M313,405,B6等等', '星河丽思卡尔顿酒店', '北京寿州大饭店位于北京市西客站北广场向东约1公里，中土大厦旁，距离天安门广场约15分钟路程，交通便利、地理位置十分优越。北京寿州大饭店是按照高品质涉外酒店标准建造而成的，是集餐饮、客房、SPA养生为一体的综合性饭店，会议中心可以设计不同类型的会议形式，倡导放心、健康、绿色的SPA养生会所，是旅途和商务活动中，放松身心的理想之地。', '', '上下床', '单人房', '空调,电脑,生活必需品,电话,烘干机', '1', '2', '1', '0', '06:00', '12:00', '0', '1439981922', '0', '', '0', '5', '1', '1');
INSERT INTO `tv_hel` VALUES ('5', '44', '214', '217,218,274,275,', '0', '六星汽车宾馆(罗湖旗舰店) ', '刘武胜', '13786102900', '2', '300.00', '20|80,21|75,', '297.00', '200.00', '6', '77', '705', '罗湖区 罗沙路5069号罗芳立交六星汽车园内', '罗湖体育馆公交站或新秀地铁站A出口(距新秀站约463米) ', '六星汽车宾馆', '北京寿州大饭店位于北京市西客站北广场向东约1公里，中土大厦旁，距离天安门广场约15分钟路程，交通便利、地理位置十分优越。北京寿州大饭店是按照高品质涉外酒店标准建造而成的，是集餐饮、客房、SPA养生为一体的综合性饭店，会议中心可以设计不同类型的会议形式，倡导放心、健康、绿色的SPA养生会所，是旅途和商务活动中，放松身心的理想之地。', '', '实体床', '双人房', '空调,电视,电脑,宽带上网,厨房,生活必需品,无线网络,电话,热水浴缸,洗衣机', '1', '1', '1', '1', '08:00', '12:00', '1440139755', '', '0', '', '0', '5', '1', '1');
INSERT INTO `tv_hel` VALUES ('6', '1', '', '', '0', '夜来香酒店', '孙茂林', '而', '而', '0.00', '20|20,', '0.00', '0.00', '', '', '', '发生的', '', '夜来香酒店', '北京寿州大饭店位于北京市西客站北广场向东约1公里，中土大厦旁，距离天安门广场约15分钟路程，交通便利、地理位置十分优越。北京寿州大饭店是按照高品质涉外酒店标准建造而成的，是集餐饮、客房、SPA养生为一体的综合性饭店，会议中心可以设计不同类型的会议形式，倡导放心、健康、绿色的SPA养生会所，是旅途和商务活动中，放松身心的理想之地。', '', '实体床', '单人房', '', '0', '0', '1', '1', '', '', '1440401403', '1440401409', '0', '', '0', '5', '1', '2');
INSERT INTO `tv_hel` VALUES ('7', '1', '219', '266,267,268,269,270,', '0', '深圳东部华侨城茵特拉根酒店', '魏阳军', '13434457872', '2', '200.00', '20|0,', '198.00', '300.00', '6', '77', '705', '盐田区 大梅沙东部华侨城茵特拉根小镇内(近湿地花园) ', '无', '茵特拉根酒店', '北京寿州大饭店位于北京市西客站北广场向东约1公里，中土大厦旁，距离天安门广场约15分钟路程，交通便利、地理位置十分优越。北京寿州大饭店是按照高品质涉外酒店标准建造而成的，是集餐饮、客房、SPA养生为一体的综合性饭店，会议中心可以设计不同类型的会议形式，倡导放心、健康、绿色的SPA养生会所，是旅途和商务活动中，放松身心的理想之地。', '', '上下床', '双人房', '空调,电视,电脑', '0', '1', '1', '1', '01:00', '12:00', '1440551643', '', '0', '', '0', '3', '1', '1');
INSERT INTO `tv_hel` VALUES ('8', '49', '229', '262,263,264,265,', '0', '天使恋人情侣主题酒店(翠竹情缘店) ', '王亚雄', '15090793977', '4', '80.00', '20|0,', '72.00', '100.00', '3', '39', '424', '罗湖区 东门北路2508号世纪汇鑫大厦5-6楼', '靠近竹园宾馆站,龙岗线翠竹站B2出口前200米左右', '翠竹情侣店', '北京寿州大饭店位于北京市西客站北广场向东约1公里，中土大厦旁，距离天安门广场约15分钟路程，交通便利、地理位置十分优越。北京寿州大饭店是按照高品质涉外酒店标准建造而成的，是集餐饮、客房、SPA养生为一体的综合性饭店，会议中心可以设计不同类型的会议形式，倡导放心、健康、绿色的SPA养生会所，是旅途和商务活动中，放松身心的理想之地。', '', '上下床', '双人房', '电视,宽带上网,生活必需品', '0', '1', '1', '1', '08:00', '16:00', '1440584956', '', '0', '', '0', '1', '1', '1');
INSERT INTO `tv_hel` VALUES ('9', '1', '237', '238,239,240,241,', '0', '维也纳酒店(深圳春风路店) ', '刘 凯', '13322934720', '8', '50.00', '20|48,', '0.00', '100.00', '4', '54', '534', '罗湖区 春风路2012号', '近万佳购物广场 距湖贝地铁站388米', '春风满门店', '北京寿州大饭店位于北京市西客站北广场向东约1公里，中土大厦旁，距离天安门广场约15分钟路程，交通便利、地理位置十分优越。北京寿州大饭店是按照高品质涉外酒店标准建造而成的，是集餐饮、客房、SPA养生为一体的综合性饭店，会议中心可以设计不同类型的会议形式，倡导放心、健康、绿色的SPA养生会所，是旅途和商务活动中，放松身心的理想之地。', '', '上下床', '四人房', '电脑,厨房,无线网络,电话', '3', '1', '1', '1', '00:00', '12:00', '1440671177', '', '0', '', '0', '1', '1', '1');
INSERT INTO `tv_hel` VALUES ('10', '1', '242', '243,244,245,246,247,248,', '0', '大中华喜来登酒店 ', '孙茂林', '15118175882', '0-5', '233.00', '20|200,', '0.00', '300.00', '3', '36', '400', '福田区 福华一路1号大中华国际交易广场', '(近金田南路) 距会展中心地铁站122米', '得意洋洋店', '北京寿州大饭店位于北京市西客站北广场向东约1公里，中土大厦旁，距离天安门广场约15分钟路程，交通便利、地理位置十分优越。北京寿州大饭店是按照高品质涉外酒店标准建造而成的，是集餐饮、客房、SPA养生为一体的综合性饭店，会议中心可以设计不同类型的会议形式，倡导放心、健康、绿色的SPA养生会所，是旅途和商务活动中，放松身心的理想之地。', '', '实体床', '单人房', '空调,电视,热水浴缸', '1', '1', '1', '1', '00:00', '09:30', '1440723220', '', '1', '', '0', '1', '1', '1');
INSERT INTO `tv_hel` VALUES ('11', '1', '249', '250,251,252,', '0', '隐秀山居酒店', '朱其方', '13798531805', '2', '260.00', '20|220,', '0.00', '100.00', '', '', '', '龙岗区 龙岗街道宝荷路', '近地铁三号线', '脆脆冰一元店', '北京寿州大饭店位于北京市西客站北广场向东约1公里，中土大厦旁，距离天安门广场约15分钟路程，交通便利、地理位置十分优越。北京寿州大饭店是按照高品质涉外酒店标准建造而成的，是集餐饮、客房、SPA养生为一体的综合性饭店，会议中心可以设计不同类型的会议形式，倡导放心、健康、绿色的SPA养生会所，是旅途和商务活动中，放松身心的理想之地。', '', '实体床', '单人房', '电视,生活必需品,热水浴缸', '0', '1', '1', '1', '00:00', '12:00', '1440730580', '', '0', '', '0', '1', '1', '1');
INSERT INTO `tv_hel` VALUES ('12', '1', '276', '282,', '0', '43534', '345', '435', '0-3', '0.00', '20|0,', '0.00', '0.00', '', '', '', '3432', '', '脆脆香酒楼', '北京寿州大饭店位于北京市西客站北广场向东约1公里，中土大厦旁，距离天安门广场约15分钟路程，交通便利、地理位置十分优越。北京寿州大饭店是按照高品质涉外酒店标准建造而成的，是集餐饮、客房、SPA养生为一体的综合性饭店，会议中心可以设计不同类型的会议形式，倡导放心、健康、绿色的SPA养生会所，是旅途和商务活动中，放松身心的理想之地。', '', '实体床', '单人房', '电视', '0', '1', '1', '1', '00:00', '12:00', '1440733425', '1440748339', '0', '', '0', '1', '1', '2');
INSERT INTO `tv_hel` VALUES ('13', '1', '389', '390,391,', '0', 'DAY 1-3 墨尔本Quality Hotel Batman\'s Hill on Collins (Room Only) Hotel （或同级别精品酒店）', '许嘉明', '15090793977', '1-2', '260.00', '20|0,21|0,', '0.00', '0.00', '', '', '', '龙岗区 龙岗街道宝荷路', '近地铁三号线', '杂货店', '北京寿州大饭店位于北京市西客站北广场向东约1公里，中土大厦旁，距离天安门广场约15分钟路程，交通便利、地理位置十分优越。北京寿州大饭店是按照高品质涉外酒店标准建造而成的，是集餐饮、客房、SPA养生为一体的综合性饭店，会议中心可以设计不同类型的会议形式，倡导放心、健康、绿色的SPA养生会所，是旅途和商务活动中，放松身心的理想之地。', '', '', '', '', '0', '0', '0', '1', '', '', '', '', '0', '', '0', '1', '1', '3');
INSERT INTO `tv_hel` VALUES ('14', '1', '377', '378,379,', '0', '东部湾海景房', '杨毅平', '13049340993', '0-5', '300.00', '20|75,', '240.00', '100.00', '6', '82', '759', '东部湾', '', '东部湾1号', '', '', '上下床', '双人房', '电视,生活必需品,热水浴缸', '0', '1', '1', '1', '00:00', '12:00', '1441769018', '', '0', '', '0', '4', '1', '1');

-- -----------------------------
-- Table structure for `tv_home_img_config`
-- -----------------------------
DROP TABLE IF EXISTS `tv_home_img_config`;
CREATE TABLE `tv_home_img_config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(11) DEFAULT NULL COMMENT '操作者id',
  `img_url` text COMMENT '列表图',
  `title` varchar(200) DEFAULT NULL COMMENT '图片标题',
  `retitle` varchar(200) DEFAULT NULL COMMENT '副标题',
  `type` varchar(3) DEFAULT NULL COMMENT '类型(1：房源；2：餐饮；3：景点；4：路线;5：分类路线;6:LOGO图)',
  `status` varchar(1) DEFAULT NULL COMMENT '状态(0：禁用；1：启用)',
  `insert_time` varchar(10) DEFAULT NULL COMMENT '添加时间',
  `update_time` varchar(10) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_home_img_config`
-- -----------------------------
INSERT INTO `tv_home_img_config` VALUES ('1', '1', '354', '带着你的亲人去旅行', '亲友自由行精选路线', '4', '1', '1440470132', '1441010956');
INSERT INTO `tv_home_img_config` VALUES ('2', '1', '355', '结伴自由行你我相随', '自由结伴，分享你我', '4', '1', '1440470132', '1441010956');
INSERT INTO `tv_home_img_config` VALUES ('3', '1', '356', '成功靠朋友,成就靠团队.', '团队自由行攻略', '4', '1', '1440470132', '1441010956');
INSERT INTO `tv_home_img_config` VALUES ('4', '1', '361', '最美住宿', '', '1', '1', '1440474706', '1441010943');
INSERT INTO `tv_home_img_config` VALUES ('5', '1', '362', '吃货必去 ', '', '2', '1', '1440474706', '1441010943');
INSERT INTO `tv_home_img_config` VALUES ('6', '1', '363', '尽情玩耍', '', '3', '1', '1440474706', '1441010943');
INSERT INTO `tv_home_img_config` VALUES ('7', '1', '364', '美中行走', '', '5', '1', '1440474706', '1441010943');
INSERT INTO `tv_home_img_config` VALUES ('8', '', '370', '', '', '6', '1', '1441594528', '1441594844');

-- -----------------------------
-- Table structure for `tv_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `tv_hooks`;
CREATE TABLE `tv_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `搜索索引` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_hooks`
-- -----------------------------
INSERT INTO `tv_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '');
INSERT INTO `tv_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop');
INSERT INTO `tv_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment');
INSERT INTO `tv_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment');
INSERT INTO `tv_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '');
INSERT INTO `tv_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment');
INSERT INTO `tv_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor');
INSERT INTO `tv_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin');
INSERT INTO `tv_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam');
INSERT INTO `tv_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor');
INSERT INTO `tv_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '');

-- -----------------------------
-- Table structure for `tv_img`
-- -----------------------------
DROP TABLE IF EXISTS `tv_img`;
CREATE TABLE `tv_img` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(100) DEFAULT NULL COMMENT '路径',
  `name` varchar(60) DEFAULT NULL COMMENT '图片名',
  `insert_time` varchar(10) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=394 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_img`
-- -----------------------------
INSERT INTO `tv_img` VALUES ('4', './Uploads/eat/1440553874.jpg', '', '1440553874');
INSERT INTO `tv_img` VALUES ('3', './Uploads/eat/1440553821.jpg', '', '1440553821');
INSERT INTO `tv_img` VALUES ('5', './Uploads/eat/1440553907.jpg', '', '1440553907');
INSERT INTO `tv_img` VALUES ('6', './Uploads/eat/1440554006.jpg', '', '1440554006');
INSERT INTO `tv_img` VALUES ('7', './Uploads/eat/1440554093.jpg', '', '1440554094');
INSERT INTO `tv_img` VALUES ('8', './Uploads/eat/1440554155.jpg', '', '1440554155');
INSERT INTO `tv_img` VALUES ('30', './Uploads/play/1440569775.jpg', '', '1440569775');
INSERT INTO `tv_img` VALUES ('10', './Uploads/eat/1440557316.jpg', '', '1440557316');
INSERT INTO `tv_img` VALUES ('11', './Uploads/eat/1440557320.jpg', '', '1440557320');
INSERT INTO `tv_img` VALUES ('12', './Uploads/eat/1440557324.jpg', '', '1440557324');
INSERT INTO `tv_img` VALUES ('13', './Uploads/Room/1440558353.jpg', '', '1440558353');
INSERT INTO `tv_img` VALUES ('14', './Uploads/Room/1440558355.jpg', '', '1440558355');
INSERT INTO `tv_img` VALUES ('15', './Uploads/Room/1440558383.jpg', '', '1440558380');
INSERT INTO `tv_img` VALUES ('16', './Uploads/Room/1440558383.jpg', '', '1440558383');
INSERT INTO `tv_img` VALUES ('17', './Uploads/Room/1440558438.jpg', '', '1440558438');
INSERT INTO `tv_img` VALUES ('29', './Uploads/play/1440569772.jpg', '', '1440569772');
INSERT INTO `tv_img` VALUES ('19', './Uploads/Room/1440558535.jpg', '', '1440558535');
INSERT INTO `tv_img` VALUES ('20', './Uploads/Room/1440558537.jpg', '', '1440558537');
INSERT INTO `tv_img` VALUES ('21', './Uploads/Room/1440558671.jpg', '', '1440558671');
INSERT INTO `tv_img` VALUES ('22', './Uploads/Room/1440558673.jpg', '', '1440558673');
INSERT INTO `tv_img` VALUES ('23', './Uploads/Room/1440558674.jpg', '', '1440558675');
INSERT INTO `tv_img` VALUES ('24', './Uploads/Room/1440558676.jpg', '', '1440558676');
INSERT INTO `tv_img` VALUES ('25', './Uploads/route/1440559613.jpg', '', '1440559614');
INSERT INTO `tv_img` VALUES ('26', './Uploads/play/1440560252.jpg', '', '1440560252');
INSERT INTO `tv_img` VALUES ('27', './Uploads/play/1440561481.jpg', '', '1440561482');
INSERT INTO `tv_img` VALUES ('28', './Uploads/route/1440562835.jpg', '', '1440562835');
INSERT INTO `tv_img` VALUES ('31', './Uploads/play/1440569783.jpg', '', '1440569783');
INSERT INTO `tv_img` VALUES ('32', './Uploads/user/1440570813.jpg', '', '1440570813');
INSERT INTO `tv_img` VALUES ('33', './Uploads/user/1440570970.jpg', '', '1440570970');
INSERT INTO `tv_img` VALUES ('34', '/Uploads/Facilitator/1440572363.jpg', '', '1440572363');
INSERT INTO `tv_img` VALUES ('35', './Uploads/Facilitator/1440572384.jpg', '', '1440572384');
INSERT INTO `tv_img` VALUES ('36', './Uploads/Facilitator/1440572387.jpg', '', '1440572395');
INSERT INTO `tv_img` VALUES ('37', './Uploads/Facilitator/1440572400.jpg', '', '1440572400');
INSERT INTO `tv_img` VALUES ('38', './Uploads/Facilitator/1440574804.jpg', '', '1440574804');
INSERT INTO `tv_img` VALUES ('39', './Uploads/Facilitator/1440574806.jpg', '', '1440574806');
INSERT INTO `tv_img` VALUES ('40', './Uploads/play/1440575286.jpg', '', '1440575286');
INSERT INTO `tv_img` VALUES ('41', './Uploads/play/1440575359.jpg', '', '1440575359');
INSERT INTO `tv_img` VALUES ('42', './Uploads/play/1440575501.jpg', '', '1440575501');
INSERT INTO `tv_img` VALUES ('43', './Uploads/Room/1440575592.jpg', '', '1440575592');
INSERT INTO `tv_img` VALUES ('44', './Uploads/Facilitator/1440578047.jpg', '', '1440578047');
INSERT INTO `tv_img` VALUES ('45', './Uploads/Facilitator/1440578051.jpg', '', '1440578051');
INSERT INTO `tv_img` VALUES ('46', './Uploads/eat/1440583343.jpg', '', '1440583344');
INSERT INTO `tv_img` VALUES ('47', './Uploads/eat/1440583348.jpg', '', '1440583348');
INSERT INTO `tv_img` VALUES ('48', './Uploads/eat/1440583349.jpg', '', '1440583350');
INSERT INTO `tv_img` VALUES ('49', './Uploads/eat/1440583393.jpg', '', '1440583393');
INSERT INTO `tv_img` VALUES ('50', './Uploads/eat/1440583394.jpg', '', '1440583394');
INSERT INTO `tv_img` VALUES ('51', './Uploads/eat/1440583396.jpg', '', '1440583396');
INSERT INTO `tv_img` VALUES ('52', './Uploads/eat/1440583397.jpg', '', '1440583397');
INSERT INTO `tv_img` VALUES ('53', './Uploads/eat/1440583400.jpg', '', '1440583400');
INSERT INTO `tv_img` VALUES ('54', './Uploads/play/1440584303.jpg', '', '1440584304');
INSERT INTO `tv_img` VALUES ('55', './Uploads/play/1440584306.jpg', '', '1440584306');
INSERT INTO `tv_img` VALUES ('56', './Uploads/play/1440584307.jpg', '', '1440584308');
INSERT INTO `tv_img` VALUES ('57', './Uploads/route/1440584653.jpg', '', '1440584653');
INSERT INTO `tv_img` VALUES ('58', './Uploads/Room/1440584931.jpg', '', '1440584931');
INSERT INTO `tv_img` VALUES ('59', './Uploads/Room/1440584933.jpg', '', '1440584933');
INSERT INTO `tv_img` VALUES ('60', './Uploads/Room/1440584935.jpg', '', '1440584935');
INSERT INTO `tv_img` VALUES ('61', './Uploads/Room/1440660637.png', '', '1440660638');
INSERT INTO `tv_img` VALUES ('62', './Uploads/Room/1440663560.png', '', '1440663560');
INSERT INTO `tv_img` VALUES ('63', './Uploads/Room/1440663595.jpg', '', '1440663595');
INSERT INTO `tv_img` VALUES ('64', './Uploads/route/1440663615.jpg', '', '1440663615');
INSERT INTO `tv_img` VALUES ('65', './Uploads/route/1440663641.jpg', '', '1440663641');
INSERT INTO `tv_img` VALUES ('66', './Uploads/route/1440663772.jpg', '', '1440663772');
INSERT INTO `tv_img` VALUES ('67', './Uploads/route/1440664144.jpg', '', '1440664144');
INSERT INTO `tv_img` VALUES ('68', './Uploads/route/1440664818.jpg', '', '1440664818');
INSERT INTO `tv_img` VALUES ('69', './Uploads/route/1440666061.jpg', '', '1440666061');
INSERT INTO `tv_img` VALUES ('70', './Uploads/route/1440666179.jpg', '', '1440666180');
INSERT INTO `tv_img` VALUES ('71', './Uploads/eat/1440667963.jpg', '', '1440667963');
INSERT INTO `tv_img` VALUES ('72', './Uploads/eat/1440667967.jpg', '', '1440667967');
INSERT INTO `tv_img` VALUES ('73', './Uploads/eat/1440667978.jpg', '', '1440667978');
INSERT INTO `tv_img` VALUES ('74', './Uploads/eat/1440668217.jpg', '', '1440668218');
INSERT INTO `tv_img` VALUES ('75', './Uploads/eat/1440668221.jpg', '', '1440668221');
INSERT INTO `tv_img` VALUES ('76', './Uploads/eat/1440668771.jpg', '', '1440668771');
INSERT INTO `tv_img` VALUES ('77', './Uploads/eat/1440668788.jpg', '', '1440668788');
INSERT INTO `tv_img` VALUES ('78', './Uploads/eat/1440668812.jpg', '', '1440668812');
INSERT INTO `tv_img` VALUES ('79', './Uploads/eat/1440668826.jpg', '', '1440668826');
INSERT INTO `tv_img` VALUES ('80', './Uploads/eat/1440668861.jpg', '', '1440668861');
INSERT INTO `tv_img` VALUES ('81', './Uploads/play/1440669109.jpg', '', '1440669109');
INSERT INTO `tv_img` VALUES ('82', './Uploads/play/1440669135.jpg', '', '1440669135');
INSERT INTO `tv_img` VALUES ('83', './Uploads/play/1440669159.jpg', '', '1440669159');
INSERT INTO `tv_img` VALUES ('84', './Uploads/play/1440669160.jpg', '', '1440669160');
INSERT INTO `tv_img` VALUES ('85', './Uploads/play/1440669161.jpg', '', '1440669161');
INSERT INTO `tv_img` VALUES ('86', './Uploads/play/1440669163.jpg', '', '1440669163');
INSERT INTO `tv_img` VALUES ('87', './Uploads/play/1440669165.jpg', '', '1440669165');
INSERT INTO `tv_img` VALUES ('88', './Uploads/play/1440669169.jpg', '', '1440669170');
INSERT INTO `tv_img` VALUES ('89', './Uploads/play/1440669171.jpg', '', '1440669171');
INSERT INTO `tv_img` VALUES ('90', './Uploads/play/1440669185.jpg', '', '1440669185');
INSERT INTO `tv_img` VALUES ('91', './Uploads/play/1440669206.jpg', '', '1440669206');
INSERT INTO `tv_img` VALUES ('92', './Uploads/play/1440669237.jpg', '', '1440669237');
INSERT INTO `tv_img` VALUES ('93', './Uploads/play/1440669281.jpg', '', '1440669281');
INSERT INTO `tv_img` VALUES ('94', './Uploads/eat/1440670526.jpg', '', '1440670526');
INSERT INTO `tv_img` VALUES ('95', './Uploads/eat/1440670529.jpg', '', '1440670529');
INSERT INTO `tv_img` VALUES ('96', './Uploads/eat/1440670532.jpg', '', '1440670532');
INSERT INTO `tv_img` VALUES ('97', './Uploads/eat/1440670535.jpg', '', '1440670535');
INSERT INTO `tv_img` VALUES ('98', './Uploads/eat/1440670538.jpg', '', '1440670538');
INSERT INTO `tv_img` VALUES ('99', './Uploads/eat/1440670549.jpg', '', '1440670549');
INSERT INTO `tv_img` VALUES ('100', './Uploads/play/1440670580.jpg', '', '1440670580');
INSERT INTO `tv_img` VALUES ('101', './Uploads/Room/1440670873.jpg', '', '1440670873');
INSERT INTO `tv_img` VALUES ('102', './Uploads/Room/1440670878.jpg', '', '1440670878');
INSERT INTO `tv_img` VALUES ('103', './Uploads/Room/1440671155.jpg', '', '1440671155');
INSERT INTO `tv_img` VALUES ('104', './Uploads/eat/1440671190.jpg', '', '1440671190');
INSERT INTO `tv_img` VALUES ('105', './Uploads/eat/1440671038.jpg', '', '1440671039');
INSERT INTO `tv_img` VALUES ('106', './Uploads/eat/1440671068.jpg', '', '1440671068');
INSERT INTO `tv_img` VALUES ('107', './Uploads/eat/1440671071.jpg', '', '1440671071');
INSERT INTO `tv_img` VALUES ('108', './Uploads/eat/1440671072.jpg', '', '1440671072');
INSERT INTO `tv_img` VALUES ('109', './Uploads/eat/1440671074.jpg', '', '1440671074');
INSERT INTO `tv_img` VALUES ('110', './Uploads/eat/1440671379.jpg', '', '1440671379');
INSERT INTO `tv_img` VALUES ('111', './Uploads/eat/1440671433.jpg', '', '1440671433');
INSERT INTO `tv_img` VALUES ('112', './Uploads/eat/1440671813.jpg', '', '1440671813');
INSERT INTO `tv_img` VALUES ('113', './Uploads/play/1440671859.jpg', '', '1440671859');
INSERT INTO `tv_img` VALUES ('114', './Uploads/Room/1440723175.jpg', '', '1440723175');
INSERT INTO `tv_img` VALUES ('115', './Uploads/eat/1440723230.jpg', '', '1440723230');
INSERT INTO `tv_img` VALUES ('116', './Uploads/eat/1440723232.jpg', '', '1440723232');
INSERT INTO `tv_img` VALUES ('117', './Uploads/eat/1440723234.jpg', '', '1440723234');
INSERT INTO `tv_img` VALUES ('118', './Uploads/eat/1440723235.jpg', '', '1440723236');
INSERT INTO `tv_img` VALUES ('119', './Uploads/play/1440723344.jpg', '', '1440723345');
INSERT INTO `tv_img` VALUES ('120', './Uploads/eat/1440723709.jpg', '', '1440723710');
INSERT INTO `tv_img` VALUES ('121', './Uploads/eat/1440723711.jpg', '', '1440723711');
INSERT INTO `tv_img` VALUES ('122', './Uploads/eat/1440723714.jpg', '', '1440723714');
INSERT INTO `tv_img` VALUES ('123', './Uploads/eat/1440724441.jpg', '', '1440724441');
INSERT INTO `tv_img` VALUES ('124', './Uploads/eat/1440724443.jpg', '', '1440724443');
INSERT INTO `tv_img` VALUES ('125', './Uploads/eat/1440724445.jpg', '', '1440724445');
INSERT INTO `tv_img` VALUES ('126', './Uploads/eat/1440724450.jpg', '', '1440724450');
INSERT INTO `tv_img` VALUES ('127', './Uploads/eat/1440724452.jpg', '', '1440724452');
INSERT INTO `tv_img` VALUES ('128', './Uploads/eat/1440724456.jpg', '', '1440724456');
INSERT INTO `tv_img` VALUES ('129', './Uploads/eat/1440724461.jpg', '', '1440724461');
INSERT INTO `tv_img` VALUES ('130', './Uploads/eat/1440724463.jpg', '', '1440724463');
INSERT INTO `tv_img` VALUES ('131', './Uploads/eat/1440724466.jpg', '', '1440724466');
INSERT INTO `tv_img` VALUES ('132', './Uploads/eat/1440724718.jpg', '', '1440724718');
INSERT INTO `tv_img` VALUES ('133', './Uploads/eat/1440724937.jpg', '', '1440724938');
INSERT INTO `tv_img` VALUES ('134', './Uploads/eat/1440724993.jpg', '', '1440724993');
INSERT INTO `tv_img` VALUES ('135', './Uploads/eat/1440725090.jpg', '', '1440725090');
INSERT INTO `tv_img` VALUES ('136', './Uploads/eat/1440725348.jpg', '', '1440725348');
INSERT INTO `tv_img` VALUES ('137', './Uploads/eat/1440725352.jpg', '', '1440725352');
INSERT INTO `tv_img` VALUES ('138', './Uploads/eat/1440725354.jpg', '', '1440725354');
INSERT INTO `tv_img` VALUES ('139', './Uploads/eat/1440725537.jpg', '', '1440725537');
INSERT INTO `tv_img` VALUES ('140', './Uploads/eat/1440725576.jpg', '', '1440725576');
INSERT INTO `tv_img` VALUES ('141', './Uploads/eat/1440725580.jpg', '', '1440725580');
INSERT INTO `tv_img` VALUES ('142', './Uploads/eat/1440725591.jpg', '', '1440725591');
INSERT INTO `tv_img` VALUES ('143', './Uploads/eat/1440725602.jpg', '', '1440725603');
INSERT INTO `tv_img` VALUES ('144', './Uploads/eat/1440725611.jpg', '', '1440725611');
INSERT INTO `tv_img` VALUES ('145', './Uploads/eat/1440725618.jpg', '', '1440725619');
INSERT INTO `tv_img` VALUES ('146', './Uploads/eat/1440725648.jpg', '', '1440725648');
INSERT INTO `tv_img` VALUES ('147', './Uploads/eat/1440725652.jpg', '', '1440725652');
INSERT INTO `tv_img` VALUES ('148', './Uploads/eat/1440725657.jpg', '', '1440725657');
INSERT INTO `tv_img` VALUES ('149', './Uploads/eat/1440725660.jpg', '', '1440725660');
INSERT INTO `tv_img` VALUES ('150', './Uploads/eat/1440725859.jpg', '', '1440725859');
INSERT INTO `tv_img` VALUES ('151', './Uploads/eat/1440725862.jpg', '', '1440725863');
INSERT INTO `tv_img` VALUES ('152', './Uploads/eat/1440725876.jpg', '', '1440725876');
INSERT INTO `tv_img` VALUES ('153', './Uploads/eat/1440725878.jpg', '', '1440725879');
INSERT INTO `tv_img` VALUES ('154', './Uploads/eat/1440725882.jpg', '', '1440725882');
INSERT INTO `tv_img` VALUES ('155', './Uploads/eat/1440725884.jpg', '', '1440725885');
INSERT INTO `tv_img` VALUES ('156', './Uploads/eat/1440725888.jpg', '', '1440725888');
INSERT INTO `tv_img` VALUES ('157', './Uploads/eat/1440725891.jpg', '', '1440725891');
INSERT INTO `tv_img` VALUES ('158', './Uploads/eat/1440725894.jpg', '', '1440725894');
INSERT INTO `tv_img` VALUES ('159', './Uploads/eat/1440725897.jpg', '', '1440725897');
INSERT INTO `tv_img` VALUES ('160', './Uploads/eat/1440725906.jpg', '', '1440725906');
INSERT INTO `tv_img` VALUES ('161', './Uploads/eat/1440725912.jpg', '', '1440725912');
INSERT INTO `tv_img` VALUES ('162', './Uploads/eat/1440725916.jpg', '', '1440725916');
INSERT INTO `tv_img` VALUES ('163', './Uploads/eat/1440725927.jpg', '', '1440725928');
INSERT INTO `tv_img` VALUES ('164', './Uploads/eat/1440725933.jpg', '', '1440725933');
INSERT INTO `tv_img` VALUES ('165', './Uploads/eat/1440725936.jpg', '', '1440725936');
INSERT INTO `tv_img` VALUES ('166', './Uploads/eat/1440726050.jpg', '', '1440726050');
INSERT INTO `tv_img` VALUES ('167', './Uploads/eat/1440726056.jpg', '', '1440726057');
INSERT INTO `tv_img` VALUES ('168', './Uploads/eat/1440726066.jpg', '', '1440726066');
INSERT INTO `tv_img` VALUES ('169', './Uploads/eat/1440726068.jpg', '', '1440726069');
INSERT INTO `tv_img` VALUES ('170', './Uploads/Facilitator/1440726080.jpg', '', '1440726080');
INSERT INTO `tv_img` VALUES ('171', './Uploads/eat/1440726164.jpg', '', '1440726164');
INSERT INTO `tv_img` VALUES ('172', './Uploads/eat/1440726167.jpg', '', '1440726167');
INSERT INTO `tv_img` VALUES ('173', './Uploads/eat/1440726170.jpg', '', '1440726170');
INSERT INTO `tv_img` VALUES ('174', './Uploads/eat/1440726181.jpg', '', '1440726181');
INSERT INTO `tv_img` VALUES ('175', './Uploads/eat/1440726365.jpg', '', '1440726366');
INSERT INTO `tv_img` VALUES ('176', './Uploads/eat/1440726371.jpg', '', '1440726371');
INSERT INTO `tv_img` VALUES ('177', './Uploads/eat/1440726377.jpg', '', '1440726378');
INSERT INTO `tv_img` VALUES ('178', './Uploads/eat/1440726399.jpg', '', '1440726399');
INSERT INTO `tv_img` VALUES ('179', './Uploads/eat/1440726404.jpg', '', '1440726405');
INSERT INTO `tv_img` VALUES ('180', './Uploads/eat/1440726407.jpg', '', '1440726407');
INSERT INTO `tv_img` VALUES ('181', './Uploads/eat/1440726412.jpg', '', '1440726412');
INSERT INTO `tv_img` VALUES ('182', './Uploads/eat/1440726420.jpg', '', '1440726421');
INSERT INTO `tv_img` VALUES ('183', './Uploads/eat/1440726536.jpg', '', '1440726537');
INSERT INTO `tv_img` VALUES ('184', './Uploads/eat/1440726540.jpg', '', '1440726540');
INSERT INTO `tv_img` VALUES ('185', './Uploads/eat/1440726543.jpg', '', '1440726543');
INSERT INTO `tv_img` VALUES ('186', './Uploads/eat/1440726548.jpg', '', '1440726548');
INSERT INTO `tv_img` VALUES ('187', './Uploads/eat/1440726550.jpg', '', '1440726550');
INSERT INTO `tv_img` VALUES ('188', './Uploads/eat/1440726565.jpg', '', '1440726565');
INSERT INTO `tv_img` VALUES ('189', './Uploads/eat/1440726573.jpg', '', '1440726573');
INSERT INTO `tv_img` VALUES ('190', './Uploads/eat/1440726576.jpg', '', '1440726576');
INSERT INTO `tv_img` VALUES ('191', './Uploads/eat/1440726580.jpg', '', '1440726580');
INSERT INTO `tv_img` VALUES ('192', './Uploads/eat/1440726583.jpg', '', '1440726583');
INSERT INTO `tv_img` VALUES ('193', './Uploads/eat/1440726588.jpg', '', '1440726588');
INSERT INTO `tv_img` VALUES ('194', './Uploads/eat/1440726591.jpg', '', '1440726591');
INSERT INTO `tv_img` VALUES ('195', './Uploads/Room/1440727420.jpg', '', '1440727420');
INSERT INTO `tv_img` VALUES ('196', './Uploads/Room/1440727425.jpg', '', '1440727425');
INSERT INTO `tv_img` VALUES ('197', './Uploads/Room/1440727429.jpg', '', '1440727429');
INSERT INTO `tv_img` VALUES ('198', './Uploads/Room/1440727433.jpg', '', '1440727433');
INSERT INTO `tv_img` VALUES ('199', './Uploads/Room/1440727435.jpg', '', '1440727435');
INSERT INTO `tv_img` VALUES ('200', './Uploads/Room/1440727623.jpg', '', '1440727623');
INSERT INTO `tv_img` VALUES ('201', './Uploads/Room/1440727626.jpg', '', '1440727626');
INSERT INTO `tv_img` VALUES ('202', './Uploads/Room/1440727630.jpg', '', '1440727631');
INSERT INTO `tv_img` VALUES ('203', './Uploads/Room/1440727634.jpg', '', '1440727634');
INSERT INTO `tv_img` VALUES ('204', './Uploads/Room/1440727637.jpg', '', '1440727637');
INSERT INTO `tv_img` VALUES ('205', './Uploads/Room/1440727640.jpg', '', '1440727641');
INSERT INTO `tv_img` VALUES ('206', './Uploads/home/1440728012.jpg', '', '1440728012');
INSERT INTO `tv_img` VALUES ('207', './Uploads/home/1440728017.jpg', '', '1440728017');
INSERT INTO `tv_img` VALUES ('208', './Uploads/home/1440728019.jpg', '', '1440728019');
INSERT INTO `tv_img` VALUES ('209', './Uploads/home/1440728170.jpg', '', '1440728170');
INSERT INTO `tv_img` VALUES ('210', './Uploads/home/1440728172.jpg', '', '1440728172');
INSERT INTO `tv_img` VALUES ('211', './Uploads/home/1440728174.jpg', '', '1440728174');
INSERT INTO `tv_img` VALUES ('212', './Uploads/home/1440728176.jpg', '', '1440728176');
INSERT INTO `tv_img` VALUES ('213', './Uploads/home/1440728262.jpg', '', '1440728262');
INSERT INTO `tv_img` VALUES ('214', './Uploads/Room/1440728293.jpg', '', '1440728293');
INSERT INTO `tv_img` VALUES ('215', './Uploads/Room/1440728296.jpg', '', '1440728296');
INSERT INTO `tv_img` VALUES ('216', './Uploads/Room/1440728299.jpg', '', '1440728299');
INSERT INTO `tv_img` VALUES ('217', './Uploads/Room/1440728302.jpg', '', '1440728302');
INSERT INTO `tv_img` VALUES ('218', './Uploads/Room/1440728306.jpg', '', '1440728306');
INSERT INTO `tv_img` VALUES ('219', './Uploads/Room/1440728599.jpg', '', '1440728599');
INSERT INTO `tv_img` VALUES ('220', './Uploads/Room/1440728602.jpg', '', '1440728602');
INSERT INTO `tv_img` VALUES ('221', './Uploads/Room/1440728604.jpg', '', '1440728604');
INSERT INTO `tv_img` VALUES ('222', './Uploads/Room/1440728607.jpg', '', '1440728607');
INSERT INTO `tv_img` VALUES ('223', './Uploads/Room/1440728610.jpg', '', '1440728610');
INSERT INTO `tv_img` VALUES ('224', './Uploads/Room/1440728613.jpg', '', '1440728613');
INSERT INTO `tv_img` VALUES ('225', './Uploads/Room/1440728691.jpg', '', '1440728691');
INSERT INTO `tv_img` VALUES ('226', './Uploads/Room/1440728693.jpg', '', '1440728693');
INSERT INTO `tv_img` VALUES ('227', './Uploads/Room/1440729375.jpg', '', '1440729375');
INSERT INTO `tv_img` VALUES ('228', './Uploads/Room/1440730602.jpg', '', '1440730602');
INSERT INTO `tv_img` VALUES ('229', './Uploads/Room/1440730607.jpg', '', '1440730607');
INSERT INTO `tv_img` VALUES ('230', './Uploads/Room/1440730612.jpg', '', '1440730612');
INSERT INTO `tv_img` VALUES ('231', './Uploads/Room/1440730618.jpg', '', '1440730618');
INSERT INTO `tv_img` VALUES ('232', './Uploads/Room/1440730621.jpg', '', '1440730621');
INSERT INTO `tv_img` VALUES ('233', './Uploads/Room/1440730557.jpg', '', '1440730563');
INSERT INTO `tv_img` VALUES ('234', './Uploads/Room/1440730565.jpg', '', '1440730565');
INSERT INTO `tv_img` VALUES ('235', './Uploads/Room/1440730569.jpg', '', '1440730569');
INSERT INTO `tv_img` VALUES ('236', './Uploads/Room/1440730704.jpg', '', '1440730704');
INSERT INTO `tv_img` VALUES ('237', './Uploads/Room/1440730974.jpg', '', '1440730974');
INSERT INTO `tv_img` VALUES ('238', './Uploads/Room/1440730978.jpg', '', '1440730978');
INSERT INTO `tv_img` VALUES ('239', './Uploads/Room/1440730981.jpg', '', '1440730981');
INSERT INTO `tv_img` VALUES ('240', './Uploads/Room/1440730984.jpg', '', '1440730984');
INSERT INTO `tv_img` VALUES ('241', './Uploads/Room/1440730987.jpg', '', '1440730987');
INSERT INTO `tv_img` VALUES ('242', './Uploads/Room/1440731282.jpg', '', '1440731282');
INSERT INTO `tv_img` VALUES ('243', './Uploads/Room/1440731294.jpg', '', '1440731294');
INSERT INTO `tv_img` VALUES ('244', './Uploads/Room/1440731296.jpg', '', '1440731296');
INSERT INTO `tv_img` VALUES ('245', './Uploads/Room/1440731299.jpg', '', '1440731299');
INSERT INTO `tv_img` VALUES ('246', './Uploads/Room/1440731302.jpg', '', '1440731302');
INSERT INTO `tv_img` VALUES ('247', './Uploads/Room/1440731306.jpg', '', '1440731306');
INSERT INTO `tv_img` VALUES ('248', './Uploads/Room/1440731309.jpg', '', '1440731309');
INSERT INTO `tv_img` VALUES ('249', './Uploads/Room/1440731479.jpg', '', '1440731479');
INSERT INTO `tv_img` VALUES ('250', './Uploads/Room/1440731484.jpg', '', '1440731484');
INSERT INTO `tv_img` VALUES ('251', './Uploads/Room/1440731487.jpg', '', '1440731487');
INSERT INTO `tv_img` VALUES ('252', './Uploads/Room/1440731490.jpg', '', '1440731490');
INSERT INTO `tv_img` VALUES ('253', './Uploads/eat/1440731419.jpg', '', '1440731419');
INSERT INTO `tv_img` VALUES ('254', './Uploads/eat/1440731421.jpg', '', '1440731422');
INSERT INTO `tv_img` VALUES ('255', './Uploads/eat/1440731437.jpg', '', '1440731437');
INSERT INTO `tv_img` VALUES ('256', './Uploads/eat/1440731442.jpg', '', '1440731443');
INSERT INTO `tv_img` VALUES ('257', './Uploads/eat/1440731475.jpg', '', '1440731475');
INSERT INTO `tv_img` VALUES ('258', './Uploads/Room/1440731689.jpg', '', '1440731689');
INSERT INTO `tv_img` VALUES ('259', './Uploads/Room/1440731692.jpg', '', '1440731692');
INSERT INTO `tv_img` VALUES ('260', './Uploads/Room/1440731695.jpg', '', '1440731696');
INSERT INTO `tv_img` VALUES ('261', './Uploads/Room/1440731698.jpg', '', '1440731698');
INSERT INTO `tv_img` VALUES ('262', './Uploads/Room/1440731874.jpg', '', '1440731875');
INSERT INTO `tv_img` VALUES ('263', './Uploads/Room/1440731878.jpg', '', '1440731878');
INSERT INTO `tv_img` VALUES ('264', './Uploads/Room/1440731880.jpg', '', '1440731880');
INSERT INTO `tv_img` VALUES ('265', './Uploads/Room/1440731884.jpg', '', '1440731884');
INSERT INTO `tv_img` VALUES ('266', './Uploads/Room/1440731904.jpg', '', '1440731904');
INSERT INTO `tv_img` VALUES ('267', './Uploads/Room/1440731907.jpg', '', '1440731908');
INSERT INTO `tv_img` VALUES ('268', './Uploads/Room/1440731911.jpg', '', '1440731911');
INSERT INTO `tv_img` VALUES ('269', './Uploads/Room/1440731919.jpg', '', '1440731919');
INSERT INTO `tv_img` VALUES ('270', './Uploads/Room/1440731922.jpg', '', '1440731922');
INSERT INTO `tv_img` VALUES ('271', './Uploads/eat/1440731746.jpg', '', '1440731746');
INSERT INTO `tv_img` VALUES ('272', './Uploads/eat/1440731749.jpg', '', '1440731749');
INSERT INTO `tv_img` VALUES ('273', './Uploads/eat/1440731751.jpg', '', '1440731751');
INSERT INTO `tv_img` VALUES ('274', './Uploads/Room/1440731949.jpg', '', '1440731950');
INSERT INTO `tv_img` VALUES ('275', './Uploads/Room/1440731953.jpg', '', '1440731953');
INSERT INTO `tv_img` VALUES ('276', './Uploads/Room/1440733403.jpg', '', '1440733403');
INSERT INTO `tv_img` VALUES ('277', './Uploads/Room/1440733405.jpg', '', '1440733406');
INSERT INTO `tv_img` VALUES ('278', './Uploads/Room/1440734054.jpg', '', '1440734054');
INSERT INTO `tv_img` VALUES ('279', './Uploads/play/1440734377.jpg', '', '1440734377');
INSERT INTO `tv_img` VALUES ('280', './Uploads/play/1440734379.jpg', '', '1440734379');
INSERT INTO `tv_img` VALUES ('281', './Uploads/Room/1440735248.jpg', '', '1440735248');
INSERT INTO `tv_img` VALUES ('282', './Uploads/Room/1440735250.jpg', '', '1440735250');
INSERT INTO `tv_img` VALUES ('283', './Uploads/Room/1440735384.jpg', '', '1440735385');
INSERT INTO `tv_img` VALUES ('284', './Uploads/Room/1440735387.jpg', '', '1440735387');
INSERT INTO `tv_img` VALUES ('285', './Uploads/play/1440735779.jpg', '', '1440735779');
INSERT INTO `tv_img` VALUES ('286', './Uploads/play/1440735781.jpg', '', '1440735781');
INSERT INTO `tv_img` VALUES ('287', './Uploads/play/1440735823.jpg', '', '1440735823');
INSERT INTO `tv_img` VALUES ('288', './Uploads/play/1440743881.jpg', '', '1440743881');
INSERT INTO `tv_img` VALUES ('289', './Uploads/play/1440743890.jpg', '', '1440743890');
INSERT INTO `tv_img` VALUES ('290', './Uploads/play/1440743894.jpg', '', '1440743894');
INSERT INTO `tv_img` VALUES ('291', './Uploads/play/1440743898.jpg', '', '1440743898');
INSERT INTO `tv_img` VALUES ('292', './Uploads/play/1440743901.jpg', '', '1440743901');
INSERT INTO `tv_img` VALUES ('293', './Uploads/play/1440745174.jpg', '', '1440745174');
INSERT INTO `tv_img` VALUES ('294', './Uploads/play/1440745192.jpg', '', '1440745192');
INSERT INTO `tv_img` VALUES ('295', './Uploads/play/1440745309.jpg', '', '1440745309');
INSERT INTO `tv_img` VALUES ('296', './Uploads/play/1440745318.jpg', '', '1440745318');
INSERT INTO `tv_img` VALUES ('297', './Uploads/play/1440745326.jpg', '', '1440745326');
INSERT INTO `tv_img` VALUES ('298', './Uploads/play/1440745329.jpg', '', '1440745329');
INSERT INTO `tv_img` VALUES ('299', './Uploads/play/1440745333.jpg', '', '1440745333');
INSERT INTO `tv_img` VALUES ('300', './Uploads/play/1440745341.jpg', '', '1440745341');
INSERT INTO `tv_img` VALUES ('301', './Uploads/eat/1440745343.jpg', '', '1440745343');
INSERT INTO `tv_img` VALUES ('302', './Uploads/eat/1440745346.jpg', '', '1440745346');
INSERT INTO `tv_img` VALUES ('303', './Uploads/Room/1440745357.jpg', '', '1440745357');
INSERT INTO `tv_img` VALUES ('304', './Uploads/play/1440745368.jpg', '', '1440745368');
INSERT INTO `tv_img` VALUES ('305', './Uploads/play/1440745370.jpg', '', '1440745370');
INSERT INTO `tv_img` VALUES ('306', './Uploads/play/1440745452.jpg', '', '1440745452');
INSERT INTO `tv_img` VALUES ('307', './Uploads/play/1440745492.jpg', '', '1440745492');
INSERT INTO `tv_img` VALUES ('308', './Uploads/play/1440745616.jpg', '', '1440745616');
INSERT INTO `tv_img` VALUES ('309', './Uploads/play/1440745619.jpg', '', '1440745619');
INSERT INTO `tv_img` VALUES ('310', './Uploads/play/1440745626.jpg', '', '1440745627');
INSERT INTO `tv_img` VALUES ('311', './Uploads/play/1440745629.jpg', '', '1440745630');
INSERT INTO `tv_img` VALUES ('312', './Uploads/play/1440745635.jpg', '', '1440745635');
INSERT INTO `tv_img` VALUES ('313', './Uploads/play/1440745638.jpg', '', '1440745638');
INSERT INTO `tv_img` VALUES ('314', './Uploads/play/1440745542.jpg', '', '1440745543');
INSERT INTO `tv_img` VALUES ('315', './Uploads/play/1440747113.jpg', '', '1440747113');
INSERT INTO `tv_img` VALUES ('316', './Uploads/play/1440747120.jpg', '', '1440747121');
INSERT INTO `tv_img` VALUES ('317', './Uploads/play/1440747131.jpg', '', '1440747132');
INSERT INTO `tv_img` VALUES ('318', './Uploads/play/1440747138.jpg', '', '1440747138');
INSERT INTO `tv_img` VALUES ('319', './Uploads/play/1440747145.jpg', '', '1440747145');
INSERT INTO `tv_img` VALUES ('320', './Uploads/play/1440747151.jpg', '', '1440747151');
INSERT INTO `tv_img` VALUES ('321', './Uploads/play/1440747508.jpg', '', '1440747508');
INSERT INTO `tv_img` VALUES ('322', './Uploads/play/1440747512.jpg', '', '1440747512');
INSERT INTO `tv_img` VALUES ('323', './Uploads/play/1440747516.jpg', '', '1440747516');
INSERT INTO `tv_img` VALUES ('324', './Uploads/play/1440747519.jpg', '', '1440747519');
INSERT INTO `tv_img` VALUES ('325', './Uploads/play/1440747522.jpg', '', '1440747522');
INSERT INTO `tv_img` VALUES ('326', './Uploads/play/1440747525.jpg', '', '1440747525');
INSERT INTO `tv_img` VALUES ('327', './Uploads/play/1440747529.jpg', '', '1440747529');
INSERT INTO `tv_img` VALUES ('328', './Uploads/play/1440747813.png', '', '1440747813');
INSERT INTO `tv_img` VALUES ('329', './Uploads/play/1440747821.png', '', '1440747821');
INSERT INTO `tv_img` VALUES ('330', './Uploads/play/1440747824.jpg', '', '1440747824');
INSERT INTO `tv_img` VALUES ('331', './Uploads/play/1440747832.jpg', '', '1440747832');
INSERT INTO `tv_img` VALUES ('332', './Uploads/play/1440748039.jpg', '', '1440748040');
INSERT INTO `tv_img` VALUES ('333', './Uploads/play/1440748044.jpg', '', '1440748044');
INSERT INTO `tv_img` VALUES ('334', './Uploads/play/1440748048.jpg', '', '1440748048');
INSERT INTO `tv_img` VALUES ('335', './Uploads/play/1440748050.jpg', '', '1440748051');
INSERT INTO `tv_img` VALUES ('336', './Uploads/play/1440748053.jpg', '', '1440748053');
INSERT INTO `tv_img` VALUES ('337', './Uploads/eat/1440748725.jpg', '', '1440748725');
INSERT INTO `tv_img` VALUES ('338', './Uploads/eat/1440748732.jpg', '', '1440748732');
INSERT INTO `tv_img` VALUES ('339', './Uploads/eat/1440748737.jpg', '', '1440748737');
INSERT INTO `tv_img` VALUES ('340', './Uploads/eat/1440748746.jpg', '', '1440748746');
INSERT INTO `tv_img` VALUES ('341', './Uploads/eat/1440748762.jpg', '', '1440748763');
INSERT INTO `tv_img` VALUES ('342', './Uploads/eat/1440748767.jpg', '', '1440748768');
INSERT INTO `tv_img` VALUES ('343', './Uploads/eat/1440748777.jpg', '', '1440748777');
INSERT INTO `tv_img` VALUES ('344', './Uploads/eat/1440748789.jpg', '', '1440748790');
INSERT INTO `tv_img` VALUES ('345', './Uploads/Facilitator/1441008760.jpg', '', '1441008761');
INSERT INTO `tv_img` VALUES ('346', './Uploads/Facilitator/1441008763.jpg', '', '1441008763');
INSERT INTO `tv_img` VALUES ('347', './Uploads/Facilitator/1441008766.jpg', '', '1441008766');
INSERT INTO `tv_img` VALUES ('348', './Uploads/home/1441010300.jpg', '', '1441010300');
INSERT INTO `tv_img` VALUES ('349', './Uploads/home/1441010304.jpg', '', '1441010304');
INSERT INTO `tv_img` VALUES ('350', './Uploads/home/1441010307.jpg', '', '1441010307');
INSERT INTO `tv_img` VALUES ('351', './Uploads/home/1441010385.jpg', '', '1441010386');
INSERT INTO `tv_img` VALUES ('352', './Uploads/home/1441010388.jpg', '', '1441010389');
INSERT INTO `tv_img` VALUES ('353', './Uploads/home/1441010391.jpg', '', '1441010391');
INSERT INTO `tv_img` VALUES ('354', './Uploads/home/1441010609.jpg', '', '1441010609');
INSERT INTO `tv_img` VALUES ('355', './Uploads/home/1441010611.jpg', '', '1441010611');
INSERT INTO `tv_img` VALUES ('356', './Uploads/home/1441010614.jpg', '', '1441010614');
INSERT INTO `tv_img` VALUES ('357', './Uploads/home/1441010692.jpg', '', '1441010692');
INSERT INTO `tv_img` VALUES ('358', './Uploads/home/1441010696.jpg', '', '1441010696');
INSERT INTO `tv_img` VALUES ('359', './Uploads/home/1441010699.jpg', '', '1441010699');
INSERT INTO `tv_img` VALUES ('360', './Uploads/home/1441010702.jpg', '', '1441010703');
INSERT INTO `tv_img` VALUES ('361', './Uploads/home/1441010929.jpg', '', '1441010929');
INSERT INTO `tv_img` VALUES ('362', './Uploads/home/1441010935.jpg', '', '1441010935');
INSERT INTO `tv_img` VALUES ('363', './Uploads/home/1441010939.jpg', '', '1441010939');
INSERT INTO `tv_img` VALUES ('364', './Uploads/home/1441010941.jpg', '', '1441010941');
INSERT INTO `tv_img` VALUES ('365', './Uploads/news/1441103333.png', '', '1441103334');
INSERT INTO `tv_img` VALUES ('366', './Uploads/eat/1441537188.jpg', '', '1441537188');
INSERT INTO `tv_img` VALUES ('367', './Uploads/eat/1441537190.jpg', '', '1441537190');
INSERT INTO `tv_img` VALUES ('368', './Uploads/eat/1441537192.jpg', '', '1441537193');
INSERT INTO `tv_img` VALUES ('369', './Uploads/home/1441594306.png', '', '1441594311');
INSERT INTO `tv_img` VALUES ('370', './Uploads/home/1441594843.png', '', '1441594843');
INSERT INTO `tv_img` VALUES ('371', './Uploads/Facilitator/1441675995.jpg', '', '1441676000');
INSERT INTO `tv_img` VALUES ('372', './Uploads/Facilitator/1441676005.jpg', '', '1441676005');
INSERT INTO `tv_img` VALUES ('373', './Uploads/eat/1441760701.jpg', '', '1441760701');
INSERT INTO `tv_img` VALUES ('374', './Uploads/eat/1441760711.jpg', '', '1441760711');
INSERT INTO `tv_img` VALUES ('375', './Uploads/Room/1441764036.png', '', '1441764036');
INSERT INTO `tv_img` VALUES ('376', './Uploads/Room/1441764039.png', '', '1441764039');
INSERT INTO `tv_img` VALUES ('377', './Uploads/Room/1441768867.jpg', '', '1441768867');
INSERT INTO `tv_img` VALUES ('378', './Uploads/Room/1441768873.jpg', '', '1441768873');
INSERT INTO `tv_img` VALUES ('379', './Uploads/Room/1441768879.jpg', '', '1441768879');
INSERT INTO `tv_img` VALUES ('380', './Uploads/route/1441769364.jpg', '', '1441769364');
INSERT INTO `tv_img` VALUES ('381', './Uploads/Facilitator/1441770431.jpg', '', '1441770431');
INSERT INTO `tv_img` VALUES ('382', './Uploads/Facilitator/1441770435.jpg', '', '1441770435');
INSERT INTO `tv_img` VALUES ('383', './Uploads/Facilitator/1441770439.jpg', '', '1441770439');
INSERT INTO `tv_img` VALUES ('384', './Uploads/Room/1441770662.jpg', '', '1441770662');
INSERT INTO `tv_img` VALUES ('385', './Uploads/Facilitator/1441876698.jpg', '', '1441876699');
INSERT INTO `tv_img` VALUES ('386', './Uploads/Facilitator/1441876701.jpg', '', '1441876701');
INSERT INTO `tv_img` VALUES ('387', './Uploads/Facilitator/1441876703.jpg', '', '1441876703');
INSERT INTO `tv_img` VALUES ('388', './Uploads/news/1441941224.jpg', '', '1441941224');
INSERT INTO `tv_img` VALUES ('389', './Uploads/Room/1441962801.jpg', '', '1441962802');
INSERT INTO `tv_img` VALUES ('390', './Uploads/Room/1441962805.jpg', '', '1441962805');
INSERT INTO `tv_img` VALUES ('391', './Uploads/Room/1441962807.jpg', '', '1441962808');
INSERT INTO `tv_img` VALUES ('392', './Uploads/Facilitator/1442041951.jpg', '', '1442041951');
INSERT INTO `tv_img` VALUES ('393', './Uploads/Facilitator/1442041953.jpg', '', '1442041953');

-- -----------------------------
-- Table structure for `tv_lv_type`
-- -----------------------------
DROP TABLE IF EXISTS `tv_lv_type`;
CREATE TABLE `tv_lv_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '名称',
  `facilities_type` varchar(1) NOT NULL DEFAULT '0' COMMENT '1（房屋），2（餐饮），3（游玩），0（旅游类型）',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '品种',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态（0：禁用；1：启用；2：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_lv_type`
-- -----------------------------
INSERT INTO `tv_lv_type` VALUES ('5', '单人房,双人房,三人房,四人房', '1', '1', '1');
INSERT INTO `tv_lv_type` VALUES ('7', '实体床,上下床', '1', '3', '1');
INSERT INTO `tv_lv_type` VALUES ('8', '粤菜,面包甜点,小吃快餐,自助餐,咖啡厅,日本料理,火锅,西餐,烧烤,韩国料理,川菜,东南亚菜,湘菜,茶餐厅,江浙菜,东北菜,西北菜,素菜,新疆菜,创意菜,清真菜,其他\r\n', '2', '0', '1');
INSERT INTO `tv_lv_type` VALUES ('9', '海滩,游艇,漂流,日出', '3', '0', '1');
INSERT INTO `tv_lv_type` VALUES ('10', '空调,电视,电脑,宽带上网,厨房,生活必需品,无线网络,电话,热水浴缸,洗衣机,烘干机', '1', '2', '1');

-- -----------------------------
-- Table structure for `tv_member`
-- -----------------------------
DROP TABLE IF EXISTS `tv_member`;
CREATE TABLE `tv_member` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户ID',
  `face_max_url` varchar(100) DEFAULT NULL COMMENT '用户头像',
  `face_min_url` varchar(100) DEFAULT NULL COMMENT '用户小头像',
  `hobby_id` text COMMENT '爱好表id（用逗号隔开）',
  `realname` varchar(25) DEFAULT NULL COMMENT '真实姓名',
  `IDcard` varchar(25) DEFAULT NULL COMMENT '身份证号码',
  `nickname` varchar(20) DEFAULT NULL COMMENT '昵称',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别(0:保密；1:男；2:女)',
  `birthday` varchar(10) DEFAULT NULL COMMENT '生日',
  `qq` varchar(20) DEFAULT NULL COMMENT 'qq号',
  `score` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '用户积分',
  `login` varchar(10) NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` varchar(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` varchar(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) DEFAULT '0' COMMENT '最后登录时间',
  `update_time` int(10) DEFAULT NULL COMMENT '更新时间',
  `type` varchar(2) NOT NULL DEFAULT '1' COMMENT '用户类型（1：普通，2：服务商，3：管理员，4：vip）',
  `vip_id` varchar(10) DEFAULT '0' COMMENT 'Vip表id',
  `imei` bigint(30) DEFAULT '0' COMMENT 'imei',
  `mobile_model` varchar(30) DEFAULT '',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `ix_uid` (`uid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='会员表\r\n@author   麦当苗儿\r\n@version  2013-05-27';

-- -----------------------------
-- Records of `tv_member`
-- -----------------------------
INSERT INTO `tv_member` VALUES ('1', '', '', '', '', '', 'admin', '0', '0000-00-00', '3242342', '50.00', '124', '0', '1438751921', '2130706433', '1442025003', '', '1', '0', '0', '');
INSERT INTO `tv_member` VALUES ('45', '', '', '', '杨艺平1', '', '杨艺平1', '0', '0000-00-00', '', '10.00', '4', '2130706433', '1439800381', '2130706433', '1442045194', '1439975210', '2', '0', '0', '');
INSERT INTO `tv_member` VALUES ('44', '', '', '', '13049340998', '', '13049340998', '0', '0000-00-00', '', '0.00', '19', '2130706433', '1439255079', '2130706433', '1440748877', '', '1', '3', '0', '');
INSERT INTO `tv_member` VALUES ('42', '', '', '', '', '', '', '0', '0000-00-00', '', '10.00', '1', '2130706433', '1439202207', '2130706433', '1439202215', '', '1', '19', '0', '');
INSERT INTO `tv_member` VALUES ('41', '', '', '', '', '', 'calvin1', '0', '0000-00-00', '', '20.00', '4', '0', '0', '2005438120', '1441018229', '', '2', '0', '0', '');
INSERT INTO `tv_member` VALUES ('43', '', '', '', '', '', 'calvin3', '0', '0000-00-00', '', '20.00', '2', '2130706433', '1439202374', '2130706433', '1439773842', '1439973099', '1', '2', '0', '');
INSERT INTO `tv_member` VALUES ('48', '', '', '', '12', '', 'asdasd', '0', '', '', '20.00', '16', '2130706433', '1440233679', '2005438120', '1441009060', '', '1', '0', '0', '');
INSERT INTO `tv_member` VALUES ('49', '33', '', '', '杨艺平', '440223199355555', '杨艺平', '0', '', '', '0.00', '17', '2130706433', '1440571084', '2130706433', '1441771362', '', '1', '0', '0', '');
INSERT INTO `tv_member` VALUES ('50', '', '', '', '', '', '', '0', '', '', '0.00', '1', '2005438120', '1441014355', '2005438120', '1441014355', '', '1', '0', '0', 'iPhone');
INSERT INTO `tv_member` VALUES ('51', '', '', '', '完全额外', '', '完全额外', '0', '', '', '0.00', '1', '2005438120', '1441017445', '2005438120', '1441017445', '', '1', '0', '0', '');

-- -----------------------------
-- Table structure for `tv_member_vip`
-- -----------------------------
DROP TABLE IF EXISTS `tv_member_vip`;
CREATE TABLE `tv_member_vip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL COMMENT '用户id',
  `vip_id` varchar(10) DEFAULT NULL COMMENT 'Vip类型id',
  `start_date` varchar(10) NOT NULL COMMENT '开始日期',
  `end_date` varchar(10) NOT NULL COMMENT '结束日期',
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '状态（0：禁用；1：启用；2：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_member_vip`
-- -----------------------------
INSERT INTO `tv_member_vip` VALUES ('2', '43', '20', '1441123200', '1441296000', '1');
INSERT INTO `tv_member_vip` VALUES ('3', '44', '21', '1441814400', '1443542400', '1');

-- -----------------------------
-- Table structure for `tv_menu`
-- -----------------------------
DROP TABLE IF EXISTS `tv_menu`;
CREATE TABLE `tv_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_menu`
-- -----------------------------
INSERT INTO `tv_menu` VALUES ('1', '首页', '0', '0', 'Index/index', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('2', '文章', '0', '3', 'Home/inforlist', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '1', '', '', '0');
INSERT INTO `tv_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('16', '用户', '0', '2', 'User/index', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('17', '用户列表', '16', '0', 'User/index', '0', '', '注册用户', '0');
INSERT INTO `tv_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用户', '', '0');
INSERT INTO `tv_menu` VALUES ('19', '用户行为', '16', '0', 'User/action', '1', '', '注册用户', '0');
INSERT INTO `tv_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addAction', '0', '\"用户->用户行为\"中的新增', '', '0');
INSERT INTO `tv_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editAction', '0', '\"用户->用户行为\"点击标题进行编辑', '', '0');
INSERT INTO `tv_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0');
INSERT INTO `tv_menu` VALUES ('23', '变更行为状态', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0');
INSERT INTO `tv_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0');
INSERT INTO `tv_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0');
INSERT INTO `tv_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0');
INSERT INTO `tv_menu` VALUES ('27', '权限管理', '16', '0', 'AuthManager/index', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0');
INSERT INTO `tv_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0');
INSERT INTO `tv_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0');
INSERT INTO `tv_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0');
INSERT INTO `tv_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0');
INSERT INTO `tv_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0');
INSERT INTO `tv_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0');
INSERT INTO `tv_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0');
INSERT INTO `tv_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0');
INSERT INTO `tv_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0');
INSERT INTO `tv_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0');
INSERT INTO `tv_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0');
INSERT INTO `tv_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0');
INSERT INTO `tv_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0');
INSERT INTO `tv_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0');
INSERT INTO `tv_menu` VALUES ('44', '插件管理', '43', '0', 'Addons/index', '0', '', '扩展', '0');
INSERT INTO `tv_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0');
INSERT INTO `tv_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0');
INSERT INTO `tv_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0');
INSERT INTO `tv_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0');
INSERT INTO `tv_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0');
INSERT INTO `tv_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0');
INSERT INTO `tv_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0');
INSERT INTO `tv_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0');
INSERT INTO `tv_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0');
INSERT INTO `tv_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0');
INSERT INTO `tv_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0');
INSERT INTO `tv_menu` VALUES ('57', '钩子管理', '43', '0', 'Addons/hooks', '0', '', '扩展', '0');
INSERT INTO `tv_menu` VALUES ('58', '模型管理', '68', '0', 'Model/index', '0', '', '系统设置', '0');
INSERT INTO `tv_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('63', '属性管理', '68', '0', 'Attribute/index', '1', '', '', '0');
INSERT INTO `tv_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('68', '系统', '0', '4', 'Config/group', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('69', '网站设置', '68', '0', 'Config/group', '0', '', '系统设置', '0');
INSERT INTO `tv_menu` VALUES ('70', '配置管理', '68', '0', 'Config/index', '0', '', '系统设置', '0');
INSERT INTO `tv_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0');
INSERT INTO `tv_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0');
INSERT INTO `tv_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0');
INSERT INTO `tv_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0');
INSERT INTO `tv_menu` VALUES ('75', '菜单管理', '68', '0', 'Menu/index', '0', '', '系统设置', '0');
INSERT INTO `tv_menu` VALUES ('76', '导航管理', '68', '0', 'Channel/index', '0', '', '系统设置', '0');
INSERT INTO `tv_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('80', '分类管理', '68', '0', 'Category/index', '0', '', '系统设置', '0');
INSERT INTO `tv_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0');
INSERT INTO `tv_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0');
INSERT INTO `tv_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0');
INSERT INTO `tv_menu` VALUES ('84', '移动', '80', '0', 'Category/move', '0', '移动栏目分类', '', '0');
INSERT INTO `tv_menu` VALUES ('85', '合并', '80', '0', 'Category/merge', '0', '合并栏目分类', '', '0');
INSERT INTO `tv_menu` VALUES ('86', '备份数据库', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0');
INSERT INTO `tv_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0');
INSERT INTO `tv_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0');
INSERT INTO `tv_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0');
INSERT INTO `tv_menu` VALUES ('90', '还原数据库', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0');
INSERT INTO `tv_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0');
INSERT INTO `tv_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0');
INSERT INTO `tv_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0');
INSERT INTO `tv_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('102', '应用', '0', '5', 'Think/lists?model=config', '1', '', '', '0');
INSERT INTO `tv_menu` VALUES ('104', '下载管理', '102', '0', 'Think/lists?model=download', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('105', '配置管理', '102', '0', 'Think/lists?model=config', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '0', '', '行为管理', '0');
INSERT INTO `tv_menu` VALUES ('108', '修改密码', '16', '0', 'User/updatePassword', '1', '', '', '0');
INSERT INTO `tv_menu` VALUES ('109', '修改昵称', '16', '0', 'User/updateNickname', '1', '', '', '0');
INSERT INTO `tv_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0');
INSERT INTO `tv_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0');
INSERT INTO `tv_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0');
INSERT INTO `tv_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('121', '订单', '0', '2', 'Order/ordlist', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('126', 'VIP用户', '16', '0', 'vip/user', '0', '', 'VIP管理', '0');
INSERT INTO `tv_menu` VALUES ('127', 'VIP类目', '16', '0', 'vip/category', '0', '', 'VIP管理', '0');
INSERT INTO `tv_menu` VALUES ('128', '服务商', '16', '0', 'facilitator/index', '0', '', '服务商管理', '0');
INSERT INTO `tv_menu` VALUES ('129', '新增类目', '127', '0', 'vip/add', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('130', '新增vip用户', '126', '0', 'vip/user_add', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('131', '编辑类目', '127', '0', 'vip/edit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('132', '编辑vip用户', '126', '0', 'vip/user_edit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('133', '新增服务商用户', '128', '0', 'facilitator/add', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('134', '编辑服务商用户', '128', '0', 'facilitator/edit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('135', '积分进出', '16', '0', 'Points/uslist', '0', '', '积分管理', '0');
INSERT INTO `tv_menu` VALUES ('136', '产品', '0', '0', 'Product/rmlist', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('137', '房源列表', '136', '0', 'Product/rmlist', '0', '', '产品管理', '0');
INSERT INTO `tv_menu` VALUES ('138', '类目列表', '136', '0', 'Product/lvlist', '0', '', '产品类目管理', '0');
INSERT INTO `tv_menu` VALUES ('140', '新增产品栏目', '138', '0', 'product/lvadd', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('141', '编辑产品类目', '138', '0', 'product/lvedit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('142', '添加房源', '137', '0', 'product/rmadd', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('143', '编辑房源', '137', '0', 'product/rmedit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('144', '餐饮列表', '136', '0', 'Product/eatlist', '0', '', '产品管理', '0');
INSERT INTO `tv_menu` VALUES ('145', '游玩列表', '136', '0', 'Product/pylist', '0', '', '产品管理', '0');
INSERT INTO `tv_menu` VALUES ('146', '添加景点', '145', '0', 'product/pyadd', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('147', '编辑景点', '145', '0', 'product/pyedit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('148', '添加餐饮', '144', '0', 'product/eatadd', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('149', '编辑餐饮', '144', '0', 'product/eatedit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('150', '订单列表', '121', '0', 'Order/ordlist', '0', '', '订单管理', '0');
INSERT INTO `tv_menu` VALUES ('151', '线路列表', '136', '0', 'product/relist', '0', '', '产品管理', '0');
INSERT INTO `tv_menu` VALUES ('162', '新增', '151', '0', 'product/readd', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('163', '新增活动', '151', '0', 'product/re_pro_add', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('164', '编辑', '151', '0', 'product/reedit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('165', '首页路线图片列表', '2', '0', 'Home/index', '0', '', '平台配置管理', '0');
INSERT INTO `tv_menu` VALUES ('166', '前台产品类型图', '2', '0', 'Home/protyp', '0', '', '平台配置管理', '0');
INSERT INTO `tv_menu` VALUES ('167', '编辑活动', '151', '0', 'Product/re_pro_edit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('168', '文章列表', '2', '0', 'Home/inforList', '0', '', '文章管理', '0');
INSERT INTO `tv_menu` VALUES ('169', '新增文章', '168', '0', 'Home/inforadd', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('170', '分类列表', '2', '1', 'Home/news_sort', '0', '', '文章管理', '0');
INSERT INTO `tv_menu` VALUES ('171', '新增/编辑', '170', '0', 'Home/news_sort_add', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('172', '编辑文章', '168', '0', 'home/inforedit', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('173', '平台LOGO', '2', '0', 'Home/site_logo', '0', '', '平台配置管理', '0');
INSERT INTO `tv_menu` VALUES ('174', '消息', '0', '0', 'Message/index', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('175', '消息列表', '174', '0', 'Message/index', '0', '', '消息管理', '0');
INSERT INTO `tv_menu` VALUES ('176', '发送新消息', '175', '0', 'Message/sendmsg', '0', '', '', '0');
INSERT INTO `tv_menu` VALUES ('177', '美景贴图', '2', '0', 'home/travel', '0', '', '文章管理', '0');
INSERT INTO `tv_menu` VALUES ('178', '订单详细', '150', '0', 'order/ord_detail', '0', '', '', '0');

-- -----------------------------
-- Table structure for `tv_message`
-- -----------------------------
DROP TABLE IF EXISTS `tv_message`;
CREATE TABLE `tv_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL COMMENT '发件人id',
  `receiver_id` int(11) NOT NULL COMMENT '收件人id',
  `send_time` varchar(11) NOT NULL COMMENT '发送时间',
  `read_flag` tinyint(1) NOT NULL DEFAULT '1' COMMENT '已读标记(1:未读2:已读)',
  `message_text_id` varchar(11) NOT NULL COMMENT '这里把消息正文内容换成消息正文Id',
  `status` int(1) DEFAULT NULL COMMENT '状态(2:删除)',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_message`
-- -----------------------------
INSERT INTO `tv_message` VALUES ('9', '41', '49', '1441613741', '1', '9', '');
INSERT INTO `tv_message` VALUES ('8', '49', '41', '1441613658', '1', '8', '');
INSERT INTO `tv_message` VALUES ('14', '1', '44', '1441693501', '1', '13', '');
INSERT INTO `tv_message` VALUES ('10', '1', '49', '1441613828', '1', '10', '');
INSERT INTO `tv_message` VALUES ('11', '1', '41', '1441678690', '1', '11', '');
INSERT INTO `tv_message` VALUES ('12', '1', '43', '1441678690', '1', '15', '');
INSERT INTO `tv_message` VALUES ('13', '1', '49', '1441679908', '1', '12', '');
INSERT INTO `tv_message` VALUES ('15', '1', '48', '1441693501', '1', '13', '');
INSERT INTO `tv_message` VALUES ('16', '1', '49', '1441697450', '1', '14', '');
INSERT INTO `tv_message` VALUES ('17', '1', '44', '1441698765', '1', '15', '');

-- -----------------------------
-- Table structure for `tv_message_text`
-- -----------------------------
DROP TABLE IF EXISTS `tv_message_text`;
CREATE TABLE `tv_message_text` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL COMMENT '发送者ID',
  `message_title` varchar(255) DEFAULT NULL COMMENT '发送标题',
  `message_text` text NOT NULL COMMENT '消息正文',
  `type` varchar(2) NOT NULL DEFAULT '1' COMMENT '消息类型(1:普通消息;2:系统消息)',
  `status` int(1) DEFAULT NULL COMMENT '状态(2:删除)',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_message_text`
-- -----------------------------
INSERT INTO `tv_message_text` VALUES ('5', '5', '', '你好啊', '1', '');
INSERT INTO `tv_message_text` VALUES ('10', '1', '', 'yangyiping ', '1', '');
INSERT INTO `tv_message_text` VALUES ('9', '1', '', 'yangyiping ', '1', '');
INSERT INTO `tv_message_text` VALUES ('8', '1', '', 'yangyiping ', '1', '');
INSERT INTO `tv_message_text` VALUES ('7', '0', '', '你猜我是谁', '1', '');
INSERT INTO `tv_message_text` VALUES ('11', '1', '', '23', '1', '');
INSERT INTO `tv_message_text` VALUES ('12', '1', '海乐游系统通知', 'hjhjh', '1', '');
INSERT INTO `tv_message_text` VALUES ('13', '1', '系统公告', '<p><strong>非法所得大赛发送颠覆速度</strong></p>', '2', '');
INSERT INTO `tv_message_text` VALUES ('14', '1', 'wo ai ', '<h1>dfsdfdsfsdfsdf<br/></h1><p><strong>dfsfdsfsdfdsfdsfsd</strong><br/></p><p><strong><br/></strong></p><p><span style=\"text-decoration: underline;\">dfdsfdsfsdfsdfdsfsdfsdfsdfsd</span><span style=\"text-decoration: none;\"></span><strong><br/></strong></p><p><span style=\"text-decoration: line-through;\">fdsffdsfdsfsdf</span></p>', '2', '');
INSERT INTO `tv_message_text` VALUES ('15', '1', '3423423423423', '<p><img src=\"/ueditor/php/upload/image/20150908/1441698754782360.jpg\" title=\"1441698754782360.jpg\" alt=\"1.jpg\"/>急啊急啊急啊急啊急啊急啊急啊急啊</p>', '2', '');

-- -----------------------------
-- Table structure for `tv_model`
-- -----------------------------
DROP TABLE IF EXISTS `tv_model`;
CREATE TABLE `tv_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text NOT NULL COMMENT '属性列表（表的字段）',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text NOT NULL COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='文档模型表\r\n@author   麦当苗儿\r\n@version  2013-06-19';

-- -----------------------------
-- Records of `tv_model`
-- -----------------------------
INSERT INTO `tv_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\"]}', '1:基础', '', '', '', '', 'id:编号\r\ntitle:标题:article/index?cate_id=[category_id]&pid=[id]\r\ntype|get_document_type:类型\r\nlevel:优先级\r\nupdate_time|time_format:最后更新\r\nstatus_text:状态\r\nview:浏览\r\nid:操作:[EDIT]&cate_id=[category_id]|编辑,article/setstatus?status=-1&ids=[id]|删除', '0', '', '', '1383891233', '1384507827', '1');
INSERT INTO `tv_model` VALUES ('2', 'article', '文章文档', '1', '', '1', '{\"1\":[\"3\",\"2\",\"5\",\"24\"],\"2\":[\"23\",\"14\",\"25\",\"11\",\"9\",\"15\",\"16\",\"10\",\"17\",\"19\",\"13\",\"20\",\"12\",\"26\"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题:article/edit?cate_id=[category_id]&id=[id]\r\ncontent:内容', '0', '', '', '1383891243', '1384743355', '1');
INSERT INTO `tv_model` VALUES ('3', 'download', '下载文档', '1', '', '1', '{\"1\":[\"29\",\"3\",\"2\",\"5\",\"27\",\"28\",\"30\",\"9\",\"10\",\"12\",\"15\",\"14\",\"11\",\"13\",\"31\",\"17\",\"16\",\"19\",\"32\",\"20\"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题', '0', '', '', '1383891252', '1385714025', '1');
INSERT INTO `tv_model` VALUES ('4', 'action', '行为定义', '0', '', '1', '{\"1\":[\"33\",\"34\",\"35\",\"36\",\"37\",\"38\",\"39\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891262', '1383891784', '1');
INSERT INTO `tv_model` VALUES ('5', 'action_log', '行为日志', '0', '', '1', '{\"1\":[\"40\",\"41\",\"42\",\"43\",\"44\",\"45\",\"46\",\"47\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891340', '1383891802', '1');
INSERT INTO `tv_model` VALUES ('6', 'addons', '插件', '0', '', '1', '{\"1\":[\"48\",\"49\",\"50\",\"51\",\"52\",\"53\",\"54\",\"55\",\"56\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891396', '1383891828', '1');
INSERT INTO `tv_model` VALUES ('7', 'attachment', '附件', '0', '', '1', '{\"1\":[\"57\",\"58\",\"59\",\"60\",\"61\",\"62\",\"63\",\"64\",\"65\",\"66\",\"67\",\"68\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891410', '1383891847', '1');
INSERT INTO `tv_model` VALUES ('8', 'attribute', '属性', '0', '', '1', '{\"1\":[\"69\",\"70\",\"71\",\"72\",\"73\",\"74\",\"75\",\"76\",\"77\",\"78\",\"79\",\"80\",\"81\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891441', '1383891888', '1');
INSERT INTO `tv_model` VALUES ('9', 'category', '分类', '0', '', '1', '{\"1\":[\"82\",\"83\",\"84\",\"85\",\"86\",\"87\",\"88\",\"89\",\"90\",\"91\",\"92\",\"93\",\"94\",\"95\",\"96\",\"97\",\"98\",\"99\",\"100\",\"101\",\"102\",\"103\",\"104\",\"105\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891453', '1383891904', '1');
INSERT INTO `tv_model` VALUES ('10', 'channel', '前台菜单', '0', '', '1', '{\"1\":[\"106\",\"107\",\"108\",\"109\",\"110\",\"111\",\"112\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891460', '1383891939', '1');
INSERT INTO `tv_model` VALUES ('11', 'config', '配置', '0', '', '1', '{\"1\":[\"113\",\"114\",\"115\",\"116\",\"117\",\"118\",\"119\",\"120\",\"121\",\"122\",\"123\"]}', '1:基础', '', '', '', '', 'id:编号\r\nname:名称:edit?id=[id]&model=[MODEL]\r\ntitle:配置', '0', 'title|name', '', '1383891466', '1384248402', '1');
INSERT INTO `tv_model` VALUES ('12', 'file', '文件上传', '0', '', '1', '{\"1\":[\"124\",\"125\",\"126\",\"127\",\"128\",\"129\",\"130\",\"131\",\"132\",\"133\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891474', '1383891964', '1');
INSERT INTO `tv_model` VALUES ('13', 'hooks', '钩子', '0', '', '1', '{\"1\":[\"134\",\"135\",\"136\",\"137\",\"138\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891480', '1384495820', '1');
INSERT INTO `tv_model` VALUES ('14', 'member', '用户信息', '0', '', '1', '{\"1\":[\"139\",\"140\",\"141\",\"142\",\"143\",\"144\",\"145\",\"146\",\"147\",\"148\",\"149\",\"150\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891488', '1384151998', '1');
INSERT INTO `tv_model` VALUES ('15', 'menu', '后台菜单', '0', '', '1', '{\"1\":[\"151\",\"152\",\"153\",\"154\",\"155\",\"156\",\"157\",\"158\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891503', '1383892107', '1');
INSERT INTO `tv_model` VALUES ('16', 'model', '模型', '0', '', '1', '{\"1\":[\"159\",\"160\",\"161\",\"162\",\"163\",\"164\",\"165\",\"166\",\"167\",\"168\",\"169\",\"170\",\"171\",\"172\",\"173\",\"174\",\"175\",\"176\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891514', '1383892121', '1');
INSERT INTO `tv_model` VALUES ('17', 'picture', '图片上传', '0', '', '1', '{\"1\":[\"177\",\"178\",\"179\",\"180\",\"181\",\"182\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891522', '1383892140', '1');
INSERT INTO `tv_model` VALUES ('18', 'url', '链接管理', '0', '', '1', '{\"1\":[\"183\",\"184\",\"185\",\"186\"]}', '1:基础', '', '', '', '', 'id:编号', '0', '', '', '1383891531', '1385617833', '1');

-- -----------------------------
-- Table structure for `tv_news`
-- -----------------------------
DROP TABLE IF EXISTS `tv_news`;
CREATE TABLE `tv_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户id',
  `logo_img_url` varchar(50) NOT NULL COMMENT '文章封面图',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `news_sort_id` varchar(11) DEFAULT NULL COMMENT '分类id',
  `insert_time` varchar(10) NOT NULL COMMENT '添加时间',
  `publisher` varchar(20) DEFAULT NULL COMMENT '发布人',
  `content` text NOT NULL COMMENT '内容',
  `address` varchar(20) DEFAULT NULL COMMENT '所在地',
  `sort` varchar(2) NOT NULL DEFAULT '0' COMMENT '排序',
  `stick` varchar(1) DEFAULT '0' COMMENT '是否置顶',
  `type` varchar(2) NOT NULL DEFAULT '1' COMMENT '文章类型',
  `status` varchar(1) NOT NULL DEFAULT '1' COMMENT '状态(0:禁用；1:已发布2:删除)',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_news`
-- -----------------------------
INSERT INTO `tv_news` VALUES ('1', '1', '95', '王夏大酒店1', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('13', '1', '95', '王夏大酒店2', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('2', '1', '324', '渔技真炭火烤鱼', '2', '1441019963', '杨艺平', '<p>你猜</p>', '珠海', '0', '1', '2', '1');
INSERT INTO `tv_news` VALUES ('3', '1', '89', '闲钱宝简介', '1', '1441039562', 'fack大魔王', '<p>&nbsp;&nbsp;&nbsp;&nbsp;闲钱宝<br/></p><p>&nbsp;&nbsp;&nbsp;&nbsp;投资理财三十年，现已出山<br/></p><p>&nbsp;&nbsp;&nbsp;&nbsp;大家快来投标啦，快点来啦哦哦哦哦<br/></p>', '中山', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('4', '1', '89', '你猜', '1', '1441103359', '王亚雄', '<p>我晕</p>', '北京', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('5', '1', '95', '渔技真炭火烤鱼3', '2', '1441025641', '杨艺平', '<p>你猜</p>', '深圳', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('6', '1', '95', '渔技真炭火烤鱼4', '2', '1441015215', '杨艺平', '<p>你猜</p>', '广州', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('7', '1', '89', '渔技真炭火烤鱼', '2', '1441037541', '杨艺平', '<p>你猜</p>', '上海', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('8', '1', '119', '渔技真炭清蒸鱼', '2', '1441019965', '杨艺平', '<p>你猜</p>', '天津', '0', '1', '2', '1');
INSERT INTO `tv_news` VALUES ('9', '1', '100', '渔技真炭水煮鱼', '2', '1441019964', '杨艺平', '<p>你猜</p>', '北京', '0', '1', '2', '1');
INSERT INTO `tv_news` VALUES ('11', '1', '388', '312123', '', '1441941229', 'admin', '<p>3213123123123</p>', '', '0', '', '1', '1');
INSERT INTO `tv_news` VALUES ('12', '1', '89', '渔技真炭烤鱼', '2', '1441037541', '杨艺平', '<p>你猜</p>', '长沙', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('14', '1', '95', '王夏大酒店5', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('15', '1', '95', '王夏大酒店6', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('16', '1', '95', '王夏大酒店7', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('17', '1', '95', '王夏大酒店8', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('18', '1', '95', '王夏大酒店9', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('19', '1', '95', '王夏大酒店10', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('20', '1', '95', '王夏大酒店11', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('21', '1', '95', '王夏大酒店12', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('22', '1', '95', '王夏大酒店13', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('23', '1', '95', '王夏大酒店14', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('24', '1', '95', '王夏大酒店15', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('25', '1', '95', '王夏大酒店16', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('26', '1', '95', '王夏大酒店17', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('27', '1', '95', '王夏大酒店18', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('28', '1', '95', '王夏大酒店19', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('29', '1', '95', '王夏大酒店20', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');
INSERT INTO `tv_news` VALUES ('30', '1', '95', '王夏大酒店21', '1', '1441017912', '王亚雄', '<p>你猜我猜不猜</p>', '武汉', '0', '0', '2', '1');

-- -----------------------------
-- Table structure for `tv_news_sort`
-- -----------------------------
DROP TABLE IF EXISTS `tv_news_sort`;
CREATE TABLE `tv_news_sort` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '新闻分类id',
  `name` varchar(200) DEFAULT NULL COMMENT '分类名',
  `pid` varchar(11) DEFAULT NULL COMMENT '上级分类id',
  `sort_type` varchar(2) NOT NULL DEFAULT '1' COMMENT '所属级别',
  `status` varchar(1) NOT NULL DEFAULT '1' COMMENT '状态（0:禁用；1:启用；2:删除）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_news_sort`
-- -----------------------------
INSERT INTO `tv_news_sort` VALUES ('1', '平台公告', '', '1', '1');
INSERT INTO `tv_news_sort` VALUES ('2', '子类目', '1', '2', '1');

-- -----------------------------
-- Table structure for `tv_order`
-- -----------------------------
DROP TABLE IF EXISTS `tv_order`;
CREATE TABLE `tv_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `pro_order_id` int(11) DEFAULT NULL COMMENT '产品订单id',
  `number` varchar(15) DEFAULT NULL COMMENT '订单号',
  `only_number` varchar(20) DEFAULT NULL COMMENT '订单唯一编号',
  `title` varchar(100) DEFAULT NULL COMMENT '订单名',
  `pay_type` tinyint(4) DEFAULT NULL COMMENT '支付类型(0:线下支付,1:支付宝支付)',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态(0:代收费,1:已收费,2:删除,3:管理员删除;4:已使用)',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_order`
-- -----------------------------
INSERT INTO `tv_order` VALUES ('12', '12', '442015091019333', '', '美食', '', '0');
INSERT INTO `tv_order` VALUES ('11', '11', '442015091019211', '', '美食', '', '0');
INSERT INTO `tv_order` VALUES ('10', '10', '492015091018272', '', '现金券', '', '1');
INSERT INTO `tv_order` VALUES ('8', '9', '442015091017593', '', '住宿', '', '0');
INSERT INTO `tv_order` VALUES ('13', '13', '442015091019473', '', '美食', '', '1');
INSERT INTO `tv_order` VALUES ('14', '14', '442015091019481', '', '美食', '', '1');
INSERT INTO `tv_order` VALUES ('15', '15', '442015091020061', '', '景点', '', '0');
INSERT INTO `tv_order` VALUES ('16', '16', '442015091020111', '', '路线', '', '0');
INSERT INTO `tv_order` VALUES ('17', '17', '442015091109232', '', '路线', '', '0');
INSERT INTO `tv_order` VALUES ('18', '18', '', '', '', '', '0');

-- -----------------------------
-- Table structure for `tv_picture`
-- -----------------------------
DROP TABLE IF EXISTS `tv_picture`;
CREATE TABLE `tv_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `upload_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `tv_play`
-- -----------------------------
DROP TABLE IF EXISTS `tv_play`;
CREATE TABLE `tv_play` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '商家用户id',
  `logo_img_url` varchar(100) NOT NULL COMMENT '封面图片',
  `attractions_img_url` tinytext COMMENT '景点图片（限制6张）标明景点名字 ',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `name` varchar(255) DEFAULT NULL COMMENT '景点名称',
  `introduce` text COMMENT '介绍',
  `play_strategy` text COMMENT '游玩攻略',
  `play_time` varchar(4) DEFAULT NULL COMMENT '建议游玩时间',
  `sper_capita` text COMMENT '温馨提示',
  `contact` varchar(25) NOT NULL COMMENT '联系人',
  `tel` varchar(20) NOT NULL COMMENT '联系电话',
  `price` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '价格/人',
  `vip_price` tinytext COMMENT 'Vip价格/人',
  `favorable_price` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '优惠价',
  `type` tinytext NOT NULL COMMENT '景点类型',
  `provinces` varchar(10) NOT NULL COMMENT '省',
  `citys` varchar(10) DEFAULT NULL COMMENT '市',
  `countys` varchar(10) DEFAULT NULL COMMENT '区',
  `address` varchar(255) NOT NULL COMMENT '所在地址',
  `insert_time` varchar(10) NOT NULL COMMENT '生成时间',
  `update_time` varchar(10) DEFAULT NULL COMMENT '更新时间',
  `sort` varchar(5) NOT NULL DEFAULT '0' COMMENT '排序',
  `look_number` int(11) NOT NULL COMMENT '已看人数',
  `pro_type` int(1) NOT NULL DEFAULT '3',
  `status` varchar(2) NOT NULL DEFAULT '3' COMMENT '状态（0：下架；1：启用；2：删除;3：待通过；4：不通过）',
  `nearby_traffic` tinytext COMMENT '附近交通',
  `praise_number` int(11) NOT NULL COMMENT '已赞人数',
  `star` varchar(1) NOT NULL DEFAULT '0' COMMENT '星级',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='游玩产品';

-- -----------------------------
-- Records of `tv_play`
-- -----------------------------
INSERT INTO `tv_play` VALUES ('1', '1', '288', '289,290,291,292,', '珠海长隆海洋王国', '长隆海洋王国', '缤纷世界：海洋王国中的亲子乐园，充满童心的爸爸妈妈可与孩子一同见证海洋缤纷神奇的一面。这里设有多种儿童游乐设施、大型游戏廊和踏浪乐园，您还可和孩子探望精灵可爱的小水獭，一家人享受温馨欢乐的时光。\r\n海象山：当然要探望我们逗趣搞笑的海洋动物朋友——海象和海狮。探访这些珍贵的动物之余记得到海狮剧场欣赏表演，牠们多才多艺的演出定会为您带来惊喜', '5D城堡影院：拥有全球较大3D弧形银幕的童话城堡--5D城堡影院，建筑外观以蓝色为主调，结合亚热带、海洋城堡等元素，色彩斑斓，视觉震撼！\r\n海豚湾：在这个海豚大本营，有瓶鼻海豚、斑点海豚和其他家族成员正等着和您打招呼！海豚剧场里欣赏海豚和饲养员合作无间精彩的演出；海豚岛更让您和海豚作近距离接触。', '2', '1、注意饮食卫生：提高防护传染病、流行病的意识。注意用餐卫生，不食用不卫生、不合格的食品及饮料，注意环境卫生，尽量少在路边小摊用餐。\r\n2、做好个人防护：备好相应的服装鞋、帽，做好防晒、防蚊虫等工作。\r\n3、注意人身安全：请在自己能够控制风险的范围内活动，注意人身安全，旅途中遇紧急情况的，应立即报警并寻求当地警察机关的帮助。\r\n4、防范水上风险：水上游览或活动时，应加倍注意安全，不可擅自下水或单独前往深水区或危险水域，应听从指挥和合理的劝阻。\r\n5、保管好贵重物品：贵重物品勿放在交运行李、酒店房间或旅游巴士上，随身携带财物稳妥安置，不要离开自己的视线范围，游览、拍照、散步、购物时，随时注意和检查谨防被盗遗失。\r\n6、携带旅行票证：个人身份证件、旅行证件、交通票证请随身妥善保管，以避免遗忘、丢失。\r\n7、园区内不得带食物', '李绪来', '18576697721', '200.00', '', '180.00', '游艇', '4', '56', '551', '广东省珠海市横琴新区富祥湾', '1439886733', '', '2', '0', '3', '1', '乘坐K10、K11、14、63、86路公交可直达珠海长隆景区。\r\na、K10路（吉大总站—长隆）景山路—水湾路—情侣南路—昌盛路—南湾南路—横琴大桥—环岛东路，每天78个班次。\r\nb、K11路（香洲—长隆', '0', '3');
INSERT INTO `tv_play` VALUES ('2', '44', '296', '297,298,299,300,', '古龙峡漂流', '古龙峡漂流', '古龙大峡谷隐逸于粤北茫茫群山之中。在高差数百米的万丈寨群峰的夹峙下，两岸河谷幽深，泉瀑飞泻，崖树斜逸，异草遍被。景物特色可用“奇、隐、俏、巧、幽、旷、惊、险、全、古”十个字来概括。清代诗人袁枚以“云开古龙峡，浪腾万丈崖”以及“万山如浪涌，泉鸣溪涌流。浮云脚下踩，松涛景色殊”形容峡谷的壮美幽深。', '浪尖上的过山车——古龙峡漂流，被誉为中国漂流的巅峰之作，高差达678米古龙大峡谷赋予了漂流与众不同的特色，集瀑布、深潭、奇石、丛林、珍稀植物于一体，悬崖对峙、奇峰耸立、滩多水急，银瀑飞溅，自然景色之美令人为止震撼。因峡深壁陡，林荫蔽日，漂流河道终年难见天日，年最高气温仅为24℃，炎炎夏季仍然冰爽宜人。天然瀑布群及溶洞山泉为漂流提供了充沛的水源', '1', '由于老人、儿童不适宜漂流，全家人可选择在粤北最大的瀑布群观光、探险。游玩一天后，可选择在当地的农家乐享用由新鲜食材制作的美食。', '周冰杰', '13641419256', '120.00', '', '118.80', '漂流', '6', '77', '707', '广东省清远市清新县三坑滩', '1440141600', '', '1', '0', '3', '1', '暂无', '0', '4');
INSERT INTO `tv_play` VALUES ('3', '44', '', '', '天涯海角', '天涯', '12321', '213', '3', '123', '杨艺平', '127', '23.00', '20|3,', '3.00', '游艇', '7', '98', '867', '1312213', '1440141604', '1440731600', '123', '0', '3', '2', '21321', '1', '4');
INSERT INTO `tv_play` VALUES ('4', '44', '', '', '天涯海角', '', '12321', '213', '3', '123', '杨艺平', '127', '23.00', '20|3,', '3.00', '游艇', '7', '98', '867', '1312213', '1440141610', '1440731600', '123', '0', '3', '2', '21321', '0', '5');
INSERT INTO `tv_play` VALUES ('5', '44', '308', '309,310,311,312,313,', '阳朔世外桃源景区4A景区', '阳朔世外桃源景区', '世外桃源景区是根据晋代陶渊明所著的《桃花源记》中的美景，结合当地的田园风光所设计开发的首批国家AAAA景区，并通过了ISO14001国际环境管理体系认证和ISO9001国际质量管理体系的认证，是世界旅游组织推荐旅游目的地，2004年5月份被评为首批全国农业旅游示范点，在桂林目前是唯一获得此殊荣的景区。景区位于桂阳公路旁，距桂林49KM、距阳朔15KM，田园风光、民俗风情、民寨大观有机排序，与大自然的秀美融合为一体，使您在此领略山光水色、民俗风情的同时，有一种恍若隔世的感觉。', '民俗风情、民寨大观有机排序，与大自然的秀美融合为一体，使您在此领略山光水色、民俗风情的同时，有一种恍若隔世的感觉。阳朔“世外桃源”主要有荷花池、燕子湖、燕子洞、侗乡风情和原始部落组成。若是“沾衣欲湿杏花雨，吹面不寒杨柳风”的季节，踏进“世外桃源”，展现在眼前的将是一片秀美的山水田园风光。清波荡漾的燕子湖镶嵌在大片的绿野平畴之中，宛如少女的明眸脉脉含情。湖岸边垂柳依依，轻拂水面。', '3', '景区首道门票及景区内船费。\r\n儿童1.2米以下【不含1.2米】免票。\r\n以上信息仅供参考，具体以景区当天披露为准。', '任  磊', '13825258236', '200.00', '', '176.00', '日出', '7', '98', '867', '广西壮族自治区桂林市阳朔县白沙镇五里店', '1440141646', '', '3', '0', '3', '1', '汽车路线\r\n市内交通：从桂林到阳朔约70公里，每15分钟一班，7：00-22：00有车，桂林到阳朔的普通班车10元/人，车程1小时10分，火车南站站前广场为班车始发站。', '0', '5');
INSERT INTO `tv_play` VALUES ('6', '1', '315', '316,317,318,319,320,', '桂林乐满地主题乐园5A景区 ', '桂林乐满地乐园', '满地主题公园是一个集时尚、动感、刺激、欢乐于一体的大型游乐场所。于2002年通过ISO9001国际标准和14001质量环境体系认证。2004年12月24日被评为“中国十佳主题乐园”，2007年荣膺国家AAAAA级旅游景区，中国自驾车旅游品牌十大景区，是中国精致主题乐园的代表。园内辟有欢乐中国城、美国西部区、梦幻世界区、海盗村、南太平洋区、欧洲区等特色景区。', '整个园区可观、可闻、可游、可赏、可疯狂、可闲逸……能够为游客提供完善、多样的游乐选择。主要游乐设施有风火轮、4D神马影院、怒海争锋、轰天雷、大峡谷急流泛舟、鬼屋历险、碰碰车、海盗船、惊涛骇浪、飞艇冲浪、破浪过山车、龙卷风、蹦极跳等等。', '2', '儿童身高1.2米以下（不含1.2米）免票，身高1.2米以下的儿童需成人陪同 。', '向守冬', '13662265805', '300.00', '', '0.00', '游艇', '4', '55', '540', '广西壮族自治区桂林市兴安县志玲路', '1440569797', '', '4', '0', '3', '1', '公交路线\r\n距离兴安县汽车站3公里，5、7、9、16路公车可直达。', '0', '5');
INSERT INTO `tv_play` VALUES ('7', '1', '321', '322,323,324,325,326,327,', '黄龙洞', '', '2005年被评选为“中国最美的旅游溶洞”，属典型的喀斯特岩溶地貌。\r\n黄龙洞已开发的洞内景观面积约20公顷。 洞分上下四层，水旱各半，从最低阴河至最高穹顶，垂直高差100多米。据初步探测，洞内有一个水库， 两条阴 河，三条地下瀑布，四个水潭，十三个大厅，九十六 条游廊。分龙宫、水晶宫、石琴山、天仙水、仙人掌、 响水河、迷宫等游览线。洞内钟乳浮悬，石柱林立， 石幔、石花、石瀑，淋琅满目，异彩纷呈。', '洞内有1库、2河、3潭、4瀑、13大厅、98廊，以及几十座山峰，上千个白玉池和近万根石笋。由石灰质溶液凝结而成的石钟乳、石笋、石柱、石花、石幔、石枝、石管、石珍珠、石珊瑚等遍布其中，无所不奇，无奇不有，仿佛一座神奇的地下“魔宫”。黄龙洞现已开放有龙舞厅、响水河、天仙瀑、天柱街、龙宫等6大游览区，主要景观有定海神针、万年雪松、龙王宝座、火箭升空、花果山、天仙瀑布、海螺吹天、双门迎宾、沧海桑田、黄土高坡等100多个。', '3', '1、洞内气温较低，建议不要在寒冷的季节去。\r\n2、如果从未见过溶洞，到此一游绝对值得。不过如果之前在其它景区见过类似的溶洞，则没有必要再去了，因为国内所有溶洞都大同小异。', '张今奕', '13794488292', '540.00', '', '475.20', '游艇', '4', '56', '552', '湖南省张家界市武陵源区索溪峪镇河口村', '1440569807', '', '5', '0', '3', '1', '汽车路线\r\n张家界市区汽车站乘车到武陵源汽车站再转乘1路车到黄龙洞下即是\r\n经物价部门批准，从黄龙洞广场可乘坐电瓶车抵达黄龙洞洞口，电瓶车票价为10元/人。', '0', '5');
INSERT INTO `tv_play` VALUES ('8', '1', '29', '30,31,', 'erwer', '', '23', '4234', '2342', '234234', '24234', '127', '23.00', '20|20,', '34.00', '游艇', '2', '52', '502', '42342', '1440569816', '1440747485', '0', '0', '3', '2', '324', '0', '5');
INSERT INTO `tv_play` VALUES ('9', '49', '328', '329,330,331,', '拉市海安中马场', '拉市海安中马场', '拉市海马场众多，但安中马场是拉市海最大的马场，安中马场占地面积2000平方米左右，视野开阔。其次安中马场是位置最好、交通最便利的马场，单程时间半小时，高速公路路面，路况较好，不易堵车。在横断山脉的高山峡谷，在滇、川、藏“大三角”地带的丛林草莽之中，绵延盘旋着一条神秘的古道，这就是世界上地势最高的文明文化传播古道之一的“茶马古道”。行走在保护完好的的高原植被中，每年的5月到11月，山花烂漫，满眼青翠，俯瞰拉市海湿地，就像一颗明珠镶嵌在群山中。', '拉市海是迁徙候鸟的栖息地，每年到此越冬或停歇的侯鸟有80多种，为滇西北之冠。拉市海边山清水秀，森林茂密，花草繁盛，清幽秀美。', '1', '1.游玩注意安全，建议穿舒适的平底鞋。\r\n2.爱护景区环境，遵守景区相关规定。', '程先觉', '13590285939', '4324.00', '', '1859.32', '日出', '5', '64', '619', '云南省丽江市拉市海湿地公园', '1440584332', '', '0', '0', '3', '1', '①丽江：丽江——玉雪大道——龙翔路——终点\r\n②昆明：昆明——昆楚高速公路——楚大高速公路——人民北路——G214——S308——玉龙大道——龙翔路——文笔路——终点', '0', '5');
INSERT INTO `tv_play` VALUES ('10', '1', '332', '333,334,335,336,', '冰川公园 ', '冰川公园 ', '玉龙雪山是欧亚大陆纬度最低的一座有现代冰川的分布的雪山。在其东麓，有四期更新世古冰川作用的遗迹分布在南北长15-16公里，东西宽4-5公里的冰川公园范围内，在这样一个离城较近的区域，却有一个面积不大但类型十分齐全多样的现代冰川和古冰川遗迹，可说是浓缩了全球中低纬度山岳冰川的主要精华，在我国是十分罕见的，其对冰川研究，生态环境保护及旅游、科学考察研究都具有极为重要的作用。', '在玉龙雪山中段海拔4000-4200米以上的高山区域，发育有19条现代冰川，总面积达11.61平方公里，其中东坡15条，西坡4条。玉龙雪山的现代冰川的类型可分为山谷冰川、冰斗冰川和悬冰川以及它们之间的过渡类型--冰斗山谷冰川和冰斗悬冰川。', '5', '多穿点衣服.冷啊', '黄 津', '13714955004', '8989.00', '', '7910.32', '游艇', '8', '114', '990', '云南省丽江市玉龙纳西族自治县雪山景区内', '1440671912', '', '6', '0', '3', '1', '无', '0', '5');
INSERT INTO `tv_play` VALUES ('11', '1', '113', '', '234', '', '5655565', '145454', '1212', '4545455', '2343', '127', '8989.00', '20|565,', '2876.48', '游艇', '2', '52', '500', '4848', '1440671934', '1440748277', '2332', '0', '3', '2', '5454545', '0', '5');
INSERT INTO `tv_play` VALUES ('12', '1', '119', '', '1212', '', '', '', '1212', '', '212', '127', '0.00', '20|20,', '0.00', '游艇', '2', '52', '500', '121212', '1440723372', '1440748288', '0', '0', '3', '2', '', '0', '5');

-- -----------------------------
-- Table structure for `tv_pro_order`
-- -----------------------------
DROP TABLE IF EXISTS `tv_pro_order`;
CREATE TABLE `tv_pro_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `uid` int(11) NOT NULL COMMENT '用户id',
  `pro_id` int(11) NOT NULL COMMENT '产品id',
  `pro_name` varchar(255) DEFAULT NULL COMMENT '产品名',
  `pro_img` varchar(11) DEFAULT NULL COMMENT '产品图片id',
  `name` varchar(25) NOT NULL COMMENT '联系人',
  `tel` varchar(20) NOT NULL COMMENT '联系电话',
  `adult` varchar(2) DEFAULT NULL COMMENT '成人',
  `child` varchar(2) DEFAULT NULL COMMENT '小孩',
  `rooms` varchar(2) DEFAULT NULL COMMENT '房间',
  `car` varchar(2) DEFAULT NULL COMMENT '用车',
  `unit_price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `discount_price` decimal(10,2) NOT NULL COMMENT '折扣价格',
  `score_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '积分价格',
  `score` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '使用积分',
  `voucher_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '代金券价格',
  `voucher_number` varchar(3) NOT NULL DEFAULT '0' COMMENT '代金券数量',
  `number` varchar(5) NOT NULL DEFAULT '1' COMMENT '产品数量',
  `total_price` decimal(10,2) NOT NULL COMMENT '总价',
  `discount_way` varchar(100) DEFAULT NULL COMMENT '折扣途径',
  `insert_time` varchar(10) DEFAULT NULL COMMENT '下单时间',
  `remarks` text COMMENT '备注',
  `starting_city` varchar(100) DEFAULT NULL COMMENT '出发地点',
  `start_time` varchar(10) DEFAULT NULL COMMENT '开始时间',
  `end_time` varchar(10) DEFAULT NULL COMMENT '结束时间',
  `pro_type` varchar(2) NOT NULL COMMENT '产品类型(1:房源2:餐饮3:景点4:路线;5:现金券)',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_pro_order`
-- -----------------------------
INSERT INTO `tv_pro_order` VALUES ('14', '44', '8', '海鲜餐厅', '373', '杨艺平', '13049340993', '', '', '', '', '92.93', '0.00', '0.00', '0.00', '89.00', '1', '1', '92.93', '', '1441885696', '', '', '1443155400', '', '2');
INSERT INTO `tv_pro_order` VALUES ('13', '44', '8', '海鲜餐厅', '373', '杨艺平', '13049340993', '', '', '', '', '92.93', '0.00', '0.00', '0.00', '89.00', '1', '1', '92.93', '', '1441885653', '', '', '1443155400', '', '2');
INSERT INTO `tv_pro_order` VALUES ('12', '44', '8', '海鲜餐厅', '373', '杨艺平', '13049340993', '', '', '', '', '92.93', '0.00', '0.00', '0.00', '89.00', '1', '1', '92.93', '', '1441884813', '', '', '1443155400', '', '2');
INSERT INTO `tv_pro_order` VALUES ('11', '44', '8', '海鲜餐厅', '373', '杨艺平', '13049340993', '', '', '', '', '92.93', '92.93', '0.00', '0.00', '0.00', '0', '1', '92.93', '', '1441884074', '', '', '1443155400', '', '2');
INSERT INTO `tv_pro_order` VALUES ('9', '44', '5', '六星汽车宾馆', '64', '杨艺平1', '13049340993', '2', '', '', '', '222.75', '445.50', '0.00', '0.00', '0.00', '0', '2', '445.50', '', '1441879169', '', '', '1443542400', '1443715200', '1');
INSERT INTO `tv_pro_order` VALUES ('10', '44', '8', '海鲜餐厅', '373', '杨艺平', '13049340993', '', '', '', '', '89.00', '445.00', '0.00', '0.00', '0.00', '0', '5', '445.00', '', '1441880846', '', '', '', '', '5');
INSERT INTO `tv_pro_order` VALUES ('15', '44', '2', '古龙峡漂流', '296', '杨艺平', '13049340993', '', '', '', '', '118.80', '236.60', '0.00', '50.00', '0.00', '0', '2', '237.60', '5', '1441886775', '', '', '1443542400', '', '3');
INSERT INTO `tv_pro_order` VALUES ('16', '44', '9', '缤纷澳妙纯净假期 10日亲子旅行', '64', '杨艺平', '13049340993', '', '', '', '', '784.00', '2352.00', '0.00', '0.00', '0.00', '0', '3', '2352.00', '', '1441887071', '', '悉尼', '1434038400', '', '4');
INSERT INTO `tv_pro_order` VALUES ('17', '44', '5', '六星汽车宾馆', '64', '杨艺平', '13049340993', '2', '', '', '', '222.75', '668.25', '0.00', '0.00', '0.00', '0', '3', '668.25', '', '1441934604', '', '', '1443542400', '2015-10-02', '1');

-- -----------------------------
-- Table structure for `tv_restaurant`
-- -----------------------------
DROP TABLE IF EXISTS `tv_restaurant`;
CREATE TABLE `tv_restaurant` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '商家用户id',
  `logo_img_url` varchar(100) DEFAULT NULL COMMENT '封面图片',
  `foot_img_url` tinytext COMMENT '餐饮图片,标明食品名字，类型，价格',
  `environment_img_url` tinytext COMMENT '环境图片',
  `business_hours` varchar(20) DEFAULT NULL COMMENT '营业时间（几点到几点）',
  `foot_name` varchar(100) NOT NULL COMMENT '餐饮店名',
  `foot_tel` varchar(25) NOT NULL COMMENT '餐饮电话',
  `per_capita` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '人均消费',
  `voucher` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '现金券/一百元',
  `voucher_rules` varchar(255) DEFAULT NULL COMMENT '现金券规则提醒',
  `effective_time` varchar(10) DEFAULT NULL COMMENT '现金券有效时间',
  `vip_price` tinytext COMMENT 'Vip价格',
  `favorable_price` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '优惠价',
  `type` varchar(15) NOT NULL COMMENT '餐馆类型',
  `provinces` varchar(10) NOT NULL COMMENT '省份',
  `citys` varchar(10) DEFAULT NULL COMMENT '市区',
  `countys` varchar(10) DEFAULT NULL COMMENT '县城',
  `address` varchar(255) NOT NULL COMMENT '所在地址',
  `nearby_traffic` tinytext COMMENT '附近交通',
  `insert_time` varchar(10) NOT NULL COMMENT '生成时间',
  `update_time` varchar(10) DEFAULT NULL COMMENT '更新时间',
  `sort` varchar(5) NOT NULL DEFAULT '0' COMMENT '排序',
  `look_number` varchar(10) NOT NULL DEFAULT '0' COMMENT '已看人数',
  `eat_number` varchar(10) NOT NULL DEFAULT '0' COMMENT '已吃人数',
  `praise_number` varchar(10) NOT NULL DEFAULT '0' COMMENT '已赞人数',
  `introduce` text COMMENT '餐饮介绍',
  `star` varchar(1) DEFAULT '1' COMMENT '星级',
  `pro_type` int(1) NOT NULL DEFAULT '2' COMMENT '产品类型',
  `status` varchar(2) NOT NULL DEFAULT '3' COMMENT '状态（0：下架；1：启用；2：删除;3：待通过；4：不通过）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='餐饮表';

-- -----------------------------
-- Records of `tv_restaurant`
-- -----------------------------
INSERT INTO `tv_restaurant` VALUES ('1', '1', '151', '2,372,73,152,153,154,155,156,157,158,159,162,', '160,161,163,164,165,', '24:00-01:00', '蝴蝶梦音乐餐厅(罗湖店)', '0734-52464446', '500.00', '100.00', '', '1442419200', '20|20,', '308.70', '面包甜点', '4', '54', '532', '北京市西城区白纸坊西街1号（东邻地铁4号线，北邻地铁7号线）', '北京首都国际机场\r\n行车约1小时15分钟，距离约37公里', '1439893069', '1440401794', '1', '22', '0', '0', '', '3', '2', '1');
INSERT INTO `tv_restaurant` VALUES ('2', '1', '139', '140,141,142,143,144,145,', '98,99,146,147,148,149,', '12:00-00:00', '萬膳日本料理·铁板烧', '010-64043847', '240.00', '0.00', '', '1442419200', '20|20,', '120.00', '自助餐', '4', '55', '540', '北京市东城区地安门内大街北月牙胡同11号', '沙元埔 - 深圳杨梅坑七星湾民宿\r\n沙元埔 - 南澳七星湾', '1440140899', '', '0', '22', '0', '0', '', '1', '2', '1');
INSERT INTO `tv_restaurant` VALUES ('3', '1', '166', '167,168,169,171,172,173,', '174,', '03:43-23:00', 'BONBONS Hello Kitty Cafe(COCOPARK店)', '18608889061', '620.00', '34223423.00', '', '1442419200', '20|20,', '607.60', '咖啡厅', '5', '64', '619', '丽江市古城新义街百岁坊46号', '324324', '1440141017', '', '0', '22', '0', '1', '', '1', '2', '1');
INSERT INTO `tv_restaurant` VALUES ('4', '1', '175', '176,177,178,179,180,', '181,182,', '20:00-08:00', '江南味道(卓越店)  分店', '0065-66888868', '80.00', '100.00', '', '1442419200', '20|20,', '40.00', '江浙菜', '3', '38', '418', '10 Bayfront Avenue, Singapore (新加坡滨海湾)', '樟宜国际机场\r\n行车约47分钟，距离约23.7公里', '1440583426', '', '10', '22', '0', '0', '', '4', '2', '1');
INSERT INTO `tv_restaurant` VALUES ('5', '1', '183', '184,185,186,187,188,189,190,', '191,192,193,194,', '08:00-22:00', '渔技真炭火烤鱼 ', '0898-88568866', '500.00', '32.00', '', '1442419200', '20|20,', '480.00', '粤菜', '28', '345', '2941', '三亚市亚龙湾国家旅游度假区龙塘路12号 ( 亚龙湾)', '到达三亚后,可以直接乘公交车M391、M392、M372可直达到酒店', '1440671086', '', '3', '22', '0', '0', '', '1', '2', '1');
INSERT INTO `tv_restaurant` VALUES ('6', '1', '136', '137,', '138,', '54-45', '545654', '45', '54.00', '45.00', '', '1442419200', '20|20,', '0.00', '粤菜', '3', '37', '410', '4545', '45', '1440725373', '1440726270', '', '22', '0', '0', '', '2', '2', '2');
INSERT INTO `tv_restaurant` VALUES ('7', '1', '338', '339,340,', '341,342,343,344,', '12:00-24:00', '梅县程江腌面王', ' 0755-29988477', '50.00', '200.00', '', '1442419200', '20|20,', '44.00', '小吃快餐', '3', '38', '418', '宝安区 兴华一路富源花园裙楼(海滨中学十字路口斜对面)', '交通很方便,坐车直到', '1440748884', '', '2', '22', '0', '0', '', '4', '2', '1');
INSERT INTO `tv_restaurant` VALUES ('8', '44', '373', '374,', '', '10:00-00:00', '海鲜餐厅', '13049340993', '121.00', '89.00', '', '1441728000', '20|20,21|80,', '116.16', '创意菜', '6', '77', '705', '车公庙', '383', '1441537270', '', '0', '22', '0', '0', '', '1', '2', '1');

-- -----------------------------
-- Table structure for `tv_route`
-- -----------------------------
DROP TABLE IF EXISTS `tv_route`;
CREATE TABLE `tv_route` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '商家用户id',
  `logo_img_url` varchar(100) DEFAULT NULL COMMENT '封面图片',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `introduce` text COMMENT '介绍',
  `chief` varchar(25) NOT NULL COMMENT '负责人',
  `tel` varchar(25) NOT NULL COMMENT '联系电话',
  `price` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '价格/人',
  `vip_price` tinytext COMMENT 'Vip价格/人',
  `favorable_price` decimal(11,2) DEFAULT '0.00' COMMENT '优惠价',
  `day` varchar(2) NOT NULL COMMENT '几天游',
  `night` varchar(2) DEFAULT '0' COMMENT '几夜游',
  `provinces` varchar(10) DEFAULT NULL COMMENT '省份',
  `citys` varchar(10) DEFAULT NULL COMMENT '市区',
  `countys` varchar(10) DEFAULT NULL COMMENT '县城',
  `starting_city` varchar(100) NOT NULL COMMENT '出发地点',
  `set_placc` varchar(255) DEFAULT NULL COMMENT '集合地点',
  `traffic_infermation` tinytext COMMENT '交通工具',
  `team_number` varchar(3) NOT NULL COMMENT '组团人数',
  `lowest_team_number` varchar(3) NOT NULL COMMENT '最低报名人数',
  `enrollment_number` varchar(3) DEFAULT '0' COMMENT '已报名人数 0',
  `effective_date` varchar(20) DEFAULT NULL COMMENT '出发日期（用，分隔开）',
  `departure_date` text COMMENT '有效时间（0：长期有效；）',
  `cancel` tinyint(1) DEFAULT '0' COMMENT '是否可退（0:不可退；1:可退',
  `destination` varchar(255) DEFAULT NULL COMMENT '目的地',
  `cost_description` text COMMENT '费用说明',
  `housed_explain` text COMMENT '吃住说明',
  `rental` text COMMENT '租车',
  `insurance` varchar(255) DEFAULT NULL COMMENT '保险',
  `comment_number` int(11) NOT NULL DEFAULT '0' COMMENT '评论者数量',
  `sort` varchar(4) DEFAULT '0' COMMENT '排序',
  `notes` text COMMENT '注意事项',
  `insert_time` varchar(10) NOT NULL COMMENT '建立时间',
  `update_time` varchar(10) DEFAULT NULL COMMENT '更新时间',
  `pro_type` int(1) NOT NULL DEFAULT '4' COMMENT '产品类型',
  `status` int(1) NOT NULL DEFAULT '3' COMMENT '状态（0：下架；1：启用；2：删除;3：待通过；4：不通过）',
  `praise_number` int(11) NOT NULL COMMENT '已赞人数',
  `star` varchar(1) NOT NULL DEFAULT '0' COMMENT '星级',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_route`
-- -----------------------------
INSERT INTO `tv_route` VALUES ('9', '1', '64', '缤纷澳妙纯净假期 10日亲子旅行', '2晚四星都市精品酒店+1晚宿鼓浪屿||双飞往返厦门鼓浪屿南普陀★包接送入住酒店、含往返机票（含税）★赠送鼓浪屿往返船票★赠送价值20万元保额旅游意外险！我们承诺不随意加价，无强推自费项目，真正玩的舒心，玩的实在，旅途中如有任何异议，全程跟踪服务行程、第一时间处理投诉，第一时间接听您的来电', '杨艺平', '13049340993', '800.00', '20|45,', '784.00', '2', '3', '6', '77', '705', '悉尼', '凯恩斯', '旧金山机场－洛杉矶机场 Toyota Corolla或相似车型 (7天，机场异地取还)', '30', '20', '0', '2015-06-12', '2015-02-15至2016-02-16', '0', '洛杉矶+拉斯维加斯+旧金山', '交通：包含本产品出发地往返厦门机票（具体航班以我社出票航班为准，每天特价仓位的机票都不一样，不一定是推荐航班.)', '4 早3正餐，10人一桌，8菜1汤，正餐标准20元/人/餐\r\n住宿：市区四星酒店酒店2晚', '不需要租车', '美亚保险-美国 万国游踪旅游保险 (钻石计划，11-14天)', '0', '0', '1、根据国家法律规定，为确保您的游程顺利，请随身携带并自行保管好您的有效身份证明，并在报名时务必确认所报姓名与身份证件完全一致无误。', '', '', '4', '1', '1', '3');
INSERT INTO `tv_route` VALUES ('10', '1', '65', '深圳出发 10天9晚 | 销量之王强势回归*5星酒店+洱海游轮*买单立减88*昆明大理...', '销量之王强势回归*5星酒店+洱海游轮*买单立减88*昆明大理丽江西双版纳10天双飞全景游*尽玩经典景点，探秘千年古城，访寻神圣丛林之灵，感受多样民俗风情，赏花踏青、游山玩水、品茶观舞*独享尊贵庭院式别墅+海景酒店，保证舒适睡眠*全程无强迫消费，加送旅行社责任险，专车接送机，快乐无忧。免费咨询电话4006-351-527，马上解决选择困难症。', '蒋女士', '15814082748', '322.00', '', '318.78', '2', '2', '6', '77', '706', '深圳出发', '丽江集合', ' 包含本产品深圳往返昆明机票（具体航班以我社出票航班为准，客人如需自选航班，下单之后可联系我们客服，补足相应的机票差价，方可出票）;', '50', '30', '0', '2015-07-20', '2015-03-18至2017-03-19', '0', '大理＋西双版纳＋石林＋丽江', '门票:行程所列景点首道大门票。赠送项目不退不换;\r\n用车:全程空调旅游车;\r\n导游:当地中文导游，自由活动期间除外;\r\n服务:提供昆明接送机;\r\n儿童价标准:年龄2~12周岁（含），不占床，含往返机票（含税），含当地旅游车车位，含导游服务，含半价正餐。儿童不含门票，届时请根据身高情况，在景区门口自行购买，敬请谅解;', '住宿:入住当地指定酒店双人标间，（带独立卫生间）;昆明参考酒店：七彩酒店、春悦酒店、铭春酒店、云南大酒店；大理参考酒店：金沙半岛、格林豪泰、凤凰温泉大酒店【含泡澡】；丽江参考酒店官房私人别墅、瓜玳国私人别墅、金生丽城、康达酒店、祥鹤楼；\r\n用餐:行程中团队标准用餐，8早12正，正餐为十人一桌，八菜一汤。自由活动期间用餐费请自理，如因自身原因放弃用餐，餐费不退;', '不用车', '旅行社责任保险', '0', '0', '234', '', '', '4', '1', '0', '4');
INSERT INTO `tv_route` VALUES ('11', '1', '66', '青春时光 0自费0购物海南三亚双飞高品纯玩6日游', '青春时光 ★ 0自费0购物★海南三亚双飞高品纯玩6日游；全程“五星高标准的接待，五星高品质的服务”、全程以“旅游+自由为主题”打造1+1〉2的休闲旅游自由新模式，【七大超值赠送、六大亮点、四个承诺、四个赔付、四个保障】做为行程的亮点和宣传口号。每天只安排1个景点，确保游览景点时间充足；全程指定入住3晚五星亚太国际酒店，2晚梅洛卡度假酒店、绝不增加行程外的垃圾变相购物和自费景点，让旅游时间更加充足化', '陆先生', '15625446578', '500.00', '', '450.00', '6', '5', '3', '38', '418', '海口', '三亚', '包含本产品深圳往返昆明机票（具体航班以我社出票航班为准，客人如需自选航班，下单之后可联系我们客服，补足相应的机票差价，方可出票）;', '60', '40', '0', '2015-08-09', '2015-02-25至2015-06-12', '0', '三亚湾＋亚龙湾＋蜈支洲岛', '导游:当地中文导游，自由活动期间除外;\r\n服务:提供昆明接送机;\r\n儿童价标准:年龄2~12周岁（含），不占床，含往返机票（含税），含当地旅游车车位，含导游服务，含半价正餐。儿童不含门票，届时请根据身高情况，在景区门口自行购买，敬请谅解;', '住宿:入住当地指定酒店双人标间，（带独立卫生间）;昆明参考酒店：七彩酒店、春悦酒店、铭春酒店、云南大酒店；大理参考酒店：金沙半岛、格林豪泰、凤凰温泉大酒店【含泡澡】；丽江参', '全程空调旅游车', '旅行社责任保险;', '0', '0', '本线路为特价优惠活动线路：优惠仅针对户口所在地为该出发地且25-54周岁年龄段的游客。其余户口所在地或该年龄段以外的游客请先电话咨询24小时免费服务热线：4006-351-527；本旅行社拥有最终解释权。', '', '', '4', '1', '0', '4');
INSERT INTO `tv_route` VALUES ('12', '1', '67', '7天6晚 | 深圳至云南昆明往返机票高端真纯玩大理、丽江、泸沽湖', '海洋景色深圳至云南昆明往返机票高端真纯玩大理、丽江、泸沽湖7天6晚纯玩，拉市海、束河古镇、九鼎龙潭、双廊、 洱海、大理古城等精华景点一网打尽！全程入住特色四星酒店标准间，泸沽湖特别安排 “湖景房”★赠送泸沽湖“ 环湖游+猪槽船游览泸沽湖+ 泸沽湖篝火晚会” （价值300元/人）纯玩不进店 无区域年龄限制补费可增加玉龙雪山、西双版纳、腾冲、瑞丽等地行程', '王小明', '15687445263', '4000.00', '', '3000.00', '7', '6', '', '98', '865', '深圳', '火车东站', '飞机去飞机回', '23', '14', '0', '0', '2016年03月24', '0', '泸沽湖＋大理＋丽江＋昆明', '1、往返程经济舱机票, 含机场建设费和燃油附加税\r\n2、往返程巴士费用\r\n3、机场与酒店之间接机/站服务\r\n4、行程所列酒店住宿费用\r\n5、行程中团队标准用餐，如因自身原因放弃用餐，餐费不退\r\n6、自由活动期间用餐费请自理', '酒店含早餐1份/房/天\r\n团队标准餐，十人一桌，八菜一汤！', '无', '请自行购买', '0', '0', '1、入住酒店后要检查自己房间的物品是否损坏，是否齐全，如有损坏及时找服务员说明并调换。\r\n2、行程结束后回到酒店，如需外出，请携带好房间钥匙，关好门窗，贵重物品随身携带。\r\n3、记好导游的电话和旅游车的车牌号及自己入住酒店的名称。', '', '', '4', '1', '0', '4');
INSERT INTO `tv_route` VALUES ('13', '0', '68', '暑期特惠|无强制购物|无强制消费|昆明石林大理丽江西双版纳...', '暑期特惠|无强制购物|无强制消费|昆明石林大理丽江西双版纳9天8晚超值游(提前预订赠送洱海大游船、云南特产鲜花饼，春城之都昆明、心花路放拍摄地大理、艳遇之都丽江、热带雨林西双版纳，云南最经典、最实惠的线路，让您玩的开心，吃的舒心！)', '刘小雄', '15842151426', '500.00', '', '310.00', '2', '3', '9', '120', '1055', '深圳', '云南', '昆明至大理火车硬卧或旅游汽车、大理至昆明火车硬卧、昆明至西双版纳往返旅游车、全程空调旅游车（一人一正坐）；', '20', '10', '0', '0', '2016-12-02', '0', '石林+昆明+西双版纳', '景点内小交通：石林电瓶车25元/人，大理古城电瓶车35元/人，野象谷索道50元/人，原始森林公园电瓶车40元/人，花卉园电瓶车40元/人；西双版纳游船260元/人。', '【餐食】7早13正（早餐酒店用）；\r\n【住宿】丽江楼外楼大酒店等舒适型/含8晚住宿', '一台宝马车', '赠送旅游意外险、旅行社责任险、云南旅游组合险，签定正式旅游合同 ', '0', '0', '此价格包含往返机票，因游客订团及出行时间不同，机票折扣可能有所浮动，价格有可能下调或者上调，建议您提前预订更实惠，本产品绑定特价机票，不可指定航班，以实际出票为准，亲如需选择航班请下单前告知，详情可拨打24小时免费服务400热线 。谢谢！', '1440385656', '', '4', '1', '0', '3');
INSERT INTO `tv_route` VALUES ('14', '44', '69', '国庆特别航次歌诗达维多利亚号', 'Costa Victoria 是那些喜爱设计、雅致、对称形状和柔和色调人士的理想邮轮。 这艘邮轮经过彻底翻修，将传统海运外观和简约设计、精美饰面、艺术杰作完美融为一体，拥有独特醒目的风格。', '刘生海', '15232664578', '600.00', '', '588.00', '3', '2', '7', '101', '900', '上海', '济州岛', '邮轮自驾行驶2天', '43', '40', '0', '0', '2016-12-12至2015-04-06', '0', '上海-济州-福冈', '1）邮轮港务税费\r\n2）日本团队登陆许可申请服务（如需办理日本单次个人签证需加500元/人）；\r\n3）全程岸上观光费用；\r\n4）邮轮上派对、主题晚会、表演、游戏、比赛等活动（特别注明的收费活动除外）。 ', '1）歌诗达维多利亚号4晚住宿；\r\n2）邮轮上提供的一日三餐、下午茶及夜宵；', '徒步,不需要走', '个人邮轮旅游意外险，建议购买，50元/份。', '0', '0', '目前韩国邮轮航线实行免签证政策，需要游客提供韩国团队签证材料，以审核游客是否满足免签观光上陆许可，但不予办理签证。对于特殊游客，可能会收取相应保证金。', '1440386238', '', '4', '1', '0', '5');
INSERT INTO `tv_route` VALUES ('15', '49', '70', '成都全日空直飞东京【经典线路】日本本州全景温泉美食6日', '成都全日空直飞东京【经典线路】日本本州全景温泉美食6日（东京~箱根~富士山~京都~大阪经典环游线路，大阪城公园、金阁寺、浅草寺、平和公园，感受古日本历史气息；心斋桥~御殿场OUTLET~秋叶原~银座，享受欢畅购物乐趣；富士山~攀登日本第一高峰）', '建燕', '15665442548', '800.00', '', '799.20', '8', '7', '9', '121', '', '成都', '香港', '飞机-汽车-大巴-飞机', '60', '60', '0', '2015-06-23', '2015-02-22-2015-14-02', '0', '广州、青岛、南宁、厦门、北京', '以上团队报名资料一般提前15天到我社。如因客人资料问题而造成拒签或被终止签证，需收取手续费1000元/人+机票定金2000元/人。若送签后出团前7天取消客人，需承担80%损失费，发团前在已出机票的情况下取消，则全额损失团费。由于客人临时取消、而造成的人等差、导致地接费用上涨，需由客人负责！！', '住宿:高档型东京或周边地区酒店\r\n早餐：酒店内；午餐：日式或中式料理；晚餐：方便游玩，敬请自理。', '无', '个人旅游意外保险', '0', '0', '日元不必携带过多，日本很多商店可支持使用中国银联银行卡。', '1440584672', '', '4', '1', '0', '5');
INSERT INTO `tv_route` VALUES ('16', '1', '', '11', '1', '11', '1', '0.00', '', '0.00', '1', '1', '', '', '', '1', '1', '1', '1', '1', '0', '0', '0', '0', '1', '1', '1', '1', '', '0', '0', '1', '1440671447', '1440724284', '4', '2', '0', '5');
INSERT INTO `tv_route` VALUES ('17', '1', '', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'a', '1', '1', '0.00', '', '0.00', '1', '1', '', '', '', '1', '1', 'a', '1', '1', '0', '0', '0', '0', '1', 'a', 'a', 'a', '', '0', '0', 'a', '1440671498', '1440724276', '4', '2', '0', '5');
INSERT INTO `tv_route` VALUES ('18', '1', '380', '东部游', '打发打发', '杨毅平', '13049340993', '1500.00', '20|74,', '1300.00', '2', '3', '6', '82', '759', '深圳', '火车站', '大巴', '30', '25', '0', '0', '2015-12-15', '0', '东部湾', '500包含吃住', '海鲜，农家菜，海景房', '', '', '0', '0', '为奋斗房', '1441769523', '', '4', '1', '0', '0');

-- -----------------------------
-- Table structure for `tv_route_details`
-- -----------------------------
DROP TABLE IF EXISTS `tv_route_details`;
CREATE TABLE `tv_route_details` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pro_name` varchar(200) DEFAULT NULL COMMENT '产品名称',
  `route_id` int(11) NOT NULL COMMENT 'route表id',
  `start_time` varchar(20) DEFAULT NULL COMMENT '项目游玩开始时间',
  `end_time` varchar(20) DEFAULT NULL COMMENT '项目游玩介绍时间',
  `bewrite` text COMMENT '游玩描述',
  `day` varchar(100) DEFAULT NULL COMMENT '第几天',
  `pro_id` varchar(20) DEFAULT NULL COMMENT '产品id',
  `type` varchar(2) DEFAULT NULL COMMENT '产品类型（1:房源；2:餐饮；3:景点）',
  `status` varchar(1) DEFAULT '1' COMMENT '状态（2：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_route_details`
-- -----------------------------
INSERT INTO `tv_route_details` VALUES ('31', '萬膳日本料理·铁板烧', '9', '07:00', '09:00', '乘飞机去昆明的路上,空中飘', '1', '2', '2', '1');
INSERT INTO `tv_route_details` VALUES ('32', '阳朔世外桃源景区4A景区', '9', '09:00', '11:30', '抵达后前往野象谷，游览4A旅游风景区【野象谷】（约120分钟），观看大象表演、百鸟园、蝴蝶园、树上旅馆，野象谷充满神秘、奇异，它那优美的自然景色，惊心动魂的探险活动，一定会让你赏心悦目，终生难忘，让你了却回归自然的夙愿；参观【傣族村寨】（游览时间约1.5小时）房屋建筑为“干栏”式竹楼，户与户之间竹篱为栏，自成院落。四周多种植椰子、香蕉、竹林等果木，处处部部葱葱，一派亚热带的风光和异国情调。游玩后乘车赴西双版纳市区。', '1', '5', '3', '1');
INSERT INTO `tv_route_details` VALUES ('33', '桂林乐满地主题乐园5A景区 ', '9', '08:00', '12:00', '迎来了美好的一天,今天我们要游览大理的标志和象征，中国南方最古老，最雄伟的建筑——【崇圣寺三塔】', '2', '6', '3', '1');
INSERT INTO `tv_route_details` VALUES ('34', '冰川公园 ', '9', '07:30', '10:30', '早餐后，乘车前往99世博会会址——游览【世博园】参观玉文化博物馆、花园大道等，（参观时间180分钟），中餐于世博园中国馆昆明厅享用云南风味-过桥米线，之后乘车前往石林，游览天下第一奇观：“世界地质公园，世界自然保护遗产”，国家5A级风景区【石林】，聆听每一块石头向您述说的故事，体会鬼斧神工的天下第一奇观，畅游二亿七千万年前，浩瀚海洋之海底。', '3', '10', '3', '1');
INSERT INTO `tv_route_details` VALUES ('47', '珠海长隆海洋王国', '9', '10:30', '12:30', '自行购物,这里很美,有很多特色,可以选上自己喜欢的东西,包括小吃......把他们装到包里,带着他们回家。', '3', '1', '3', '1');
INSERT INTO `tv_route_details` VALUES ('49', '江南味道(卓越店)  分店', '9', '12:00', '14:30', '疲惫的玩耍,接下来就是填饱我们的肚子,之后美美的睡一个小时.......... 让精神饱满起来', '2', '4', '2', '1');
INSERT INTO `tv_route_details` VALUES ('50', '京基喜来登度假酒店', '12', '13:40', '15:30', '玲度', '1', '3', '1', '1');
INSERT INTO `tv_route_details` VALUES ('51', '珠海长隆海洋王国', '12', '16:04', '17:04', '34', '2', '1', '3', '1');
INSERT INTO `tv_route_details` VALUES ('52', '京基喜来登度假酒店', '12', '17:04', '19:04', '54353', '2', '3', '1', '1');
INSERT INTO `tv_route_details` VALUES ('53', '京基喜来登度假酒店', '12', '15:03', '04:03', '3423234', '3', '3', '1', '1');
INSERT INTO `tv_route_details` VALUES ('54', 'BONBONS Hello Kitty Cafe(COCOPARK店)', '12', '04:23', '23:04', '4332432', '3', '3', '2', '1');
INSERT INTO `tv_route_details` VALUES ('55', '', '0', '', '', '', '', '', '', '1');
INSERT INTO `tv_route_details` VALUES ('56', '', '0', '', '', '', '', '', '', '1');
INSERT INTO `tv_route_details` VALUES ('57', '新加坡滨海湾金沙大酒店(Marina Bay Sands) ', '16', '', '', '1', '1', '4', '2', '1');
INSERT INTO `tv_route_details` VALUES ('58', '丽江童话精品客栈溪溪里庄园', '17', '', '', 'dafadsfasdfasdfasdfasfsafasadfasdfafa', '1', '3', '2', '1');
INSERT INTO `tv_route_details` VALUES ('59', '京基喜来登度假酒店', '9', '11:30', '13:00', '开饭了...自助餐.大家一起来吃', '1', '3', '1', '1');
INSERT INTO `tv_route_details` VALUES ('60', '古龙峡漂流', '10', '07:00', '09:00', '乘坐国际航班前往世界级渡假胜地——【普吉岛】,抵达后由专职中文导游接团，出机场由专车接入指定的酒店休息。', '1', '2', '3', '1');
INSERT INTO `tv_route_details` VALUES ('61', '珠海长隆海洋王国', '10', '08:45', '12:00', '早餐后，随后前往【印度洋快艇来回大PP岛】可以一路欣赏印度洋海上风景，在一望无际大海上感受大海给我们带来神奇魅力，让您尽享蓝天白云水天一线的热带天堂。给您独占远离喧嚣鸟语花香的世外桃源。热情的阳光中投下跳动的光斑，邀您共赴狂欢的盛宴，带您开启神秘的海洋。', '2', '1', '3', '1');
INSERT INTO `tv_route_details` VALUES ('62', '', '12', '', '', '', '4', '', '', '1');
INSERT INTO `tv_route_details` VALUES ('63', '', '12', '', '', '', '5', '', '', '1');
INSERT INTO `tv_route_details` VALUES ('64', '', '12', '', '', '', '6', '', '', '1');
INSERT INTO `tv_route_details` VALUES ('65', '珠海长隆海洋王国', '9', '01:00', '04:00', '长白山万达智选假日酒店位于吉林省长白山国际度假区，与度假区滑雪场近在咫尺，15分钟步行至度假区商业街，距离长白山机场仅12公里。 酒店装修风格和设计理念时尚、充满活力。酒店提供免费的高速互联网连接，热气腾腾的早餐，舒适的客房等贴心的服务和设施， 令旅客倍感舒心。', '3', '1', '3', '1');
INSERT INTO `tv_route_details` VALUES ('66', '', '9', '04:00', '20:00', '结束旅程,回家拉回家拉回家拉回家拉回家拉', '3', '', '4', '1');
INSERT INTO `tv_route_details` VALUES ('67', '', '10', '09:00', '12:00', '早餐后，按照搭乘航班时间前往美丽而闻名的泰国第一大岛【普吉岛】，随后搭乘泰国特有之长尾船前往被誉为泰国的「海上小桂林」之称的【攀牙湾Phang-Nga】这里遍布着诸多大小岛屿、怪石嶙峋、景色变幻万千，堪称「世界奇观」，以其天然奇景声名远播。千乘游船穿梭於奇形怪状的岛林中，畅游【欧洲人走的攀牙湾海上国家公园】穿梭于攀牙湾群岛间，海蚀山林、钟乳石奇景，一睹小桂林的山水风光、屏千岛的峭壁平滑如镜，铁钉屿的英姿傲世独立等，宛入仙境一般。途经最负盛名的【占士邦岛】因007电影金鎗人曾在此拍摄而闻名于世。隨后赠送【割喉群岛+畅游橡皮艇泛舟红树林之旅探险】', '1', '', '3', '1');
INSERT INTO `tv_route_details` VALUES ('68', 'DAY 1-3 墨尔本Quality Hotel Batman\'s Hill on Collins (Room Only) Hotel （或同级别精品酒店）', '9', '18:30', '19:30', '开饭了...自助餐.大家一起来吃', '1', '13', '1', '1');
INSERT INTO `tv_route_details` VALUES ('69', '六星汽车宾馆(罗湖旗舰店) ', '15', '12:03', '03:02', '32131', '1', '5', '1', '1');
INSERT INTO `tv_route_details` VALUES ('70', '萬膳日本料理·铁板烧', '15', '13:03', '14:04', '3423', '2', '2', '2', '1');
INSERT INTO `tv_route_details` VALUES ('71', '深圳东部华侨城茵特拉根酒店', '15', '04:23', '05:05', '5432', '3', '7', '1', '1');
INSERT INTO `tv_route_details` VALUES ('72', '珠海长隆海洋王国', '15', '23:43', '00:00', 'reterter', '4', '1', '3', '1');
INSERT INTO `tv_route_details` VALUES ('73', '', '15', '', '', '', '5', '', '', '1');
INSERT INTO `tv_route_details` VALUES ('74', '', '15', '', '', '', '6', '', '', '1');
INSERT INTO `tv_route_details` VALUES ('75', '', '15', '', '', '', '7', '', '', '1');
INSERT INTO `tv_route_details` VALUES ('76', '江南味道(卓越店)  分店', '14', '04:23', '04:32', '43243243', '1', '4', '2', '1');
INSERT INTO `tv_route_details` VALUES ('77', '萬膳日本料理·铁板烧', '14', '03:54', '23:04', '24324', '2', '2', '2', '1');
INSERT INTO `tv_route_details` VALUES ('78', '萬膳日本料理·铁板烧', '13', '23:04', '04:32', '432423', '1', '2', '2', '1');
INSERT INTO `tv_route_details` VALUES ('79', '', '13', '04:24', '04:34', '4234234', '2', '', '4', '1');
INSERT INTO `tv_route_details` VALUES ('80', '珠海长隆海洋王国', '13', '04:32', '12:32', '34234', '3', '1', '3', '1');
INSERT INTO `tv_route_details` VALUES ('81', '珠海长隆海洋王国', '18', '10:00', '12:00', '观看海景', '1', '1', '3', '1');
INSERT INTO `tv_route_details` VALUES ('82', '江南味道(卓越店)  分店', '18', '13:00', '14:00', '吃饭', '1', '4', '2', '1');
INSERT INTO `tv_route_details` VALUES ('83', '阳朔世外桃源景区4A景区', '18', '', '', '泡温泉', '1', '5', '3', '1');
INSERT INTO `tv_route_details` VALUES ('84', '', '18', '', '', '自用活动', '2', '', '4', '1');
INSERT INTO `tv_route_details` VALUES ('85', '六星汽车宾馆(罗湖旗舰店) ', '18', '18:00', '00:00', '住', '3', '5', '1', '1');

-- -----------------------------
-- Table structure for `tv_score_member_log`
-- -----------------------------
DROP TABLE IF EXISTS `tv_score_member_log`;
CREATE TABLE `tv_score_member_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL COMMENT '用户id',
  `val` decimal(11,2) NOT NULL COMMENT '获取/使用积分值',
  `content` tinytext NOT NULL COMMENT '获取/使用积分途径',
  `url` varchar(100) NOT NULL COMMENT '在哪里获取的',
  `insert_time` varchar(10) NOT NULL COMMENT '获取/使用时间',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型（1：获取，0：使用）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_score_member_log`
-- -----------------------------
INSERT INTO `tv_score_member_log` VALUES ('2', '1', '12.00', '212121', '21212', '121212121', '1');
INSERT INTO `tv_score_member_log` VALUES ('3', '44', '50.00', '用于购买产品', '/index.php?s=/home/product/rtcontent/id/5.html', '1441879034', '0');
INSERT INTO `tv_score_member_log` VALUES ('4', '44', '50.00', '用于购买产品', '/index.php?s=/home/product/rtcontent/id/5.html', '1441879169', '0');
INSERT INTO `tv_score_member_log` VALUES ('5', '44', '50.00', '用于购买产品', '/index.php?s=/home/product/pycontent/id/2.html', '1441886775', '0');

-- -----------------------------
-- Table structure for `tv_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `tv_ucenter_admin`;
CREATE TABLE `tv_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='管理员表';

-- -----------------------------
-- Records of `tv_ucenter_admin`
-- -----------------------------
INSERT INTO `tv_ucenter_admin` VALUES ('1', '1', '1');

-- -----------------------------
-- Table structure for `tv_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `tv_ucenter_app`;
CREATE TABLE `tv_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `tv_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `tv_ucenter_member`;
CREATE TABLE `tv_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(25) DEFAULT NULL COMMENT '用户名',
  `password` varchar(32) NOT NULL COMMENT '密码',
  `mobile` varchar(20) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `email` varchar(50) DEFAULT NULL COMMENT '用户邮箱',
  `reg_ip` varchar(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` varchar(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) DEFAULT '1' COMMENT '会员状态(0:禁用；1:启用；2:删除)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `tv_ucenter_member`
-- -----------------------------
INSERT INTO `tv_ucenter_member` VALUES ('1', 'admin', 'fca5002d9792fdec5870d0831103348c', '1304934099', '1438751921', '', '2130706433', '1442025003', '2130706433', '1438751921', '1');
INSERT INTO `tv_ucenter_member` VALUES ('45', '', 'a3dc31213569fc5b641eed693f289bb5', '13489753614', '1439800381', '', '2130706433', '1442045194', '2130706433', '1439800381', '1');
INSERT INTO `tv_ucenter_member` VALUES ('44', 'calvin', 'bee82882cb6ee8432ee62845fec0970f', '13049340998', '1439255079', '', '2130706433', '1440748877', '2130706433', '1439255079', '1');
INSERT INTO `tv_ucenter_member` VALUES ('43', 'calvin3', 'bee82882cb6ee8432ee62845fec0970f', '13049340995', '1439202374', '', '2130706433', '1439773842', '2130706433', '1439202374', '1');
INSERT INTO `tv_ucenter_member` VALUES ('42', '', 'bee82882cb6ee8432ee62845fec0970f', '13049340996', '1439202207', '', '2130706433', '1440138202', '2130706433', '1439202207', '2');
INSERT INTO `tv_ucenter_member` VALUES ('41', 'calvin1', 'bee82882cb6ee8432ee62845fec0970f', '13049340994', '1439201383', '', '2130706433', '1441018229', '2005438120', '1439201383', '1');
INSERT INTO `tv_ucenter_member` VALUES ('48', 'asdasd', 'a3dc31213569fc5b641eed693f289bb5', '18588613274', '1440233679', '', '2130706433', '1441019117', '2005438120', '1440472960', '1');
INSERT INTO `tv_ucenter_member` VALUES ('49', 'calvin-yang', 'bee82882cb6ee8432ee62845fec0970f', '1357853614', '1440571084', '977639814@qq.com', '2130706433', '1441771362', '2130706433', '1440571084', '1');
INSERT INTO `tv_ucenter_member` VALUES ('50', '123456', 'bee82882cb6ee8432ee62845fec0970f', '18507565649', '1441014355', '', '2005438120', '0', '0', '1441018256', '1');
INSERT INTO `tv_ucenter_member` VALUES ('51', '', 'asdasd', '18588613273', '0', '', '0', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `tv_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `tv_ucenter_setting`;
CREATE TABLE `tv_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `tv_upvote`
-- -----------------------------
DROP TABLE IF EXISTS `tv_upvote`;
CREATE TABLE `tv_upvote` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '点赞表id',
  `uid` int(11) NOT NULL COMMENT '点赞用户id',
  `pro_id` varchar(11) NOT NULL COMMENT '点赞产品',
  `pro_type` varchar(2) DEFAULT NULL COMMENT '点赞产品类型',
  `time` varchar(10) DEFAULT NULL COMMENT '点赞时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_upvote`
-- -----------------------------
INSERT INTO `tv_upvote` VALUES ('3', '1', '3', '2', '1441533303');
INSERT INTO `tv_upvote` VALUES ('2', '1', '3', '1', '1441533055');
INSERT INTO `tv_upvote` VALUES ('4', '1', '4', '1', '1441533363');
INSERT INTO `tv_upvote` VALUES ('5', '1', '9', '4', '1441533413');
INSERT INTO `tv_upvote` VALUES ('6', '1', '10', '4', '1441533413');
INSERT INTO `tv_upvote` VALUES ('7', '49', '3', '1', '1441533303');
INSERT INTO `tv_upvote` VALUES ('8', '1', '4', '2', '1441533303');
INSERT INTO `tv_upvote` VALUES ('9', '1', '4', '3', '1441533363');

-- -----------------------------
-- Table structure for `tv_url`
-- -----------------------------
DROP TABLE IF EXISTS `tv_url`;
CREATE TABLE `tv_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `tv_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `tv_userdata`;
CREATE TABLE `tv_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `tv_verifycode`
-- -----------------------------
DROP TABLE IF EXISTS `tv_verifycode`;
CREATE TABLE `tv_verifycode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` char(6) DEFAULT '',
  `type` enum('mobile_verify','forget_pwd','reg','edit_mobile_two','edit_mobile_one') DEFAULT 'mobile_verify' COMMENT '验证类型',
  `mobile` bigint(11) DEFAULT '0' COMMENT '手机号码',
  `user_id` int(11) DEFAULT '0' COMMENT '会员id',
  `content` varchar(300) DEFAULT '',
  `status` tinyint(1) DEFAULT '0' COMMENT '1发送成功 2发送失败 3已使用',
  `create_time` int(10) DEFAULT '0' COMMENT '发送时间',
  `verify_time` int(10) DEFAULT '0' COMMENT '验证时间',
  `verify_validity` int(10) DEFAULT '0' COMMENT '验证码有效时间',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_verifycode`
-- -----------------------------
INSERT INTO `tv_verifycode` VALUES ('1', 'BLIMA', 'reg', '0', '0', '您的验证码是：[BLIMA]', '1', '1440148662', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('2', '7I1RK', 'reg', '0', '0', '您的验证码是：[7I1RK]', '2', '1440215771', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('3', 'H3W4C', 'reg', '0', '0', '您的验证码是：[H3W4C]', '2', '1440223858', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('4', 'EXLG4', 'reg', '0', '0', '您的验证码是：[EXLG4]', '2', '1440223980', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('5', '8QPUX', 'reg', '0', '0', '您的验证码是：[8QPUX]', '2', '1440224057', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('6', 'BPQAX', 'reg', '0', '0', '您的验证码是：[BPQAX]', '1', '1440224125', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('7', 'PFW3B', 'reg', '0', '0', '您的验证码是：[PFW3B]', '1', '1440224213', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('8', '4UDHB', 'reg', '0', '0', '您的验证码是：[4UDHB]', '1', '1440224473', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('9', 'WQ9LU', 'reg', '0', '0', '您的验证码是：[WQ9LU]', '1', '1440224533', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('10', 'SDMK2', 'reg', '0', '0', '您的验证码是：[SDMK2]', '1', '1440224662', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('11', 'JGUP6', 'reg', '2147483647', '0', '您的验证码是：[JGUP6]', '1', '1440224835', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('12', 'ZYBDH', 'reg', '18588613273', '0', '您的验证码是：[ZYBDH]', '1', '1440224897', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('13', 'B5U9C', 'reg', '18588613273', '0', '您的验证码是：[B5U9C]', '1', '1440227654', '0', '1440227954');
INSERT INTO `tv_verifycode` VALUES ('14', '5ESJ4', 'reg', '18588613273', '0', '您的验证码是：[5ESJ4]', '1', '1440228167', '0', '1440228467');
INSERT INTO `tv_verifycode` VALUES ('15', 'HFSPM', 'reg', '18588613273', '0', '您的验证码是：[HFSPM]', '1', '1440232033', '0', '1440232333');
INSERT INTO `tv_verifycode` VALUES ('16', 'OOY19', 'reg', '18588613273', '0', '您的验证码是：[OOY19]', '1', '1440233644', '0', '1440233944');
INSERT INTO `tv_verifycode` VALUES ('17', 'AW6R8', 'reg', '18588613273', '0', '您的验证码是：[AW6R8]', '1', '1440236413', '0', '1440236713');
INSERT INTO `tv_verifycode` VALUES ('18', 'D2AWG', 'reg', '13417978975', '0', '您的验证码是：[D2AWG]', '1', '1440378209', '0', '1440378509');
INSERT INTO `tv_verifycode` VALUES ('19', 'UEWHT', 'forget_pwd', '18588613273', '0', '您的验证码是：[UEWHT]', '1', '1440418946', '0', '1440419246');
INSERT INTO `tv_verifycode` VALUES ('20', 'R16O1', 'forget_pwd', '18588613277', '0', '您的验证码是：[R16O1]', '1', '1440419699', '0', '1440419999');
INSERT INTO `tv_verifycode` VALUES ('21', 'GP6HN', 'forget_pwd', '18588613273', '0', '您的验证码是：[GP6HN]', '1', '1440419792', '0', '1440420092');
INSERT INTO `tv_verifycode` VALUES ('22', '7GZL7', 'forget_pwd', '18588613273', '0', '您的验证码是：[7GZL7]', '1', '1440420543', '0', '1440420843');
INSERT INTO `tv_verifycode` VALUES ('23', 'AWRUW', 'reg', '18588613277', '0', '您的验证码是：[AWRUW]', '1', '1440420590', '0', '1440420890');
INSERT INTO `tv_verifycode` VALUES ('24', '24PZS', 'reg', '18588613274', '0', '您的验证码是：[24PZS]', '1', '1440420666', '0', '1440420966');
INSERT INTO `tv_verifycode` VALUES ('25', '4WRYQ', 'reg', '18588613274', '0', '您的验证码是：[4WRYQ]', '1', '1440420682', '0', '1440420982');
INSERT INTO `tv_verifycode` VALUES ('26', 'C2ITO', 'forget_pwd', '18588613273', '0', '您的验证码是：[C2ITO]', '3', '1440469777', '1440469984', '1440470077');
INSERT INTO `tv_verifycode` VALUES ('27', 'U9GAD', 'forget_pwd', '18588613273', '0', '您的验证码是：[U9GAD]', '1', '1440471758', '0', '1440472058');
INSERT INTO `tv_verifycode` VALUES ('28', 'QC9H2', 'edit_mobile_one', '18588613273', '0', '您的验证码是：[QC9H2]', '1', '1440491252', '0', '1440491552');
INSERT INTO `tv_verifycode` VALUES ('29', 'RLK4F', 'edit_mobile_one', '18588613273', '0', '您的验证码是：[RLK4F]', '3', '1440493098', '1440493174', '1440493398');
INSERT INTO `tv_verifycode` VALUES ('30', 'H26TD', 'edit_mobile_two', '18588613273', '0', '您的验证码是：[H26TD]', '1', '1440494386', '0', '1440494686');
INSERT INTO `tv_verifycode` VALUES ('31', 'A78DG', 'edit_mobile_two', '18588613274', '0', '您的验证码是：[A78DG]', '3', '1440496378', '1440496504', '1440496678');
INSERT INTO `tv_verifycode` VALUES ('32', 'WVB4Q', 'edit_mobile_one', '18588613273', '0', '您的验证码是：[WVB4Q]', '1', '1440497283', '0', '1440497583');
INSERT INTO `tv_verifycode` VALUES ('33', 'FKD26', 'edit_mobile_one', '18588613273', '0', '您的验证码是：[FKD26]', '1', '1440497386', '0', '1440497686');
INSERT INTO `tv_verifycode` VALUES ('34', '4IMJB', 'edit_mobile_one', '18588613274', '0', '您的验证码是：[4IMJB]', '3', '1440497604', '1440497622', '1440497904');
INSERT INTO `tv_verifycode` VALUES ('35', 'AJ8CI', 'edit_mobile_two', '18588613273', '0', '您的验证码是：[AJ8CI]', '3', '1440497676', '1440497934', '1440497976');
INSERT INTO `tv_verifycode` VALUES ('36', 'CQR6R', 'reg', '13049340993', '0', '您的验证码是：[CQR6R]', '1', '1440753651', '0', '1440753951');
INSERT INTO `tv_verifycode` VALUES ('37', 'S3BOL', 'reg', '18507565649', '0', '您的验证码是：[S3BOL]', '1', '1441011607', '0', '1441011907');
INSERT INTO `tv_verifycode` VALUES ('38', 'AUEE2', 'reg', '18507565649', '0', '您的验证码是：[AUEE2]', '1', '1441011743', '0', '1441012043');
INSERT INTO `tv_verifycode` VALUES ('39', '4BN1C', 'reg', '18507565649', '0', '您的验证码是：[4BN1C]', '1', '1441012343', '0', '1441012643');
INSERT INTO `tv_verifycode` VALUES ('40', '2MAEQ', 'reg', '18507565649', '0', '您的验证码是：[2MAEQ]', '1', '1441012433', '0', '1441012733');
INSERT INTO `tv_verifycode` VALUES ('41', 'TPZDE', 'reg', '18507565649', '0', '您的验证码是：[TPZDE]', '1', '1441012981', '0', '1441013281');
INSERT INTO `tv_verifycode` VALUES ('42', 'RIRPZ', 'reg', '18507565649', '0', '您的验证码是：[RIRPZ]', '1', '1441013476', '0', '1441013776');
INSERT INTO `tv_verifycode` VALUES ('43', 'FIYWU', 'reg', '18507565649', '0', '您的验证码是：[FIYWU]', '1', '1441013546', '0', '1441013846');
INSERT INTO `tv_verifycode` VALUES ('44', 'TTA5F', 'reg', '18507565649', '0', '您的验证码是：[TTA5F]', '1', '1441013621', '0', '1441013921');
INSERT INTO `tv_verifycode` VALUES ('45', 'HIEPW', 'reg', '18507565649', '0', '您的验证码是：[HIEPW]', '1', '1441013706', '0', '1441014006');
INSERT INTO `tv_verifycode` VALUES ('46', 'UZAAU', 'reg', '18507565649', '0', '您的验证码是：[UZAAU]', '1', '1441013742', '0', '1441014042');
INSERT INTO `tv_verifycode` VALUES ('47', '41VF4', 'reg', '18507565649', '0', '您的验证码是：[41VF4]', '1', '1441013745', '0', '1441014045');
INSERT INTO `tv_verifycode` VALUES ('48', 'ZF2K2', 'reg', '18507565649', '0', '您的验证码是：[ZF2K2]', '1', '1441013745', '0', '1441014045');
INSERT INTO `tv_verifycode` VALUES ('49', 'O4K6Q', 'reg', '18507565649', '0', '您的验证码是：[O4K6Q]', '1', '1441013787', '0', '1441014087');
INSERT INTO `tv_verifycode` VALUES ('50', 'VS5Q4', 'reg', '18507565649', '0', '您的验证码是：[VS5Q4]', '1', '1441013824', '0', '1441014124');
INSERT INTO `tv_verifycode` VALUES ('51', 'GNRJU', 'reg', '18588613273', '0', '您的验证码是：[GNRJU]', '1', '1441013892', '0', '1441014192');
INSERT INTO `tv_verifycode` VALUES ('54', '94578', 'reg', '18507565649', '0', '您的验证码是：[94578]', '1', '1441014439', '0', '1441014739');
INSERT INTO `tv_verifycode` VALUES ('55', '89499', 'reg', '18507565649', '0', '您的验证码是：[89499]', '1', '1441014512', '0', '1441014812');
INSERT INTO `tv_verifycode` VALUES ('56', '09321', 'reg', '18507565649', '0', '您的验证码是：[09321]', '1', '1441014534', '0', '1441014834');
INSERT INTO `tv_verifycode` VALUES ('57', '08309', 'reg', '18507565649', '0', '您的验证码是：[08309]', '3', '1441014607', '1441014705', '1441014907');
INSERT INTO `tv_verifycode` VALUES ('58', '69929', 'reg', '18507565649', '0', '您的验证码是：[69929]', '1', '1441014740', '0', '1441017040');
INSERT INTO `tv_verifycode` VALUES ('59', '72400', 'reg', '18588613273', '0', '您的验证码是：[72400]', '3', '1441015405', '1441017445', '1441115905');
INSERT INTO `tv_verifycode` VALUES ('60', '06084', 'forget_pwd', '18507565649', '0', '您的验证码是：[06084]', '1', '1441015736', '0', '1441016036');
INSERT INTO `tv_verifycode` VALUES ('61', '73475', 'forget_pwd', '18507565649', '0', '您的验证码是：[73475]', '1', '1441015948', '0', '1441016248');
INSERT INTO `tv_verifycode` VALUES ('62', '15157', 'forget_pwd', '18507565649', '0', '您的验证码是：[15157]', '1', '1441016670', '0', '1441016970');
INSERT INTO `tv_verifycode` VALUES ('63', '08218', 'forget_pwd', '18507565649', '0', '您的验证码是：[08218]', '3', '1441016867', '1441017093', '1441017167');
INSERT INTO `tv_verifycode` VALUES ('64', '82239', 'forget_pwd', '18507565649', '0', '您的验证码是：[82239]', '3', '1441017790', '1441017823', '1441018090');
INSERT INTO `tv_verifycode` VALUES ('65', '', 'mobile_verify', '0', '0', '', '0', '0', '0', '0');
INSERT INTO `tv_verifycode` VALUES ('66', '67825', 'forget_pwd', '18507565649', '0', '您的验证码是：[67825]', '3', '1441680249', '1441680275', '1441680549');

-- -----------------------------
-- Table structure for `tv_vip`
-- -----------------------------
DROP TABLE IF EXISTS `tv_vip`;
CREATE TABLE `tv_vip` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL COMMENT '名称',
  `discount` varchar(6) DEFAULT '0' COMMENT '折扣价',
  `remark` varchar(255) DEFAULT NULL COMMENT '用途（描述）',
  `monthly_price` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '月价',
  `status` int(1) NOT NULL DEFAULT '1' COMMENT 'Vip状态（0：禁用；1：启用；2：删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_vip`
-- -----------------------------
INSERT INTO `tv_vip` VALUES ('20', 'vip-1', '20', '40', '34343.00', '1');
INSERT INTO `tv_vip` VALUES ('21', 'vip-2', '88', '', '200.00', '1');

-- -----------------------------
-- Table structure for `tv_voucher`
-- -----------------------------
DROP TABLE IF EXISTS `tv_voucher`;
CREATE TABLE `tv_voucher` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `number` varchar(11) NOT NULL COMMENT '代金券数量',
  `pro_id` varchar(11) NOT NULL COMMENT '产品id',
  `pro_type` varchar(2) DEFAULT NULL COMMENT '产品类型',
  `voucher_price` decimal(10,2) NOT NULL COMMENT '代金券价格',
  `insert_time` varchar(10) NOT NULL COMMENT '购买时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tv_voucher`
-- -----------------------------
INSERT INTO `tv_voucher` VALUES ('1', '44', '4', '8', '2', '89.00', '1441880846');
